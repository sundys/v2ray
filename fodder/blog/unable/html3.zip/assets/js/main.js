/* ==========================================================================
   HELIX 螺旋科技 — 交互脚本
   纯静态演示：数据全部内置，无任何网络请求
   ========================================================================== */
"use strict";

(function () {
  document.documentElement.classList.add("has-js");

  /* ==================== 1. 工具与状态 ==================== */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const pad = (n) => String(n).padStart(2, "0");
  const reduceQuery = window.matchMedia("(prefers-reduced-motion: reduce)");

  const state = {
    reduce: reduceQuery.matches,
    filter: "all",
    tab: "models"
  };

  const fmt = (value, digits) =>
    Number(value).toLocaleString("zh-CN", {
      minimumFractionDigits: digits,
      maximumFractionDigits: digits
    });

  /* ==================== 2. 内置数据（虚构样本） ==================== */
  const BENCH = {
    models: {
      caption: "MMLU-Pro 得分 · 2026-11-13 统一评测（5-shot）",
      unit: "分",
      items: [
        { name: "Helix-3 236B", org: "螺旋智能", value: 88.4, delta: 1.2 },
        { name: "弦论-72B", org: "弦论智能", value: 85.1, delta: 0.4 },
        { name: "拓扑-32B", org: "拓扑纪元", value: 82.7, delta: 0.9 },
        { name: "霁云-MoE 141B", org: "霁云智算", value: 80.9, delta: -0.3 },
        { name: "沧溟-13B", org: "沧溟实验室", value: 76.2, delta: 0.6 }
      ]
    },
    chips: {
      caption: "FP8 稠密算力 · 单卡实测（PFLOPS）",
      unit: "P",
      items: [
        { name: "澜芯 X1", org: "澜芯半导体 · 2nm", value: 1.2, delta: 0.1 },
        { name: "蚀刻 A9", org: "蚀刻微电子 · 3nm", value: 0.9, delta: 0.05 },
        { name: "霁云 C500", org: "霁云智算 · 5nm", value: 0.7, delta: 0 },
        { name: "拓扑 T2", org: "拓扑纪元 · 5nm", value: 0.6, delta: -0.02 },
        { name: "沧溟 M1", org: "沧溟实验室 · 6nm", value: 0.48, delta: 0.03 }
      ]
    },
    repos: {
      caption: "GitHub 周增 star · 2026-11-07 至 11-14",
      unit: "k",
      items: [
        { name: "rust-infer", org: "openhelix", value: 3.2, delta: 0.8 },
        { name: "helix-tokenizer", org: "openhelix", value: 1.1, delta: 0.2 },
        { name: "a3-scheduler", org: "jiyun-lab", value: 0.84, delta: 0.31 },
        { name: "moe-router", org: "helix-research", value: 0.62, delta: 0.12 },
        { name: "tiny-hbm-sim", org: "lanxin", value: 0.41, delta: 0.09 }
      ]
    }
  };

  const TERM_SAMPLES = {
    util: ["96.2%", "94.8%", "97.1%", "95.5%", "98.0%"],
    temp: ["32.4℃ → 41.8℃", "31.9℃ → 41.2℃", "33.1℃ → 42.5℃", "32.7℃ → 42.0℃"],
    price: ["¥ 28.4 / 卡时", "¥ 27.9 / 卡时", "¥ 29.1 / 卡时", "¥ 28.0 / 卡时"]
  };

  /* ==================== 3. 快讯 marquee ==================== */
  // 悬停由 CSS 暂停；按钮提供键盘与触屏的显式暂停
  function initTicker() {
    const ticker = $("#ticker");
    const btn = $("#tickerBtn");
    if (!ticker || !btn) return;

    let paused = state.reduce;

    function sync() {
      ticker.classList.toggle("is-paused", paused);
      btn.setAttribute("aria-pressed", paused ? "true" : "false");
      btn.setAttribute("aria-label", paused ? "继续快讯滚动" : "暂停快讯滚动");
    }

    btn.addEventListener("click", () => {
      paused = !paused;
      sync();
    });

    sync();
    state.tickerPause = (value) => {
      paused = value;
      sync();
    };
  }

  /* ==================== 4. 数字增长 ==================== */
  // 进入视口后用 requestAnimationFrame 缓动到目标值；减少动效时直接落位
  function initCountUp() {
    const nums = $$("[data-count]");
    if (!nums.length) return;

    const finish = (el) => {
      const target = Number(el.dataset.count);
      const digits = Number(el.dataset.decimals || 0);
      el.textContent = fmt(target, digits);
    };

    if (state.reduce || !("IntersectionObserver" in window)) {
      nums.forEach(finish);
      state.countFinish = () => nums.forEach(finish);
      return;
    }

    function run(el) {
      const target = Number(el.dataset.count);
      const digits = Number(el.dataset.decimals || 0);
      const duration = 1400;
      const start = performance.now();

      function step(now) {
        const p = Math.min(1, (now - start) / duration);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = fmt(target * eased, digits);
        if (p < 1) requestAnimationFrame(step);
        else el.textContent = fmt(target, digits);
      }

      requestAnimationFrame(step);
    }

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          io.unobserve(entry.target);
          run(entry.target);
        });
      },
      { threshold: 0.4 }
    );

    nums.forEach((el) => io.observe(el));
    state.countFinish = () => nums.forEach(finish);
  }

  /* ==================== 5. 滚动淡入 ==================== */
  // 仅在 JS 可用时启用，避免禁用脚本后内容不可见
  function initReveal() {
    const items = $$("[data-reveal]");
    if (!items.length) return;

    if (state.reduce || !("IntersectionObserver" in window)) {
      items.forEach((el) => el.classList.add("is-in"));
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add("is-in");
          io.unobserve(entry.target);
        });
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.1 }
    );

    items.forEach((el) => io.observe(el));
  }

  /* ==================== 6. Bento 筛选器 ==================== */
  // data-cat 与 data-filter 对应；筛选时取消命名区域，改为等宽排布
  function initBentoFilter() {
    const bento = $("#bento");
    const status = $("#filterStatus");
    if (!bento) return;

    const buttons = $$("[data-filter]");
    const cards = $$("[data-cat]", bento);

    buttons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const filter = btn.dataset.filter;
        if (filter === state.filter) return;
        state.filter = filter;

        buttons.forEach((b) => {
          const on = b === btn;
          b.classList.toggle("is-active", on);
          b.setAttribute("aria-pressed", on ? "true" : "false");
        });

        let shown = 0;
        cards.forEach((card) => {
          const visible = filter === "all" || card.dataset.cat === filter;
          card.hidden = !visible;
          if (visible) shown += 1;
        });

        bento.classList.toggle("is-filtered", filter !== "all");

        if (status) {
          const label = btn.textContent.trim();
          status.textContent =
            filter === "all"
              ? "共 " + shown + " 张卡片"
              : "已筛选「" + label + "」，共 " + shown + " 张卡片";
        }
      });
    });
  }

  /* ==================== 7. 基准榜单标签页 ==================== */
  // 渲染列表 + 方向键 / Home / End 键盘导航
  function initBenchTabs() {
    const list = $("#benchList");
    const caption = $("#benchCaption");
    const panel = $("#panel-bench");
    const tabs = $$("[data-tab]");
    if (!list || !tabs.length) return;

    const formatValue = (value) => {
      if (value < 1) return value.toFixed(2);
      return value.toFixed(1).replace(/\.0$/, "");
    };

    function render(key) {
      const data = BENCH[key];
      if (!data) return;

      const max = Math.max.apply(
        null,
        data.items.map((item) => item.value)
      );

      list.innerHTML = "";
      data.items.forEach((item, index) => {
        const width = Math.max(0.12, item.value / max).toFixed(3);
        const li = document.createElement("li");
        li.className = "bench__row";
        li.innerHTML =
          '<span class="bench__rank">' + pad(index + 1) + "</span>" +
          '<span class="bench__name">' + item.name + "<small>" + item.org + "</small></span>" +
          '<span class="bench__bar" aria-hidden="true"><i style="--w:' + width + '"></i></span>' +
          '<span class="bench__val">' + formatValue(item.value) + "<i>" + data.unit + "</i></span>" +
          '<span class="bench__delta ' + (item.delta > 0 ? "is-up" : item.delta < 0 ? "is-down" : "") + '">' +
          (item.delta > 0 ? "+" : "") + item.delta + "</span>";
        list.appendChild(li);
      });

      if (caption) caption.textContent = data.caption;
    }

    function activate(btn) {
      tabs.forEach((tab) => {
        const on = tab === btn;
        tab.classList.toggle("is-active", on);
        tab.setAttribute("aria-selected", on ? "true" : "false");
        tab.tabIndex = on ? 0 : -1;
      });

      state.tab = btn.dataset.tab;
      if (panel) panel.setAttribute("aria-labelledby", btn.id);
      render(state.tab);
    }

    tabs.forEach((btn) => {
      btn.addEventListener("click", () => activate(btn));

      btn.addEventListener("keydown", (event) => {
        const keys = ["ArrowRight", "ArrowLeft", "Home", "End"];
        if (keys.indexOf(event.key) === -1) return;
        event.preventDefault();

        const index = tabs.indexOf(btn);
        let next = index;

        if (event.key === "ArrowRight") next = (index + 1) % tabs.length;
        if (event.key === "ArrowLeft") next = (index - 1 + tabs.length) % tabs.length;
        if (event.key === "Home") next = 0;
        if (event.key === "End") next = tabs.length - 1;

        activate(tabs[next]);
        tabs[next].focus();
      });
    });

    render(state.tab);
  }

  /* ==================== 8. 卡片光斑跟随 ==================== */
  // 指针位置写入 --mx / --my，用 rAF 合并高频事件
  function initSpotlight() {
    const bento = $("#bento");
    if (!bento || state.reduce) return;

    let frame = 0;
    let last = null;

    bento.addEventListener("pointermove", (event) => {
      const card = event.target.closest(".bento__card");
      if (!card) return;
      last = { card: card, x: event.clientX, y: event.clientY };
      if (frame) return;

      frame = requestAnimationFrame(() => {
        frame = 0;
        if (!last) return;
        const rect = last.card.getBoundingClientRect();
        last.card.style.setProperty("--mx", ((last.x - rect.left) / rect.width) * 100 + "%");
        last.card.style.setProperty("--my", ((last.y - rect.top) / rect.height) * 100 + "%");
      });
    });
  }

  /* ==================== 9. 终端重新采样 ==================== */
  function initTerminal() {
    const body = $("#termBody");
    const btn = $("#termRefresh");
    const time = $("#termTime");
    if (!body || !btn) return;

    function sample() {
      $$("[data-t]", body).forEach((el) => {
        const pool = TERM_SAMPLES[el.dataset.t];
        if (!pool) return;
        el.textContent = pool[Math.floor(Math.random() * pool.length)];
      });

      if (time) {
        const now = new Date();
        time.textContent = pad(now.getHours()) + ":" + pad(now.getMinutes()) + ":" + pad(now.getSeconds());
        time.setAttribute("datetime", now.toISOString());
      }
    }

    btn.addEventListener("click", () => {
      btn.disabled = true;
      sample();
      window.setTimeout(() => {
        btn.disabled = false;
      }, 420);
    });
  }

  /* ==================== 10. 订阅表单 ==================== */
  // 纯本地校验，不发送任何请求
  function initForm() {
    const form = $("#subForm");
    const input = $("#subEmail");
    const msg = $("#subMsg");
    if (!form || !input || !msg) return;

    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const value = input.value.trim();
      const valid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);

      if (!valid) {
        input.setAttribute("aria-invalid", "true");
        msg.className = "sub__msg is-err";
        msg.textContent = "请填写有效的邮箱地址，例如 editor@helix.tech。";
        input.focus();
        return;
      }

      input.removeAttribute("aria-invalid");
      msg.className = "sub__msg is-ok";
      msg.textContent = "已向 " + value + " 发送确认邮件；演示环境不会真正投递。";
    });

    input.addEventListener("input", () => {
      if (input.getAttribute("aria-invalid") !== "true") return;
      input.removeAttribute("aria-invalid");
      msg.textContent = "";
    });
  }

  /* ==================== 11. 移动端导航 ==================== */
  function initMobileNav() {
    const details = $(".mnav");
    if (!details) return;

    $$("a", details).forEach((link) => {
      link.addEventListener("click", () => {
        details.removeAttribute("open");
      });
    });
  }

  /* ==================== 12. 滚动高亮当前栏目 ==================== */
  function initScrollSpy() {
    const links = $$(".nav__list a");
    if (!links.length || !("IntersectionObserver" in window)) return;

    const map = new Map();
    links.forEach((link) => {
      const href = link.getAttribute("href") || "";
      if (!href.startsWith("#")) return;
      const section = document.getElementById(href.slice(1));
      if (section) map.set(section, link);
    });

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const active = map.get(entry.target);
          if (!active) return;
          links.forEach((link) => {
            link.classList.remove("is-current");
            link.removeAttribute("aria-current");
          });
          active.classList.add("is-current");
          active.setAttribute("aria-current", "true");
        });
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );

    map.forEach((link, section) => io.observe(section));
  }

  /* ==================== 13. 启动 ==================== */
  function init() {
    initTicker();
    initCountUp();
    initReveal();
    initBentoFilter();
    initBenchTabs();
    initSpotlight();
    initTerminal();
    initForm();
    initMobileNav();
    initScrollSpy();

    reduceQuery.addEventListener("change", (event) => {
      state.reduce = event.matches;

      if (event.matches) {
        $$("[data-reveal]").forEach((el) => el.classList.add("is-in"));
        if (state.countFinish) state.countFinish();
        if (state.tickerPause) state.tickerPause(true);
      } else if (state.tickerPause) {
        state.tickerPause(false);
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
