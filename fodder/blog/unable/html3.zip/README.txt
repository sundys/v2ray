HELIX 螺旋科技 · 静态主页
========================================================================

一、项目说明
------------------------------------------------------------------------
这是一个零外部依赖的纯静态科技媒体主页，主题为「HELIX · 电光青 +
酸性绿 + 深空黑 Bento」。所有公司、人物、参数、金额与事件均为虚构，
仅用于版式与交互演示。

设计关键词：深空底色、细网格、光束、Bento Grid、等宽终端数据块、
数字滚动统计、卡片描边流光、无缝快讯 marquee。

二、目录结构
------------------------------------------------------------------------
03-tech/
├── index.html                 单页结构（语义化标签 + 内联 SVG 图标）
├── favicon.svg                站点图标（双螺旋标记）
├── README.txt                 本文件
└── assets/
    ├── css/
    │   └── style.css          单文件样式，@layer 分层
    ├── js/
    │   └── main.js            经典脚本（defer），无 import/export
    └── img/
        ├── chip-die.webp          头条主图：芯片裸片与走线
        ├── terminal-code.webp     模型开源新闻配图
        ├── code-review.webp       推理框架新闻配图
        ├── lab-server.webp        Bento 算力卡配图
        ├── humanoid-robot.webp    Bento 机器人卡配图
        └── orbital-cloud.webp     全球节点长图

图片均来自本地素材池，宽 1600px，统一加暗色遮罩与降低饱和度，
以匹配深空色调。

三、页面区块
------------------------------------------------------------------------
1. 顶栏：品牌、主导航、移动端原生 details 菜单、订阅入口
2. 顶部快讯：CSS 动画无缝 marquee（内容复制一份）+ 悬停/按钮暂停
3. Hero：主标题、终端状态卡、光束与径向光晕背景
4. 今日头条：跨栏主稿 + 两条配图快讯 + 三条短讯
5. 产品矩阵：8 张不等大 Bento 卡片（grid-template-areas），
   支持按「算力基建 / 芯片与模型 / 生态与资本」筛选
6. 数据统计：4 个数字滚动统计 + 算力成本指数条
7. 基准榜单：模型 / 芯片 / 开源三个标签页，方向键可切换
8. 开源雷达与资本信号：项目周增榜、融资表、全球节点长图
9. 订阅：本地邮箱校验与 aria-live 提示
10. 页脚：栏目导航、虚构备案号与免责声明

四、交互与可访问性
------------------------------------------------------------------------
- IntersectionObserver 触发数字增长与滚动淡入
- 卡片 hover 描边流光（mask 裁边 + 渐变扫过），指针跟随光斑
- marquee 用 CSS animation 位移 -50%，两组内容完全一致实现无缝
- 标签页补齐 role=tab / aria-selected / 方向键、Home、End
- 筛选按钮使用 aria-pressed，结果数量通过 aria-live 播报
- 首行 skip-link、单一 h1、全部图片有 alt、无内联事件属性
- prefers-reduced-motion 下停止 marquee、流光、计数与淡入
- 断点 640 / 900 / 1200，320px 宽无横向滚动

五、本地预览
------------------------------------------------------------------------
方式一：直接双击 index.html，用 file:// 打开（表现与线上一致）。
方式二：起一个静态服务器：

    cd D:\GitProject\html\03-tech
    npx serve .            # 或 python -m http.server 8080

六、nginx 部署配置
------------------------------------------------------------------------
把 03-tech 目录整体上传到服务器，例如 /var/www/helix-tech，
然后添加站点配置：

    server {
        listen 80;
        server_name helix.example.com;
        root /var/www/helix-tech;
        index index.html;

        charset utf-8;

        location / {
            try_files $uri $uri/ =404;
        }

        location ~* \.(?:css|js|webp|svg)$ {
            expires 30d;
            add_header Cache-Control "public, max-age=2592000, immutable";
            access_log off;
        }

        gzip on;
        gzip_comp_level 5;
        gzip_min_length 1024;
        gzip_types text/css application/javascript image/svg+xml;
    }

启用并重载：

    sudo ln -s /etc/nginx/sites-available/helix-tech /etc/nginx/sites-enabled/
    sudo nginx -t
    sudo systemctl reload nginx

如需 HTTPS，可用 certbot 申请证书后由 certbot 自动改写上述配置。

七、兼容性与约束
------------------------------------------------------------------------
- 目标浏览器：Chrome / Edge 120+、Safari 17.4+、Firefox 121+
- 使用 @layer、oklch()、color-mix()、:has()、容器查询、dvh、
  mask-composite，并为 mask-composite 与 backdrop-filter 提供回退
- 不加载任何网络字体、CDN、第三方库；图标全部为内联 SVG
- 无构建步骤，无 fetch 请求，可完全离线运行

八、内容声明
------------------------------------------------------------------------
页面中的「澜芯 X1」「Helix-3」「霁云智算」「擎羽 Q2」「拓扑纪元」
等名称、参数、融资金额、榜单分数、arXiv 编号与备案号均为虚构，
不对应任何真实主体，不构成投资或采购建议。
