FRAME 帧间影院 — 纯静态影视主页
====================================================================

一、站点简介
--------------------------------------------------------------------
「FRAME 帧间影院」是一个纯静态的影视 / 剧集主页示例：影院深炭底色 + 珊瑚红，
电影感排版（超大标题、紧凑字距、等宽数字序号）。页面包含主推轮播、热播榜、
分类片库、横向剧集行、创作者卡片、口碑短评与页脚等区块。

全部片名、主创、评分、播出时间均为虚构示例，不对应任何真实作品；
所有数据内置于 HTML / JS，页面不发起任何网络请求，可完全离线运行。


二、文件清单
--------------------------------------------------------------------
04-video/
├── index.html                 单页结构（语义标签 + 内联 SVG 图标精灵）
├── favicon.svg                站点图标（内联绘制，无外部字体/图片）
├── README.txt                 本说明
└── assets/
    ├── css/
    │   └── style.css          单文件样式表，@layer 分层：
    │                          reset → tokens → base → layout → components → utilities
    ├── js/
    │   └── main.js            单文件经典脚本（defer 加载，无 import/export）
    └── img/
        ├── feature-01.webp    主推轮播第 1 帧（1600×1280）
        ├── feature-02.webp    主推轮播第 2 帧 / 横版剧照（1600×1067）
        ├── feature-03.webp    主推轮播第 3 帧 / 横版剧照（1600×1067）
        ├── poster-01.webp     竖版海报位（1600×1081，object-fit: cover 裁切）
        ├── poster-02.webp     竖版海报位（1600×1067）
        └── poster-03.webp     竖版海报位（1600×1067）

说明：图片经 CSS 的 aspect-ratio（16/9、2/3、1/1）+ object-fit: cover 统一裁切，
并用深色渐变遮罩保证文字对比度；首屏主图 fetchpriority="high"，
其余图片 loading="lazy" + decoding="async"，均带 width/height 以避免 CLS。


三、页面区块
--------------------------------------------------------------------
1. 顶栏        品牌、主导航、更新日历 / 开始观看（sticky，滚动后加投影）
2. 主推区      h1 大标题 + 3 条 16:9 轮播（叠层标题、时长角标、渐变遮罩、
               播放按钮）+ 右侧竖排「热播榜」8 条
3. 分类片库    类型 tab（全部/剧集/电影/纪录片/短片）+ 搜索框
               + 12 张海报混排网格（2/3 竖版与 16/9 横版）
4. 新剧速递    横向滚动剧集行（8 张，含更新集数、更新时段、观看进度）
5. 幕后创作者  4 张创作者卡片（头像、身份、作品数、关注）
6. 本周口碑    编辑推荐大引言 + 3 条短评
7. 页脚        品牌简介、三栏导航、备案号样式与版权


四、已实现的交互
--------------------------------------------------------------------
- 主推轮播：6.5 秒自动播放；圆点 / 左右箭头手动切换；键盘 ← → Home End；
  hover 与聚焦时暂停，离开后恢复；标签页隐藏时停止计时；
  prefers-reduced-motion: reduce 时完全不自动播放；切换时通过 aria-live 播报。
- 分类筛选：tab 过滤 + 关键词搜索（片名 / 导演 / 类型），结果逐张淡入，
  实时更新「共 N 部作品」计数并支持空结果提示；tab 组内可用方向键切换。
- 横向剧集行：左右按钮按容器宽度滚动，鼠标可拖拽，键盘方向键 / Home / End，
  到达两端时按钮自动禁用。
- 模拟播放器：点击任意播放按钮打开 <dialog>，显示片名、类型与时长，
  支持播放 / 暂停与进度推进（8 倍速演示），Esc 或点击遮罩关闭。
- 片单收藏 / 关注创作者：aria-pressed 双态按钮，图标与文案同步切换。
- 滚动入场：IntersectionObserver 渐显；减少动态偏好下直接显示。


五、nginx 部署（Windows / Linux 通用）
--------------------------------------------------------------------
1) 将整个 04-video 目录放到站点根目录，例如：
   Linux:   /var/www/frame
   Windows: D:\www\frame

2) 站点配置（/etc/nginx/conf.d/frame.conf 或 nginx.conf 的 http {} 内）：

   server {
       listen       80;
       server_name  frame.example.com;
       root         /var/www/frame;          # Windows 用 D:/www/frame;
       index        index.html;

       charset utf-8;
       add_header X-Content-Type-Options nosniff;
       add_header Referrer-Policy no-referrer-when-downgrade;

       # 静态资源长缓存（文件名不变时按需调整版本号）
       location ~* \.(?:css|js|webp|svg|woff2)$ {
           expires 30d;
           add_header Cache-Control "public, max-age=2592000, immutable";
           try_files $uri =404;
       }

       # 单页：其余路径回落到首页
       location / {
           try_files $uri $uri/ /index.html;
       }

       # 图片不记录访问日志（可选）
       location ~* \.(?:webp|svg)$ {
           access_log off;
           expires 30d;
       }

       gzip on;
       gzip_types text/css application/javascript image/svg+xml;
       gzip_min_length 1024;
   }

3) 检查并重载：
   nginx -t
   nginx -s reload        # Linux 也可用 systemctl reload nginx

4) 访问：
   http://frame.example.com/   或   http://<服务器 IP>/

Windows 本地快速预览（无 nginx 时）：
   - 直接双击 index.html 用浏览器打开（file:// 协议，表现一致）；
   - 或在 04-video 目录执行 python -m http.server 8080，
     然后访问 http://127.0.0.1:8080/ 。


六、兼容性与约束
--------------------------------------------------------------------
- 目标浏览器：Chrome / Edge 120+、Safari 17.4+、Firefox 121+。
- 零外部依赖：无 CDN、无网络字体、无第三方库，图标全部为内联 SVG；
  仅使用系统字体栈（system-ui / PingFang SC / Microsoft YaHei 等）。
- CSS 特性：@layer、自定义属性、clamp()、oklch()、color-mix()、:has()、
  @container、dvh、text-wrap: balance / pretty、aspect-ratio、
  :focus-visible、prefers-reduced-motion（含 prefers-contrast 加强）。
- 可访问性：单一 h1、skip-link、语义化分区、所有图片有 alt、
  按钮有可读文本或 aria-label、焦点环清晰、无内联事件属性。
- 响应式：移动优先，断点 640 / 900 / 1200 px；320 px 宽度无横向滚动，
  宽屏由 max-width: 1320px 容器约束。

© 2026 FRAME 帧间影院（演示站点）
