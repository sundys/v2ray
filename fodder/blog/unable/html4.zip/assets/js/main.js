/* ==========================================================================
   FRAME 帧间影院 — 交互脚本
   纯静态演示：数据内置、零网络请求；所有交互用 addEventListener 绑定
   ========================================================================== */
"use strict";

(function () {
  /* ==================== 1. 公共工具 ==================== */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
  const reduceMotion = () => motionQuery.matches;
  const scrollBehavior = () => (reduceMotion() ? "auto" : "smooth");

  function pad(n) {
    return String(n).padStart(2, "0");
  }

  /* 秒 → 时:分:秒 */
  function fmtTime(total) {
    const s = Math.max(0, Math.round(total));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return h > 0 ? h + ":" + pad(m) + ":" + pad(sec) : pad(m) + ":" + pad(sec);
  }

  /* ==================== 2. 主推轮播 ==================== */
  /* 自动播放 + 圆点/箭头切换 + 方向键 + hover 暂停 + 减少动态时停播 */
  function initCarousel() {
    const stage = $("[data-carousel]");
    if (!stage) return;

    const slides = $$("[data-slide]", stage);
    const dots = $$("[data-carousel-dot]", stage);
    const prevBtn = $("[data-carousel-prev]", stage);
    const nextBtn = $("[data-carousel-next]", stage);
    const indexEl = $("[data-carousel-index]", stage);
    const liveEl = $("[data-carousel-live]", stage);
    const track = $(".stage__track", stage);
    const total = slides.length;
    const INTERVAL = 6500;

    const names = slides.map((s) => {
      const t = $(".stage__title", s);
      return t ? t.textContent.trim() : "";
    });

    let index = 0;
    let timer = 0;
    let paused = false;

    function render(announce) {
      slides.forEach((s, i) => s.classList.toggle("is-active", i === index));
      dots.forEach((d, i) => {
        const on = i === index;
        d.classList.toggle("is-active", on);
        if (on) d.setAttribute("aria-current", "true");
        else d.removeAttribute("aria-current");
      });
      if (indexEl) indexEl.textContent = pad(index + 1);
      if (announce && liveEl) {
        liveEl.textContent = "第 " + (index + 1) + " 部，共 " + total + " 部：" + names[index];
      }
    }

    function go(i, announce) {
      index = (i + total) % total;
      render(announce !== false);
      restart();
    }

    function stopTimer() {
      window.clearInterval(timer);
      timer = 0;
    }

    function restart() {
      stopTimer();
      if (paused || reduceMotion() || document.hidden) return;
      timer = window.setInterval(() => {
        index = (index + 1) % total;
        render(true);
      }, INTERVAL);
    }

    prevBtn?.addEventListener("click", () => go(index - 1));
    nextBtn?.addEventListener("click", () => go(index + 1));

    dots.forEach((dot, i) => {
      dot.addEventListener("click", () => {
        if (i === index) return;
        go(i);
      });
    });

    stage.addEventListener("keydown", (e) => {
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        go(index - 1);
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        go(index + 1);
      } else if (e.key === "Home") {
        e.preventDefault();
        go(0);
      } else if (e.key === "End") {
        e.preventDefault();
        go(total - 1);
      }
    });

    stage.addEventListener("pointerenter", () => {
      paused = true;
      stopTimer();
    });

    stage.addEventListener("pointerleave", () => {
      paused = false;
      restart();
    });

    stage.addEventListener("focusin", () => {
      paused = true;
      stopTimer();
    });

    stage.addEventListener("focusout", (e) => {
      if (stage.contains(e.relatedTarget)) return;
      paused = false;
      restart();
    });

    /* 触屏横向滑动 */
    if (track) {
      let startX = 0;
      let startY = 0;
      let tracking = false;

      track.addEventListener("pointerdown", (e) => {
        if (e.pointerType === "mouse") return;
        tracking = true;
        startX = e.clientX;
        startY = e.clientY;
      });

      track.addEventListener("pointerup", (e) => {
        if (!tracking) return;
        tracking = false;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) {
          go(index + (dx < 0 ? 1 : -1));
        }
      });

      track.addEventListener("pointercancel", () => {
        tracking = false;
      });
    }

    document.addEventListener("visibilitychange", () => {
      if (document.hidden) stopTimer();
      else restart();
    });

    motionQuery.addEventListener("change", () => {
      if (reduceMotion()) stopTimer();
      else restart();
    });

    render(false);
    restart();
  }

  /* ==================== 3. 分类筛选 + 搜索 ==================== */
  /* tab 过滤网格，切换时逐张淡入；搜索按片名/导演/类型匹配 */
  function initFilters() {
    const grid = $("#grid-list");
    if (!grid) return;

    const tabs = $$("[data-cat]");
    const input = $("#gridSearch");
    const countEl = $("[data-count]");
    const emptyEl = $("[data-empty]");
    const tiles = $$(".tile", grid);

    let cat = "all";
    let query = "";

    function matches(tile) {
      const okCat = cat === "all" || tile.dataset.cat === cat;
      if (!okCat) return false;
      if (!query) return true;
      const hay = (tile.dataset.search || "") + " " + tile.textContent;
      return hay.toLowerCase().includes(query);
    }

    function apply() {
      let shown = 0;
      tiles.forEach((tile) => {
        const show = matches(tile);
        tile.classList.remove("is-in");
        tile.hidden = !show;
        if (!show) return;
        shown += 1;
        /* 重排一次以重启入场动画 */
        void tile.offsetWidth;
        tile.style.animationDelay = Math.min(shown, 12) * 26 + "ms";
        tile.classList.add("is-in");
      });

      if (countEl) countEl.textContent = "共 " + shown + " 部作品";
      if (emptyEl) emptyEl.hidden = shown > 0;
    }

    tabs.forEach((tab) => {
      tab.addEventListener("click", () => {
        cat = tab.dataset.cat || "all";
        tabs.forEach((t) => t.setAttribute("aria-pressed", String(t === tab)));
        apply();
      });
    });

    /* tab 组内方向键移动并激活 */
    const tablist = $(".tabs");
    tablist?.addEventListener("keydown", (e) => {
      if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
      const i = tabs.indexOf(document.activeElement);
      if (i < 0) return;
      e.preventDefault();
      const next = tabs[(i + (e.key === "ArrowRight" ? 1 : -1) + tabs.length) % tabs.length];
      next.focus();
      next.click();
    });

    input?.addEventListener("input", () => {
      query = input.value.trim().toLowerCase();
      apply();
    });

    apply();
  }

  /* ==================== 4. 横向剧集行 ==================== */
  /* 按钮滚动 + 鼠标拖拽 + 方向键；到达两端时禁用对应按钮 */
  function initRail() {
    const rail = $("[data-rail]");
    if (!rail) return;

    const scroller = $("[data-rail-scroller]", rail);
    const prevBtn = $("[data-rail-prev]", rail);
    const nextBtn = $("[data-rail-next]", rail);
    if (!scroller) return;

    let rafId = 0;

    function update() {
      const max = scroller.scrollWidth - scroller.clientWidth - 2;
      if (prevBtn) prevBtn.disabled = scroller.scrollLeft <= 2;
      if (nextBtn) nextBtn.disabled = scroller.scrollLeft >= max;
    }

    function queueUpdate() {
      if (rafId) return;
      rafId = window.requestAnimationFrame(() => {
        rafId = 0;
        update();
      });
    }

    function step() {
      return Math.max(240, Math.round(scroller.clientWidth * 0.8));
    }

    /* 兼容不支持 scrollBy 选项对象的环境，退回直接设置 scrollLeft */
    function scrollByX(delta) {
      if (typeof scroller.scrollBy === "function") {
        scroller.scrollBy({ left: delta, behavior: scrollBehavior() });
      } else {
        scroller.scrollLeft += delta;
      }
    }

    function scrollToX(left) {
      if (typeof scroller.scrollTo === "function") {
        scroller.scrollTo({ left, behavior: scrollBehavior() });
      } else {
        scroller.scrollLeft = left;
      }
    }

    prevBtn?.addEventListener("click", () => scrollByX(-step()));
    nextBtn?.addEventListener("click", () => scrollByX(step()));

    scroller.addEventListener("scroll", queueUpdate, { passive: true });
    window.addEventListener("resize", queueUpdate);

    scroller.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
        e.preventDefault();
        const dir = e.key === "ArrowRight" ? 1 : -1;
        scrollByX(dir * Math.round(scroller.clientWidth * 0.6));
      } else if (e.key === "Home") {
        e.preventDefault();
        scrollToX(0);
      } else if (e.key === "End") {
        e.preventDefault();
        scrollToX(scroller.scrollWidth);
      }
    });

    /* 鼠标拖拽（触屏保留原生惯性滚动） */
    let dragging = false;
    let dragged = false;
    let startX = 0;
    let startLeft = 0;

    scroller.addEventListener("pointerdown", (e) => {
      if (e.pointerType !== "mouse" || e.button !== 0) return;
      dragging = true;
      dragged = false;
      startX = e.clientX;
      startLeft = scroller.scrollLeft;
      scroller.classList.add("is-dragging");
    });

    scroller.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const dx = e.clientX - startX;
      if (Math.abs(dx) > 4) dragged = true;
      if (dragged) scroller.scrollLeft = startLeft - dx;
    });

    function endDrag() {
      if (!dragging) return;
      dragging = false;
      scroller.classList.remove("is-dragging");
    }

    scroller.addEventListener("pointerup", endDrag);
    scroller.addEventListener("pointercancel", endDrag);
    scroller.addEventListener("pointerleave", endDrag);

    /* 拖拽结束后不要误触卡片按钮 */
    scroller.addEventListener("click", (e) => {
      if (!dragged) return;
      e.preventDefault();
      e.stopPropagation();
      dragged = false;
    }, true);

    scroller.addEventListener("dragstart", (e) => e.preventDefault());

    update();
  }

  /* ==================== 5. 模拟播放器 ==================== */
  /* 弹窗播放器：播放/暂停、进度条推进（8 倍速演示）、时长格式化 */
  function initPlayer() {
    const dialog = $("#player");
    if (!dialog) return;

    const titleEl = $("#playerTitle");
    const metaEl = $("[data-player-meta]", dialog);
    const imgEl = $("[data-player-img]", dialog);
    const toggle = $("[data-player-toggle]", dialog);
    const fill = $("[data-player-fill]", dialog);
    const currentEl = $("[data-player-current]", dialog);
    const totalEl = $("[data-player-total]", dialog);
    const closeBtn = $("[data-player-close]", dialog);

    let duration = 7680;
    let elapsed = 0;
    let playing = false;
    let rafId = 0;
    let last = 0;

    function paint() {
      const ratio = duration > 0 ? Math.min(1, elapsed / duration) : 0;
      if (fill) fill.style.width = (ratio * 100).toFixed(2) + "%";
      if (currentEl) currentEl.textContent = fmtTime(elapsed);
    }

    function tick(now) {
      if (!playing) return;
      if (!last) last = now;
      const dt = Math.min(0.5, (now - last) / 1000);
      last = now;
      elapsed = Math.min(duration, elapsed + dt * 8);
      paint();
      if (elapsed >= duration) {
        setPlaying(false);
        return;
      }
      rafId = window.requestAnimationFrame(tick);
    }

    function setPlaying(on) {
      playing = on;
      last = 0;
      window.cancelAnimationFrame(rafId);
      const use = toggle ? toggle.querySelector("use") : null;
      if (use) use.setAttribute("href", on ? "#i-pause" : "#i-play");
      if (toggle) toggle.setAttribute("aria-label", on ? "暂停" : "播放");
      if (on) rafId = window.requestAnimationFrame(tick);
    }

    function openPlayer(cfg) {
      if (titleEl) titleEl.textContent = cfg.title;
      if (metaEl) metaEl.textContent = cfg.meta;
      if (imgEl && cfg.img) {
        imgEl.setAttribute("src", cfg.img);
        imgEl.setAttribute("alt", "《" + cfg.title + "》画面");
      }
      duration = Math.max(60, cfg.dur || 600);
      elapsed = 0;
      if (totalEl) totalEl.textContent = fmtTime(duration);
      paint();
      setPlaying(true);
      if (typeof dialog.showModal === "function") dialog.showModal();
      else dialog.setAttribute("open", "");
      if (toggle) toggle.focus();
    }

    document.addEventListener("click", (e) => {
      const trigger = e.target.closest("[data-play-title]");
      if (!trigger) return;
      const holder = trigger.closest(".tile, .episode, .stage__slide");
      const img = holder ? holder.querySelector("img") : null;
      openPlayer({
        title: trigger.dataset.playTitle,
        meta: trigger.dataset.playMeta || "",
        dur: Number(trigger.dataset.playDur) || 600,
        img: img ? img.getAttribute("src") : ""
      });
    });

    closeBtn?.addEventListener("click", () => {
      if (typeof dialog.close === "function") dialog.close();
      else dialog.removeAttribute("open");
    });

    dialog.addEventListener("click", (e) => {
      if (e.target === dialog) dialog.close();
    });

    dialog.addEventListener("close", () => setPlaying(false));

    toggle?.addEventListener("click", () => {
      if (elapsed >= duration) elapsed = 0;
      setPlaying(!playing);
    });
  }

  /* ==================== 6. 片单与关注 ==================== */
  /* aria-pressed 双态按钮：片单收藏、创作者关注 */
  function initToggles() {
    document.addEventListener("click", (e) => {
      const bookmark = e.target.closest("[data-bookmark]");
      if (bookmark) {
        const on = bookmark.getAttribute("aria-pressed") === "true";
        bookmark.setAttribute("aria-pressed", String(!on));
        const label = bookmark.querySelector("span");
        if (label) label.textContent = on ? "加入片单" : "已加入片单";
        const use = bookmark.querySelector("use");
        if (use) use.setAttribute("href", on ? "#i-plus" : "#i-check");
        return;
      }

      const follow = e.target.closest("[data-follow]");
      if (follow) {
        const on = follow.getAttribute("aria-pressed") === "true";
        follow.setAttribute("aria-pressed", String(!on));
        const label = follow.querySelector("span");
        if (label) label.textContent = on ? "关注" : "已关注";
        const use = follow.querySelector("use");
        if (use) use.setAttribute("href", on ? "#i-plus" : "#i-check");
      }
    });
  }

  /* ==================== 7. 滚动入场 ==================== */
  /* IntersectionObserver 逐块淡入；减少动态时直接显示 */
  function initReveal() {
    const targets = $$(".sec-head, .toolbar, .rail__head, .creator, .quote, .review");
    if (!targets.length) return;

    if (reduceMotion() || !("IntersectionObserver" in window)) return;

    targets.forEach((el, i) => {
      el.classList.add("fade-up");
      el.style.setProperty("--d", Math.min(i % 6, 5) * 55 + "ms");
    });

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add("is-in");
          io.unobserve(entry.target);
        });
      },
      { rootMargin: "0px 0px -6% 0px", threshold: 0.08 }
    );

    targets.forEach((el) => io.observe(el));
  }

  /* ==================== 8. 顶栏状态 ==================== */
  /* rAF 节流的滚动监听：滚动后给顶栏加投影 */
  function initHeader() {
    const header = $(".site-head");
    if (!header) return;

    let ticking = false;

    function sync() {
      ticking = false;
      header.classList.toggle("is-stuck", window.scrollY > 10);
    }

    window.addEventListener("scroll", () => {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(sync);
    }, { passive: true });

    sync();
  }

  /* ==================== 9. 启动 ==================== */
  function init() {
    initCarousel();
    initFilters();
    initRail();
    initPlayer();
    initToggles();
    initReveal();
    initHeader();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
