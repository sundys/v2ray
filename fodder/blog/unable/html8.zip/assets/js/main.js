/* ==========================================================================
   TRANSIT 城市交通信息台 — 交互脚本
   纯静态演示：路况数据内置，无任何网络请求
   ========================================================================== */
"use strict";

(function () {
  /* ==================== 1. 数据（虚构样本） ==================== */
  /* speed：当前平均车速 km/h；off：拥堵指数的个体偏移；trend：与 1 小时前相比的车速变化 */
  const SEGMENTS = [
    { id: "s1", name: "中山路高架", dir: "北向", len: 4.2, speed: 18, off: 0.6, trend: -2.4, note: "两车追尾，占用 1 条车道" },
    { id: "s2", name: "环城北路", dir: "东向", len: 5.8, speed: 26, off: -0.5, trend: -1.1, note: "商圈出入口排队，信号配时延长" },
    { id: "s3", name: "德胜快速路", dir: "双向", len: 7.4, speed: 58, off: 0.2, trend: 0.8, note: "通行顺畅，无限速调整" },
    { id: "s4", name: "天目山路", dir: "西向", len: 3.9, speed: 24, off: -0.1, trend: -1.6, note: "沿线两处施工围挡，车道收窄" },
    { id: "s5", name: "庆春路", dir: "东向", len: 2.6, speed: 14, off: 0.7, trend: -3.2, note: "商圈路口禁止左转，绕行车辆增多" },
    { id: "s6", name: "秋涛路", dir: "南向", len: 6.1, speed: 46, off: -0.3, trend: 0.5, note: "高架匝道分流正常" },
    { id: "s7", name: "文一西路", dir: "西向", len: 8.3, speed: 52, off: -0.06, trend: 1.2, note: "绿波带生效，停车次数减少" },
    { id: "s8", name: "时代大道", dir: "南向", len: 5.2, speed: 16, off: 0.6, trend: -2.8, note: "路面修补占用最外侧车道" },
    { id: "s9", name: "之江路", dir: "东向", len: 4.7, speed: 28, off: -0.4, trend: -0.9, note: "积水已排除，车速逐步恢复" },
    { id: "s10", name: "留石高架", dir: "双向", len: 6.9, speed: 61, off: 0.35, trend: 1.6, note: "通行顺畅，货车比例较低" }
  ];

  const LEVELS = {
    ok: { label: "畅通", cls: "ok" },
    slow: { label: "缓行", cls: "slow" },
    jam: { label: "拥堵", cls: "jam" }
  };

  const state = {
    segs: SEGMENTS.map(function (s) { return Object.assign({}, s); }),
    filter: "all",
    sort: "index",
    reduceMotion: window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    busy: false
  };

  /* ==================== 2. 工具 ==================== */
  const $ = function (sel, root) { return (root || document).querySelector(sel); };
  const $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  const clamp = function (v, min, max) { return Math.min(max, Math.max(min, v)); };
  const pad = function (n) { return String(n).padStart(2, "0"); };
  const fmt1 = function (n) { return n.toFixed(1); };

  function levelOf(speed) {
    return speed >= 40 ? "ok" : speed >= 20 ? "slow" : "jam";
  }

  function indexOf(seg) {
    return Math.round(clamp(10.4 - seg.speed * 0.145 + seg.off, 0.8, 9.8) * 10) / 10;
  }

  function localStamp(date, withSeconds) {
    const d = date;
    const base = d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) +
      "T" + pad(d.getHours()) + ":" + pad(d.getMinutes());
    return withSeconds ? base + ":" + pad(d.getSeconds()) : base;
  }

  /* ==================== 3. 顶部时间与更新时间 ==================== */
  function initClock() {
    const clock = $("#clock");
    const upd = $("#updTime");
    const lead = $("#leadTime");

    function tick() {
      const now = new Date();
      clock.textContent = pad(now.getHours()) + ":" + pad(now.getMinutes()) + ":" + pad(now.getSeconds());
      clock.setAttribute("datetime", localStamp(now, true));
    }

    function stamp() {
      const now = new Date();
      const text = pad(now.getHours()) + ":" + pad(now.getMinutes());
      upd.textContent = text;
      upd.setAttribute("datetime", localStamp(now, false));
      lead.textContent = text;
      lead.setAttribute("datetime", localStamp(now, false));
    }

    tick();
    stamp();
    setInterval(tick, 1000);
    return stamp;
  }

  /* ==================== 4. 总览：环形指数 + KPI ==================== */
  function renderSummary() {
    const segs = state.segs;
    const total = segs.reduce(function (sum, s) { return sum + indexOf(s); }, 0);
    const avgIndex = Math.round((total / segs.length) * 10) / 10;
    const level = avgIndex >= 7 ? "jam" : avgIndex >= 4 ? "slow" : "ok";

    const arc = $("#ringArc");
    const len = 415;
    arc.setAttribute("stroke-dasharray", fmt1((len * avgIndex) / 10) + " " + len);
    arc.setAttribute("class", "ring__arc ring__arc--" + level);
    arc.style.stroke = "var(--c-" + level + ")";

    $("#ringVal").textContent = fmt1(avgIndex);
    $("#ringLv").textContent = LEVELS[level].label;
    $("#ringLv").style.color = "var(--c-" + level + ")";
    $("#ringTitle").textContent = "全路网拥堵指数 " + fmt1(avgIndex) + "，处于" + LEVELS[level].label + "区间";

    const counts = { ok: 0, slow: 0, jam: 0 };
    segs.forEach(function (s) { counts[levelOf(s.speed)] += 1; });
    $("#cntOk").textContent = counts.ok;
    $("#cntSlow").textContent = counts.slow;
    $("#cntJam").textContent = counts.jam;

    const avgSpeed = segs.reduce(function (sum, s) { return sum + s.speed; }, 0) / segs.length;
    const fastIds = ["s1", "s3", "s6", "s8", "s10"];
    const fast = segs.filter(function (s) { return fastIds.indexOf(s.id) >= 0; });
    const fastAvg = fast.reduce(function (sum, s) { return sum + s.speed; }, 0) / fast.length;
    const jamKm = segs.reduce(function (sum, s) {
      return sum + (levelOf(s.speed) === "jam" ? s.len : 0);
    }, 0);

    $("#kSpeed").textContent = fmt1(avgSpeed);
    $("#kFast").textContent = fmt1(fastAvg);
    $("#kJamKm").textContent = fmt1(jamKm);
    $("#kEvents").textContent = 5 + counts.jam;

    return avgIndex;
  }

  /* ==================== 5. 路网图着色与提示 ==================== */
  function renderMap() {
    state.segs.forEach(function (seg) {
      const g = document.querySelector('.seg[data-seg="' + seg.id + '"]');
      if (!g) return;
      const level = levelOf(seg.speed);
      g.setAttribute("data-level", level);
      g.setAttribute("aria-label",
        seg.name + "，" + LEVELS[level].label + "，平均车速 " + seg.speed + " 公里每小时");
    });
  }

  function initMapTips() {
    const canvas = $("#mapCanvas");
    const tip = $("#mapTip");
    if (!canvas || !tip) return;

    const nameEl = $("#tipName");
    const lvEl = $("#tipLv");
    const speedEl = $("#tipSpeed");
    const noteEl = $("#tipNote");

    function show(g) {
      const seg = state.segs.find(function (s) { return s.id === g.dataset.seg; });
      if (!seg) return;
      const level = levelOf(seg.speed);
      nameEl.textContent = seg.name;
      lvEl.textContent = LEVELS[level].label;
      lvEl.style.color = "var(--c-" + level + ")";
      speedEl.textContent = seg.speed;
      noteEl.textContent = seg.note;

      const host = canvas.getBoundingClientRect();
      const rect = g.getBoundingClientRect();
      const left = clamp(rect.left - host.left + rect.width / 2, 86, host.width - 86);
      const top = clamp(rect.top - host.top + rect.height / 2, 78, host.height - 8);
      tip.style.left = left + "px";
      tip.style.top = top + "px";
      tip.hidden = false;
    }

    function hide() {
      tip.hidden = true;
    }

    $$(".seg", canvas).forEach(function (g) {
      g.addEventListener("pointerenter", function () { show(g); });
      g.addEventListener("pointerleave", hide);
      g.addEventListener("focus", function () { show(g); });
      g.addEventListener("blur", hide);
      g.addEventListener("keydown", function (e) {
        if (e.key === "Escape") { hide(); g.blur(); }
      });
    });

    canvas.addEventListener("pointerleave", hide);
    window.addEventListener("scroll", hide, { passive: true });
  }

  /* ==================== 6. 路段卡片：筛选 / 排序 / 渲染 ==================== */
  function visibleSegs() {
    const list = state.segs.filter(function (s) {
      return state.filter === "all" || levelOf(s.speed) === state.filter;
    });
    list.sort(function (a, b) {
      return state.sort === "index" ? indexOf(b) - indexOf(a) : a.speed - b.speed;
    });
    return list;
  }

  function cardMarkup(seg) {
    const level = levelOf(seg.speed);
    const idx = indexOf(seg);
    const dash = fmt1((125.7 * idx) / 10);
    const flat = Math.abs(seg.trend) < 0.05;
    const dirIcon = flat ? "#i-gauge" : seg.trend > 0 ? "#i-up" : "#i-down";
    const dirCls = flat ? "" : seg.trend > 0 ? "road__trend--up" : "road__trend--down";
    const trendText = flat ? "持平" : (seg.trend > 0 ? "+" : "−") + fmt1(Math.abs(seg.trend));
    return '' +
      '<div class="road__ring">' +
        '<svg viewBox="0 0 46 46" aria-hidden="true">' +
          '<circle class="ring__track" cx="23" cy="23" r="20"/>' +
          '<circle class="ring__arc" cx="23" cy="23" r="20" stroke-dasharray="' + dash + ' 125.7" transform="rotate(-90 23 23)"/>' +
        '</svg>' +
        '<span class="ring__val">' + fmt1(idx) + '</span>' +
      '</div>' +
      '<div class="road__body">' +
        '<h3 class="road__name">' + seg.name +
          '<span class="pill pill--' + level + '">' + LEVELS[level].label + '</span>' +
        '</h3>' +
        '<p class="road__meta">' + seg.dir + ' · ' + fmt1(seg.len) + ' km · 均速 <b>' + seg.speed + '</b> km/h</p>' +
        '<p class="road__note">' + seg.note + '</p>' +
      '</div>' +
      '<p class="road__trend ' + dirCls + '">' +
        '<svg class="ico" aria-hidden="true"><use href="' + dirIcon + '"/></svg>' +
        '<span class="sr-only">较 1 小时前</span>' + trendText +
      '</p>';
  }

  function renderBoard() {
    const list = $("#roadList");
    const items = visibleSegs();
    const total = state.segs.length;

    list.innerHTML = items.map(function (seg) {
      return '<li class="road is-new" data-seg="' + seg.id + '" data-level="' + levelOf(seg.speed) + '">' +
        cardMarkup(seg) + '</li>';
    }).join("");

    if (!items.length) {
      list.innerHTML = '<li class="road"><p class="road__note">当前筛选条件下没有路段，请切换到「全部」。</p></li>';
    }

    $("#roadCount").textContent = items.length + " 条";
    const sortText = state.sort === "index" ? "按拥堵指数由高到低排列" : "按平均车速由低到高排列";
    $("#boardFoot").textContent = "共 " + total + " 条监测路段 · 显示 " + items.length + " 条 · " + sortText;

    if (state.reduceMotion) {
      $$(".road.is-new", list).forEach(function (el) { el.classList.remove("is-new"); });
    }
  }

  function initFilters() {
    const filterBtns = $$("[data-filter]");
    const sortBtns = $$("[data-sort]");

    filterBtns.forEach(function (btn) {
      btn.addEventListener("click", function () {
        state.filter = btn.dataset.filter;
        filterBtns.forEach(function (b) {
          b.setAttribute("aria-pressed", b === btn ? "true" : "false");
        });
        renderBoard();
      });
    });

    sortBtns.forEach(function (btn) {
      btn.addEventListener("click", function () {
        state.sort = btn.dataset.sort;
        sortBtns.forEach(function (b) {
          b.setAttribute("aria-pressed", b === btn ? "true" : "false");
        });
        renderBoard();
      });
    });
  }

  /* ==================== 7. 刷新：模拟一次数据更新 ==================== */
  function announce(text) {
    const live = $("#liveMsg");
    live.textContent = "";
    window.setTimeout(function () { live.textContent = text; }, 60);
  }

  function initRefresh(stamp) {
    const btn = $("#refreshBtn");

    btn.addEventListener("click", function () {
      if (state.busy) return;
      state.busy = true;
      btn.disabled = true;
      btn.classList.add("is-spinning");

      state.segs.forEach(function (seg) {
        const before = seg.speed;
        const delta = Math.round((Math.random() - 0.5) * 9);
        seg.speed = clamp(before + delta, 8, 74);
        seg.trend = Math.round((seg.speed - before) * 10) / 10;
      });

      const avgIndex = renderSummary();
      renderMap();
      renderBoard();
      stamp();

      window.setTimeout(function () {
        btn.disabled = false;
        btn.classList.remove("is-spinning");
        state.busy = false;
        announce("已更新，当前全路网拥堵指数 " + fmt1(avgIndex));
      }, 400);
    });
  }

  /* ==================== 8. 时刻表 tab 切换 ==================== */
  function initTabs() {
    const tabs = $$('[role="tab"]');
    const panels = tabs.map(function (t) { return document.getElementById(t.getAttribute("aria-controls")); });

    function select(index) {
      tabs.forEach(function (tab, i) {
        const on = i === index;
        tab.setAttribute("aria-selected", on ? "true" : "false");
        tab.tabIndex = on ? 0 : -1;
        tab.classList.toggle("is-active", on);
        if (panels[i]) panels[i].hidden = !on;
      });
    }

    tabs.forEach(function (tab, i) {
      tab.addEventListener("click", function () { select(i); });
      tab.addEventListener("keydown", function (e) {
        let next = -1;
        if (e.key === "ArrowRight") next = (i + 1) % tabs.length;
        else if (e.key === "ArrowLeft") next = (i - 1 + tabs.length) % tabs.length;
        else if (e.key === "Home") next = 0;
        else if (e.key === "End") next = tabs.length - 1;
        if (next < 0) return;
        e.preventDefault();
        select(next);
        tabs[next].focus();
      });
    });
  }

  /* ==================== 9. 滚动入场 ==================== */
  function initReveal() {
    const items = $$(".advice__card, .gallery__item, .events, .tabs, .metro");
    if (state.reduceMotion || !("IntersectionObserver" in window)) return;

    items.forEach(function (el) { el.classList.add("fade-up"); });

    const io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.classList.add("is-in");
          io.unobserve(en.target);
        }
      });
    }, { rootMargin: "0px 0px -6% 0px", threshold: 0.08 });

    items.forEach(function (el) { io.observe(el); });
  }

  /* ==================== 10. 启动 ==================== */
  function init() {
    const stamp = initClock();
    renderSummary();
    renderMap();
    renderBoard();
    initMapTips();
    initFilters();
    initRefresh(stamp);
    initTabs();
    initReveal();

    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = function (e) { state.reduceMotion = e.matches; };
    if (typeof mq.addEventListener === "function") mq.addEventListener("change", onChange);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
