TRANSIT · 城市交通信息台（08-traffic）
=====================================
纯静态单页站点：深蓝灰控制台 + 信号黄的城市交通信息主页。
零外部依赖（无 CDN、无网络字体、无第三方库、无 fetch 请求），双击 index.html
用 file:// 打开或在 nginx 下访问，表现一致。

一、文件清单
------------
08-traffic/
├── index.html                 页面结构（语义标签、内联 SVG 图标与路网图）
├── favicon.svg                站点图标（内联绘制，无外链）
├── README.txt                 本说明
└── assets/
    ├── css/style.css          单文件样式表，@layer 分层
    ├── js/main.js             单文件经典脚本（defer 加载）
    └── img/
        ├── road-night.webp    路况实拍：夜间城市道路车流（辅助视觉）
        ├── road-peak.webp     路况实拍：高峰时段路口排队（辅助视觉）
        └── transit-hub.webp   路况实拍：公共交通枢纽候车场景（辅助视觉）

主视觉全部由 CSS 与内联 SVG 完成（路网示意图、地铁线网图、环形拥堵指数），
图片仅作辅助影像，不承载关键信息。

二、页面区块
------------
1. 顶部状态条：站点标识、城市、实时时钟、天气提示、刷新按钮、更新时间、主导航
2. 运行总览：h1 标题、态势摘要、5 项 KPI、全路网拥堵指数环形进度与三级统计
3. 实时路况：左侧 SVG 路网示意图（10 条路段按拥堵等级着色 + 拥堵段呼吸动画
   + 悬停/聚焦提示），右侧路段明细卡片（环形指数、筛选与排序）
4. 地铁线网：3 条线路示意图、站点圆点、两座换乘站、首末班与行车间隔
5. 时刻表：航班 / 高铁 / 地铁三个 tab，表格 + 状态胶囊标签
6. 出行建议与路网事件：6 条建议卡片 + 实时事件时间线
7. 路况实拍：3 张现场影像（loading="lazy"）
8. 数据说明与页脚：口径说明、监测参数、栏目导航、备案号

三、交互说明
------------
- 刷新路况：重新模拟 10 条路段的车速与拥堵指数，路网颜色、卡片、环形进度
  以约 400ms 过渡同步更新，并通过 aria-live="polite" 播报
  “已更新，当前全路网拥堵指数 X”。
- 筛选 / 排序：全部 / 畅通 / 缓行 / 拥堵（aria-pressed 单选组），
  以及按拥堵指数、按平均车速两种排序。
- 时刻表 tab：点击或使用 ←/→/Home/End 键切换，遵循 role="tab" 键盘模型。
- 路网提示：路段 <g tabindex="0"> 可键盘聚焦，悬停或聚焦显示路段名、
  拥堵等级、平均车速与事件说明；Esc 关闭。
- 无脚本时页面仍可阅读：路网图、地铁图、时刻表、建议与图片均为静态 HTML。

四、技术要点
------------
- CSS：@layer reset/tokens/base/layout/components/utilities、自定义属性、
  clamp()、oklch()、color-mix()、:has() 语义选择、容器查询（.board）、dvh 视口、
  :focus-visible 焦点环、prefers-reduced-motion 与 prefers-contrast 降级。
- 响应式：移动优先，断点 640 / 900 / 1200px；320px 宽无横向滚动；
  SVG 使用 viewBox 自适应；表格在窄屏内横向滚动，不撑破页面。
- 可访问性：skip-link、单一 h1、所有图片有 alt、按钮有可读文本、
  无内联事件属性、数值使用等宽数字、状态用文字 + 颜色双重编码。
- 性能：无外部请求，图片显式宽高 + lazy 解码，动画仅使用 opacity/transform。

五、本地预览
------------
方式一（推荐）：直接双击 index.html，浏览器以 file:// 打开。
方式二：启动任意静态服务器，例如：

    npx serve 08-traffic
    # 或
    python -m http.server 8080 --directory 08-traffic

然后访问 http://localhost:8080/ 。

六、nginx 部署
--------------
把 08-traffic 目录整体上传到站点根目录，例如 /var/www/transit，然后：

    server {
        listen       80;
        server_name  transit.example.com;

        root  /var/www/transit;
        index index.html;

        charset utf-8;

        # 单页：所有路径回落到 index.html
        location / {
            try_files $uri $uri/ /index.html;
        }

        # 静态资源长缓存（文件名稳定，可按需加版本号）
        location ~* \.(css|js|svg|webp)$ {
            expires 30d;
            add_header Cache-Control "public, max-age=2592000, immutable";
            access_log off;
        }

        # HTML 不做长缓存，便于更新
        location = /index.html {
            add_header Cache-Control "no-cache";
        }

        gzip on;
        gzip_types text/css application/javascript image/svg+xml text/plain;
        gzip_min_length 1024;
    }

若部署在子路径（如 https://example.com/traffic/），本页面使用相对路径，
无需修改任何代码即可直接访问。

七、声明
--------
本站为演示站点：路况、拥堵指数、航班号、车次、站台、延误时间与事件均为
虚构数据，仅用于版式与交互演示，不可用于实际出行决策。
