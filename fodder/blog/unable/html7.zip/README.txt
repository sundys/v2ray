ORBIT 行情终端 · 静态站点说明
================================================

一、站点定位
------------------------------------------------
ORBIT 是一个纯静态的金融资讯 / 行情仪表盘主页，深色数据终端风格，
荧光绿表示上涨、珊瑚红表示下跌，涨跌同时用 ▲ ▼ 符号标注，保证色觉障碍用户也能区分。
所有指数点位、个股与币种报价、成交额、板块涨跌、机构观点、宏观数据与财经日历
均为内置的虚构演示样本，不连接任何接口，不构成任何投资建议。

二、文件清单
------------------------------------------------
index.html                 单页结构：顶栏、滚动行情条、大盘指数、自选行情、
                           板块热力、资讯流、宏观指标、财经日历、页脚
favicon.svg                站点图标（轨道 + 荧光点）
README.txt                 本说明文件
assets/css/style.css       单文件样式表，@layer 分层：
                           reset → tokens → base → layout → components → utilities
assets/js/main.js          单文件交互脚本（经典脚本，defer 加载，无 import/export）
assets/img/market-floor.webp   资讯头条配图（交易大厅）
assets/img/trading-desk.webp   资讯缩略图（交易终端）
assets/img/data-screens.webp   资讯缩略图（数据屏幕）
assets/img/city-skyline.webp   资讯缩略图（城市天际线）

三、交互功能
------------------------------------------------
1. 行情随机游走：每 3 秒对所有指数、自选报价与滚动行情条做小幅波动
   （单次幅度 ≤ 0.06%，并限制在昨收 ±4% 区间内），数字、涨跌额、涨跌幅、
   颜色、▲▼ 箭头与迷你 sparkline 同步更新。
   顶栏「暂停刷新 / 继续刷新」按钮为 aria-pressed 切换按钮，暂停时停止全部刷新。
2. Canvas 面积图：devicePixelRatio 适配 + ResizeObserver 重绘；鼠标悬停显示
   十字线与数值浮层，聚焦图表后可用 ← → / Home / End 逐点查看，Esc 退出；
   1D / 1W / 1M 三个时间范围可切换。
3. 自选分类 tab：股票 / 外汇 / 加密 / 基金 / 债券五组数据，支持方向键切换，
   表格在窄屏内横向滚动，不会撑破页面。
4. 数字格式化：千分位、两位（或四位）小数、带符号百分比，全部等宽数字对齐。
5. 无障碍：skip-link、单一 h1、语义化区块、所有图片带 alt、内联 SVG 图标、
   :focus-visible 焦点环、aria-live 节流播报（15 秒内最多一次，另在暂停、
   切换 tab 时立即播报）；prefers-reduced-motion 下自动暂停刷新并停止动画。

四、本地访问方式
------------------------------------------------
方式一（直接打开）：双击 index.html，file:// 下功能与线上一致。
方式二（本地静态服务器）：
    cd D:\GitProject\html\07-finance
    python -m http.server 8080
    浏览器访问 http://127.0.0.1:8080/

五、nginx 部署配置片段
------------------------------------------------
server {
    listen       80;
    server_name  orbit.example.com;
    root         /var/www/orbit;
    index        index.html;

    charset utf-8;

    # 静态资源长缓存（图片带指纹或极少变动时使用）
    location ~* \.(?:webp|svg|css|js)$ {
        expires 30d;
        add_header Cache-Control "public, max-age=2592000, immutable";
        try_files $uri =404;
    }

    # 入口页不缓存，便于发布后立即生效
    location = /index.html {
        add_header Cache-Control "no-cache, must-revalidate";
    }

    # 单页站点：找不到的路径回到首页
    location / {
        try_files $uri $uri/ /index.html;
    }

    # 压缩
    gzip on;
    gzip_comp_level 6;
    gzip_min_length 1024;
    gzip_types text/plain text/css application/javascript image/svg+xml application/json;

    # 基础安全响应头
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
}

启用步骤：
    sudo cp -r 07-finance /var/www/orbit
    sudo nginx -t && sudo systemctl reload nginx

六、约束说明
------------------------------------------------
- 零外部依赖：无 CDN、无网络字体、无第三方库，图标全部为内联 SVG；
  样式中的字体栈只使用系统字体。
- 无构建步骤：源码即产物，可直接由 nginx 托管，也可用 file:// 打开。
- 图片均带 width/height 与非首屏 loading="lazy" + decoding="async"，
  主视觉（指数大数字、面积图、sparkline）完全由 CSS / Canvas / SVG 绘制，不依赖图片。
- 演示数据，不构成投资建议。
