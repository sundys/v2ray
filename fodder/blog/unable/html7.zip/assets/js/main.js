/* ==========================================================================
   ORBIT 行情终端 — 交互脚本
   纯静态演示：行情、图表、日历均为内置虚构数据，无任何网络请求
   ========================================================================== */
"use strict";

(function () {
  /* ==================== 1. 数据（虚构样本） ==================== */
  const INDEX = {
    prevClose: 3370.82,
    value: 3412.68,
    open: 3372.40,
    high: 3418.26,
    low: 3368.15,
    turnover: 6842
  };

  const TILES = [
    { id: "szse", name: "深证成指", value: 11208.44, prev: 11029.02, dp: 2 },
    { id: "chinext", name: "创业板指", value: 2386.12, prev: 2338.16, dp: 2 },
    { id: "hstech", name: "恒生科技", value: 5412.30, prev: 5449.36, dp: 2 },
    { id: "ndx", name: "纳斯达克 100", value: 24118.75, prev: 24017.41, dp: 2 }
  ];

  const WATCH = {
    stock: {
      label: "股票",
      dp: 2,
      rows: [
        { name: "贵州茅台", code: "600519 · SH", price: 1682.40, prev: 1668.04, amount: "62.4 亿" },
        { name: "宁德时代", code: "300750 · SZ", price: 268.55, prev: 262.93, amount: "94.8 亿" },
        { name: "中芯国际", code: "688981 · SH", price: 96.28, prev: 97.57, amount: "48.2 亿" },
        { name: "招商银行", code: "600036 · SH", price: 42.16, prev: 41.98, amount: "31.6 亿" },
        { name: "比亚迪", code: "002594 · SZ", price: 312.70, prev: 309.46, amount: "56.1 亿" },
        { name: "中国平安", code: "601318 · SH", price: 58.34, prev: 58.50, amount: "27.9 亿" }
      ]
    },
    fx: {
      label: "外汇",
      dp: 4,
      rows: [
        { name: "美元/离岸人民币", code: "USD/CNH", price: 7.1186, prev: 7.1272, amount: "1,286 亿" },
        { name: "欧元/美元", code: "EUR/USD", price: 1.0842, prev: 1.0822, amount: "842 亿" },
        { name: "美元/日元", code: "USD/JPY", price: 151.42, prev: 150.90, amount: "1,024 亿" },
        { name: "英镑/美元", code: "GBP/USD", price: 1.2684, prev: 1.2696, amount: "516 亿" },
        { name: "澳元/美元", code: "AUD/USD", price: 0.6512, prev: 0.6498, amount: "284 亿" },
        { name: "美元指数", code: "DXY", price: 104.62, prev: 104.46, amount: "196 亿" }
      ]
    },
    crypto: {
      label: "加密",
      dp: 2,
      rows: [
        { name: "BTC/USDT", code: "BINANCE", price: 68420.50, prev: 66518.20, amount: "428.6 亿" },
        { name: "ETH/USDT", code: "BINANCE", price: 3412.80, prev: 3348.10, amount: "186.4 亿" },
        { name: "SOL/USDT", code: "BINANCE", price: 168.42, prev: 173.84, amount: "42.8 亿" },
        { name: "BNB/USDT", code: "BINANCE", price: 582.30, prev: 578.60, amount: "18.6 亿" },
        { name: "XRP/USDT", code: "BINANCE", price: 0.6184, prev: 0.6277, dp: 4, amount: "12.4 亿" },
        { name: "DOGE/USDT", code: "BINANCE", price: 0.1428, prev: 0.1370, dp: 4, amount: "8.2 亿" }
      ]
    },
    fund: {
      label: "基金",
      dp: 4,
      rows: [
        { name: "华夏上证 50ETF", code: "510050 · SH", price: 2.6840, prev: 2.6648, amount: "18.4 亿" },
        { name: "易方达蓝筹精选", code: "005827 · OF", price: 2.1184, prev: 2.1260, amount: "6.2 亿" },
        { name: "南方中证 500ETF", code: "510500 · SH", price: 6.4280, prev: 6.3530, amount: "12.8 亿" },
        { name: "广发双债增强", code: "270048 · OF", price: 1.2846, prev: 1.2841, amount: "0.8 亿" },
        { name: "招商中证白酒", code: "161725 · OF", price: 0.8642, prev: 0.8750, amount: "4.6 亿" },
        { name: "天弘余额宝", code: "000198 · OF", price: 1.0000, prev: 1.0000, amount: "—" }
      ]
    },
    bond: {
      label: "债券",
      dp: 2,
      rows: [
        { name: "26 附息国债 01", code: "260001 · IB", price: 101.42, prev: 101.30, amount: "86.4 亿" },
        { name: "25 国开 10", code: "250210 · IB", price: 100.86, prev: 100.91, amount: "124.2 亿" },
        { name: "24 国债 15", code: "240015 · IB", price: 102.34, prev: 102.26, amount: "42.6 亿" },
        { name: "23 农发 05", code: "230405 · IB", price: 101.18, prev: 101.22, amount: "18.4 亿" },
        { name: "22 国债 19", code: "220019 · IB", price: 103.62, prev: 103.55, amount: "9.8 亿" },
        { name: "26 贴现国债 02", code: "269902 · IB", price: 99.42, prev: 99.40, amount: "36.2 亿" }
      ]
    }
  };

  const TICKER = [
    { id: "sse", name: "上证", value: 3412.68, prev: 3370.82, dp: 2 },
    { id: "szse", name: "深证", value: 11208.44, prev: 11029.02, dp: 2 },
    { id: "chinext", name: "创业板", value: 2386.12, prev: 2338.16, dp: 2 },
    { id: "hstech", name: "恒生科技", value: 5412.30, prev: 5449.36, dp: 2 },
    { id: "ndx", name: "纳指 100", value: 24118.75, prev: 24017.41, dp: 2 },
    { id: "dxy", name: "美元指数", value: 104.62, prev: 104.46, dp: 2 },
    { id: "cnh", name: "离岸人民币", value: 7.1186, prev: 7.1272, dp: 4 },
    { id: "gold", name: "伦敦金", value: 2684.40, prev: 2661.50, dp: 2 },
    { id: "oil", name: "布伦特原油", value: 78.42, prev: 79.32, dp: 2 },
    { id: "btc", name: "BTC", value: 68420.50, prev: 66518.20, dp: 2 }
  ];

  const MONTH_LABELS = (function () {
    const out = [];
    const d = new Date(2026, 9, 15);
    while (out.length < 22) {
      const wd = d.getDay();
      if (wd !== 0 && wd !== 6) out.push(d.getMonth() + 1 + "/" + d.getDate());
      d.setDate(d.getDate() + 1);
    }
    return out;
  })();

  const RANGES = {
    "1D": {
      count: 78, start: 3370.82, noise: 1.3, amp: 6.4, waves: 2.6, phase: 0.4, seed: 11013,
      label: function (i, n) {
        let m = 570 + Math.round((i / (n - 1)) * 240);
        if (m > 690) m += 90;
        return pad(Math.floor(m / 60)) + ":" + pad(m % 60);
      }
    },
    "1W": {
      count: 35, start: 3348.20, noise: 3.1, amp: 9.2, waves: 4.2, phase: 1.1, seed: 11014,
      label: function (i) {
        const days = ["11/09", "11/10", "11/11", "11/12", "11/13"];
        const hours = ["10:00", "11:30", "13:30", "14:30", "15:00", "15:00", "15:00"];
        return days[Math.min(4, Math.floor(i / 7))] + " " + hours[i % 7];
      }
    },
    "1M": {
      count: 22, start: 3218.40, noise: 5.6, amp: 15.5, waves: 3.1, phase: 2.2, seed: 11015,
      label: function (i) { return MONTH_LABELS[i] || "11/13"; }
    }
  };

  /* ==================== 2. 状态与格式化工具 ==================== */
  const state = { paused: false, cat: "stock", range: "1D", clock: "14:32:06", timer: 0 };
  const liveEl = document.getElementById("liveStatus");
  const numberFormats = new Map();
  let lastAnnounce = 0;

  function pad(n) { return String(n).padStart(2, "0"); }

  function nf(dp) {
    if (!numberFormats.has(dp)) {
      numberFormats.set(dp, new Intl.NumberFormat("zh-CN", {
        minimumFractionDigits: dp, maximumFractionDigits: dp
      }));
    }
    return numberFormats.get(dp);
  }

  function fmtNum(v, dp) { return nf(dp === undefined ? 2 : dp).format(v); }

  function fmtSigned(v, dp) {
    const d = dp === undefined ? 2 : dp;
    const sign = v > 0 ? "+" : v < 0 ? "−" : "";
    return sign + nf(d).format(Math.abs(v));
  }

  function fmtPct(v, dp) { return fmtSigned(v, dp === undefined ? 2 : dp) + "%"; }

  function dir(v) { return v > 0 ? "up" : v < 0 ? "down" : "flat"; }

  function arrow(v) { return v > 0 ? "▲" : v < 0 ? "▼" : "—"; }

  function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

  function round(v, dp) {
    const f = Math.pow(10, dp === undefined ? 2 : dp);
    return Math.round(v * f) / f;
  }

  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* 节流播报：同一区域 15 秒内只播报一次，避免读屏轰炸 */
  function announce(text, force) {
    if (!liveEl) return;
    const now = Date.now();
    if (!force && now - lastAnnounce < 15000) return;
    lastAnnounce = now;
    liveEl.textContent = text;
  }

  /* ==================== 3. 价格随机游走 ==================== */
  function walkValue(value, prev, dp, strength) {
    const step = value * (strength || 0.0006);
    const next = value + (Math.random() * 2 - 1) * step;
    return round(clamp(next, prev * 0.96, prev * 1.04), dp);
  }

  function tickPrices() {
    INDEX.value = walkValue(INDEX.value, INDEX.prevClose, 2, 0.0006);
    INDEX.high = Math.max(INDEX.high, INDEX.value);
    INDEX.low = Math.min(INDEX.low, INDEX.value);
    INDEX.turnover += Math.round(Math.random() * 6);

    TILES.forEach(function (t) { t.value = walkValue(t.value, t.prev, t.dp, 0.0005); });

    Object.keys(WATCH).forEach(function (key) {
      const group = WATCH[key];
      group.rows.forEach(function (row) {
        const dp = row.dp === undefined ? group.dp : row.dp;
        row.price = walkValue(row.price, row.prev, dp, 0.0005);
        row.spark.shift();
        const last = row.spark[row.spark.length - 1];
        row.spark.push(last + (Math.random() - 0.5));
      });
    });

    TICKER.forEach(function (item) {
      if (item.id === "sse") {
        item.value = INDEX.value;
        item.prev = INDEX.prevClose;
        return;
      }
      const tile = TILES.find(function (t) { return t.id === item.id; });
      if (tile) {
        item.value = tile.value;
        item.prev = tile.prev;
        return;
      }
      item.value = walkValue(item.value, item.prev, item.dp, 0.0005);
    });
  }

  /* ==================== 4. 指数与自选渲染 ==================== */
  const els = {
    value: document.getElementById("idxValue"),
    delta: document.getElementById("idxDelta"),
    arrow: document.getElementById("idxArrow"),
    change: document.getElementById("idxChange"),
    pct: document.getElementById("idxPct"),
    high: document.getElementById("idxHigh"),
    low: document.getElementById("idxLow"),
    turnover: document.getElementById("idxTurnover")
  };

  function renderIndex() {
    const chg = INDEX.value - INDEX.prevClose;
    const pct = (chg / INDEX.prevClose) * 100;
    els.value.textContent = fmtNum(INDEX.value, 2);
    els.change.textContent = fmtSigned(chg, 2);
    els.pct.textContent = fmtPct(pct);
    els.arrow.textContent = arrow(chg);
    els.delta.dataset.dir = dir(chg);
    els.high.textContent = fmtNum(INDEX.high, 2);
    els.low.textContent = fmtNum(INDEX.low, 2);
    els.turnover.textContent = fmtNum(INDEX.turnover, 0) + " 亿";
  }

  function renderTiles() {
    TILES.forEach(function (t) {
      const valEl = document.querySelector('[data-tile="' + t.id + '"]');
      const deltaEl = document.querySelector('[data-tile-delta="' + t.id + '"]');
      if (!valEl || !deltaEl) return;
      const chg = t.value - t.prev;
      const pct = (chg / t.prev) * 100;
      valEl.textContent = fmtNum(t.value, t.dp);
      deltaEl.dataset.dir = dir(chg);
      deltaEl.innerHTML = '<span aria-hidden="true">' + arrow(chg) + "</span> " +
        fmtSigned(chg, t.dp) + " · " + fmtPct(pct);
    });
  }

  const quoteBody = document.getElementById("quoteBody");
  const panel = document.getElementById("watchPanel");
  const watchStamp = document.getElementById("watchStamp");
  let activeRows = [];

  function sparkPath(values) {
    const w = 88;
    const h = 26;
    let min = Infinity;
    let max = -Infinity;
    values.forEach(function (v) { if (v < min) min = v; if (v > max) max = v; });
    const span = max - min || 1;
    return values.map(function (v, i) {
      const x = (i / (values.length - 1)) * w;
      const y = h - 2 - ((v - min) / span) * (h - 4);
      return (i ? "L" : "M") + x.toFixed(1) + " " + y.toFixed(1);
    }).join(" ");
  }

  function updateRows() {
    activeRows.forEach(function (item) {
      const row = item.row;
      const chg = row.price - row.prev;
      const pct = (chg / row.prev) * 100;
      item.refs.price.textContent = fmtNum(row.price, item.dp);
      item.refs.chg.textContent = fmtSigned(chg, item.dp);
      item.refs.pct.textContent = fmtPct(pct);
      item.refs.tr.dataset.dir = dir(chg);
      item.refs.spark.setAttribute("d", sparkPath(row.spark));
    });
  }

  function renderWatch(cat) {
    const group = WATCH[cat];
    if (!group) return;
    state.cat = cat;
    activeRows = [];
    quoteBody.replaceChildren();

    group.rows.forEach(function (row) {
      const dp = row.dp === undefined ? group.dp : row.dp;
      const tr = document.createElement("tr");
      tr.className = "quote";
      tr.innerHTML =
        '<td class="quote__name"><span class="quote__label"></span><span class="quote__code"></span></td>' +
        '<td class="quote__price ta-r"></td>' +
        '<td class="quote__chg ta-r"></td>' +
        '<td class="quote__pct ta-r"></td>' +
        '<td class="quote__spark"><svg class="spark" viewBox="0 0 88 26" preserveAspectRatio="none" aria-hidden="true" focusable="false"><path class="spark__line" d=""></path></svg></td>' +
        '<td class="quote__amount ta-r"></td>';
      tr.querySelector(".quote__label").textContent = row.name;
      tr.querySelector(".quote__code").textContent = row.code;
      tr.querySelector(".quote__amount").textContent = row.amount;

      const item = {
        row: row,
        dp: dp,
        refs: {
          tr: tr,
          price: tr.querySelector(".quote__price"),
          chg: tr.querySelector(".quote__chg"),
          pct: tr.querySelector(".quote__pct"),
          spark: tr.querySelector(".spark__line")
        }
      };
      activeRows.push(item);
      quoteBody.append(tr);
    });

    updateRows();
  }

  /* ==================== 5. 滚动行情条 ==================== */
  const tickerTrack = document.getElementById("tickerTrack");

  function tickerItemMarkup(item) {
    const li = document.createElement("li");
    li.className = "ticker__item";
    li.dataset.id = item.id;
    li.innerHTML = '<span class="ticker__name"></span><span class="ticker__price"></span><span class="ticker__pct"></span>';
    return li;
  }

  function initTicker() {
    if (!tickerTrack) return;
    const groups = [document.createElement("ul"), document.createElement("ul")];
    groups.forEach(function (g) { g.className = "ticker__group"; });

    TICKER.forEach(function (item) {
      groups.forEach(function (g) {
        const li = tickerItemMarkup(item);
        li.querySelector(".ticker__name").textContent = item.name;
        g.append(li);
      });
    });
    tickerTrack.append(groups[0], groups[1]);
    groups[1].setAttribute("aria-hidden", "true");
  }

  function renderTicker() {
    if (!tickerTrack) return;
    TICKER.forEach(function (item) {
      const chg = item.value - item.prev;
      const pct = (chg / item.prev) * 100;
      tickerTrack.querySelectorAll('[data-id="' + item.id + '"]').forEach(function (li) {
        li.dataset.dir = dir(chg);
        li.querySelector(".ticker__price").textContent = fmtNum(item.value, item.dp);
        li.querySelector(".ticker__pct").textContent = arrow(chg) + " " + fmtPct(pct);
      });
    });
  }

  /* ==================== 6. Canvas 面积图 ==================== */
  function initChart() {
    const plot = document.getElementById("chartPlot");
    const canvas = document.getElementById("chartCanvas");
    const tip = document.getElementById("chartTip");
    const tipTime = document.getElementById("tipTime");
    const tipVal = document.getElementById("tipVal");
    const tipPct = document.getElementById("tipPct");
    const a11y = document.getElementById("chartA11y");
    if (!plot || !canvas || !canvas.getContext) return { sync: function () {}, redraw: function () {} };

    const ctx = canvas.getContext ? canvas.getContext("2d") : null;
    const css = getComputedStyle(document.documentElement);
    const read = function (name, fallback) {
      const v = css.getPropertyValue(name).trim();
      return v || fallback;
    };
    const C = {
      up: read("--c-up", "oklch(0.85 0.19 150)"),
      down: read("--c-down", "oklch(0.68 0.2 25)"),
      accent: read("--c-accent", "oklch(0.75 0.13 250)"),
      ink2: read("--c-ink-2", "oklch(0.78 0.016 250)"),
      ink3: read("--c-ink-3", "oklch(0.62 0.018 250)"),
      panel: read("--c-panel", "oklch(0.205 0.022 250)")
    };
    const PAD = { t: 14, r: 62, b: 24, l: 10 };
    let w = 0;
    let h = 0;
    let dpr = 1;
    let hover = -1;
    let geom = null;
    let series = buildSeries(state.range);

    function buildSeries(range) {
      const cfg = RANGES[range];
      const rnd = mulberry32(cfg.seed);
      const pts = [];
      for (let i = 0; i < cfg.count; i++) {
        const p = i / (cfg.count - 1);
        const trend = cfg.start + (INDEX.value - cfg.start) * p;
        const wave = Math.sin(p * Math.PI * cfg.waves + cfg.phase) * cfg.amp * (1 - p * 0.4);
        const noise = (rnd() - 0.5) * 2 * cfg.noise;
        pts.push({ v: round(trend + wave + noise, 2), label: cfg.label(i, cfg.count) });
      }
      pts[pts.length - 1].v = INDEX.value;
      return pts;
    }

    function alpha(color, a) {
      const m = /^oklch\(([^/)]+)\)$/.exec(color.trim());
      return m ? "oklch(" + m[1] + " / " + a + ")" : color;
    }

    function layout() {
      const rect = canvas.getBoundingClientRect();
      if (!rect.width || !rect.height) return false;
      w = rect.width;
      h = rect.height;
      dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      return true;
    }

    /* 缩放/DPR 变化时重建后备缓冲，避免位图被拉伸 */
    function ensureDpr() {
      const next = Math.min(window.devicePixelRatio || 1, 2.5);
      if (next === dpr) return;
      dpr = next;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function draw() {
      if (!ctx || !w || !h) return;
      ensureDpr();
      const iw = Math.max(12, w - PAD.l - PAD.r);
      const ih = Math.max(12, h - PAD.t - PAD.b);
      const values = series.map(function (p) { return p.v; });
      const lo = Math.min.apply(null, values.concat([INDEX.prevClose]));
      const hi = Math.max.apply(null, values.concat([INDEX.prevClose]));
      const span = hi - lo || 1;
      const min = lo - span * 0.14;
      const max = hi + span * 0.14;
      const trend = series[series.length - 1].v >= series[0].v ? C.up : C.down;
      geom = { min: min, max: max, t: PAD.t, ih: ih };

      const X = function (i) { return PAD.l + (iw * i) / (series.length - 1); };
      const Y = function (v) { return PAD.t + ih * (1 - (v - min) / (max - min)); };

      ctx.clearRect(0, 0, w, h);
      ctx.font = '10px ui-monospace, "Cascadia Mono", Consolas, monospace';
      ctx.textBaseline = "middle";

      /* 水平网格 + 右侧刻度 */
      for (let g = 0; g <= 4; g++) {
        const val = max - ((max - min) * g) / 4;
        const y = Y(val);
        ctx.beginPath();
        ctx.strokeStyle = "oklch(1 0 0 / 0.07)";
        ctx.lineWidth = 1;
        ctx.moveTo(PAD.l, y);
        ctx.lineTo(PAD.l + iw, y);
        ctx.stroke();
        ctx.fillStyle = C.ink3;
        ctx.textAlign = "left";
        ctx.fillText(fmtNum(val, 2), PAD.l + iw + 8, y);
      }

      /* 昨收参考线 */
      const yPrev = Y(INDEX.prevClose);
      ctx.save();
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = alpha(C.ink3, 0.7);
      ctx.beginPath();
      ctx.moveTo(PAD.l, yPrev);
      ctx.lineTo(PAD.l + iw, yPrev);
      ctx.stroke();
      ctx.restore();
      ctx.fillStyle = C.ink3;
      ctx.textAlign = "left";
      ctx.fillText("昨收", PAD.l + 2, yPrev - 9);

      /* 面积渐变 */
      const grad = ctx.createLinearGradient(0, PAD.t, 0, PAD.t + ih);
      grad.addColorStop(0, alpha(trend, 0.34));
      grad.addColorStop(1, alpha(trend, 0.01));
      ctx.beginPath();
      ctx.moveTo(X(0), Y(series[0].v));
      for (let i = 1; i < series.length; i++) ctx.lineTo(X(i), Y(series[i].v));
      ctx.lineTo(X(series.length - 1), PAD.t + ih);
      ctx.lineTo(X(0), PAD.t + ih);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();

      /* 折线 */
      ctx.beginPath();
      ctx.moveTo(X(0), Y(series[0].v));
      for (let i = 1; i < series.length; i++) ctx.lineTo(X(i), Y(series[i].v));
      ctx.strokeStyle = trend;
      ctx.lineWidth = 2;
      ctx.lineJoin = "round";
      ctx.lineCap = "round";
      ctx.shadowColor = alpha(trend, 0.45);
      ctx.shadowBlur = 10;
      ctx.stroke();
      ctx.shadowBlur = 0;

      /* 末点光点 */
      const lastX = X(series.length - 1);
      const lastY = Y(series[series.length - 1].v);
      ctx.beginPath();
      ctx.fillStyle = alpha(trend, 0.2);
      ctx.arc(lastX, lastY, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.fillStyle = trend;
      ctx.arc(lastX, lastY, 3.4, 0, Math.PI * 2);
      ctx.fill();

      /* 横轴时间刻度 */
      ctx.fillStyle = C.ink3;
      [0, 0.25, 0.5, 0.75, 1].forEach(function (f, idx) {
        const i = Math.round(f * (series.length - 1));
        ctx.textAlign = idx === 0 ? "left" : idx === 4 ? "right" : "center";
        ctx.fillText(series[i].label, X(i), h - 8);
      });

      /* 十字线与高亮点 */
      if (hover >= 0 && hover < series.length) {
        const hx = X(hover);
        const hy = Y(series[hover].v);
        ctx.save();
        ctx.setLineDash([3, 4]);
        ctx.strokeStyle = alpha(C.accent, 0.85);
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(hx, PAD.t);
        ctx.lineTo(hx, PAD.t + ih);
        ctx.stroke();
        ctx.setLineDash([3, 5]);
        ctx.strokeStyle = alpha(C.ink2, 0.45);
        ctx.beginPath();
        ctx.moveTo(PAD.l, hy);
        ctx.lineTo(PAD.l + iw, hy);
        ctx.stroke();
        ctx.restore();

        ctx.beginPath();
        ctx.fillStyle = C.panel;
        ctx.strokeStyle = trend;
        ctx.lineWidth = 2;
        ctx.arc(hx, hy, 4.6, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
    }

    function showTip(i) {
      const pt = series[i];
      const chg = pt.v - INDEX.prevClose;
      const pct = (chg / INDEX.prevClose) * 100;
      tipTime.textContent = pt.label;
      tipVal.textContent = fmtNum(pt.v, 2);
      tipPct.textContent = arrow(chg) + " " + fmtPct(pct);
      tipPct.dataset.dir = dir(chg);
      tip.classList.add("is-on");
      tip.style.opacity = "1";

      const iw = Math.max(12, w - PAD.l - PAD.r);
      const x = PAD.l + (iw * i) / (series.length - 1);
      const y = geom
        ? geom.t + geom.ih * (1 - (pt.v - geom.min) / (geom.max - geom.min))
        : h * 0.2;
      const tipW = tip.offsetWidth || 110;
      const tipH = tip.offsetHeight || 58;
      const left = clamp(x + 14, 6, Math.max(6, w - tipW - 6));
      const top = clamp(y - tipH / 2, 6, Math.max(6, h - tipH - 6));
      tip.style.left = left + "px";
      tip.style.top = top + "px";
    }

    function hideTip() {
      tip.classList.remove("is-on");
      tip.style.opacity = "0";
    }

    function moveTo(i, silent) {
      hover = clamp(i, 0, series.length - 1);
      draw();
      showTip(hover);
      if (!silent) {
        const pt = series[hover];
        const chg = pt.v - INDEX.prevClose;
        a11y.textContent = pt.label + " 指数 " + fmtNum(pt.v, 2) + "，较昨收 " + fmtPct((chg / INDEX.prevClose) * 100);
      }
    }

    function clearHover() {
      hover = -1;
      hideTip();
      draw();
    }

    plot.addEventListener("pointermove", function (e) {
      if (!w) return;
      const rect = plot.getBoundingClientRect();
      const px = e.clientX - rect.left;
      const iw = Math.max(12, w - PAD.l - PAD.r);
      if (px < PAD.l - 6 || px > PAD.l + iw + 6) { clearHover(); return; }
      moveTo(Math.round(((px - PAD.l) / iw) * (series.length - 1)));
    });

    plot.addEventListener("pointerleave", clearHover);
    plot.addEventListener("blur", clearHover);

    plot.addEventListener("keydown", function (e) {
      const keys = ["ArrowLeft", "ArrowRight", "Home", "End", "Escape"];
      if (keys.indexOf(e.key) === -1) return;
      e.preventDefault();
      if (e.key === "Escape") { clearHover(); return; }
      if (e.key === "Home") { moveTo(0); return; }
      if (e.key === "End") { moveTo(series.length - 1); return; }
      const base = hover < 0 ? series.length - 1 : hover;
      moveTo(base + (e.key === "ArrowLeft" ? -1 : 1));
    });

    document.querySelectorAll(".range__btn").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const range = btn.dataset.range;
        if (!range || range === state.range) return;
        state.range = range;
        document.querySelectorAll(".range__btn").forEach(function (b) {
          b.setAttribute("aria-pressed", String(b === btn));
        });
        series = buildSeries(range);
        hover = -1;
        hideTip();
        draw();
        announce("图表已切换到 " + range + " 区间", true);
      });
    });

    /* 无 2D 上下文（如极老环境）时仍保留范围切换的状态与 aria 反馈 */
    if (!ctx) return { sync: function () {}, redraw: function () {} };

    const onResize = function () {
      window.requestAnimationFrame(function () {
        if (layout()) draw();
      });
    };

    if (typeof ResizeObserver === "function") {
      new ResizeObserver(onResize).observe(plot);
    } else {
      window.addEventListener("resize", onResize);
    }

    layout();
    draw();

    return {
      sync: function () {
        series[series.length - 1].v = INDEX.value;
        if (hover >= 0) showTip(hover);
        draw();
      },
      redraw: function () {
        if (layout()) draw();
      }
    };
  }

  /* ==================== 7. 交互：分类 tab / 暂停 / 时钟 ==================== */
  function initTabs() {
    const tabs = Array.prototype.slice.call(document.querySelectorAll(".tabs__btn"));
    if (!tabs.length || !quoteBody) return;

    function select(btn, focus) {
      tabs.forEach(function (b) {
        const on = b === btn;
        b.setAttribute("aria-selected", String(on));
        b.tabIndex = on ? 0 : -1;
      });
      panel.setAttribute("aria-labelledby", btn.id);
      renderWatch(btn.dataset.cat);
      announce("已切换到" + WATCH[btn.dataset.cat].label + "列表，共 " + WATCH[btn.dataset.cat].rows.length + " 条", true);
      if (focus) btn.focus();
    }

    tabs.forEach(function (btn, i) {
      btn.addEventListener("click", function () { select(btn, false); });
      btn.addEventListener("keydown", function (e) {
        let next = null;
        if (e.key === "ArrowRight" || e.key === "ArrowDown") next = tabs[(i + 1) % tabs.length];
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") next = tabs[(i - 1 + tabs.length) % tabs.length];
        if (e.key === "Home") next = tabs[0];
        if (e.key === "End") next = tabs[tabs.length - 1];
        if (!next) return;
        e.preventDefault();
        select(next, true);
      });
    });
  }

  function initClock() {
    const clockEl = document.getElementById("clockTime");
    let seconds = 14 * 3600 + 32 * 60 + 6;
    const end = 15 * 3600;

    function render() {
      const hh = pad(Math.floor(seconds / 3600));
      const mm = pad(Math.floor((seconds % 3600) / 60));
      const ss = pad(seconds % 60);
      state.clock = hh + ":" + mm + ":" + ss;
      if (clockEl) {
        clockEl.textContent = state.clock;
        clockEl.setAttribute("datetime", "2026-11-13T" + state.clock + "+08:00");
      }
      updateStamp();
    }

    function step() {
      if (seconds < end) seconds += 1;
      render();
    }

    render();
    window.setInterval(step, 1000);
  }

  function updateStamp() {
    if (watchStamp) watchStamp.textContent = "最后更新 " + state.clock;
  }

  function setPaused(next, silent) {
    state.paused = next;
    const btn = document.getElementById("pauseBtn");
    const label = document.getElementById("pauseLabel");
    const icon = document.getElementById("pauseIcon");
    if (btn) {
      btn.setAttribute("aria-pressed", String(next));
      btn.setAttribute("aria-label", next ? "继续自动刷新" : "暂停自动刷新");
    }
    if (label) label.textContent = next ? "继续刷新" : "暂停刷新";
    if (icon) icon.setAttribute("href", next ? "#i-play" : "#i-pause");
    if (next) stopTimer(); else startTimer();
    if (!silent) announce(next ? "已暂停自动刷新，行情保持在当前快照" : "已恢复自动刷新，行情每 3 秒更新", true);
  }

  function startTimer() {
    if (state.timer || state.paused) return;
    state.timer = window.setInterval(tick, 3000);
  }

  function stopTimer() {
    if (!state.timer) return;
    window.clearInterval(state.timer);
    state.timer = 0;
  }

  function initPause() {
    const btn = document.getElementById("pauseBtn");
    if (!btn) return;
    btn.addEventListener("click", function () { setPaused(!state.paused); });

    const reduce = typeof window.matchMedia === "function"
      ? window.matchMedia("(prefers-reduced-motion: reduce)")
      : null;
    if (reduce && reduce.matches) {
      setPaused(true, true);
      announce("检测到系统减弱动效设置，已暂停自动刷新", true);
    }
    if (reduce && typeof reduce.addEventListener === "function") {
      reduce.addEventListener("change", function (e) {
        if (e.matches) setPaused(true, true);
      });
    }
  }

  /* ==================== 8. 主循环 ==================== */
  let chart = null;

  function tick() {
    tickPrices();
    renderIndex();
    renderTiles();
    updateRows();
    renderTicker();
    if (chart) chart.sync();
    updateStamp();
    announce("上证指数 " + fmtNum(INDEX.value, 2) + "，" +
      (INDEX.value >= INDEX.prevClose ? "涨 " : "跌 ") +
      fmtNum(Math.abs((INDEX.value - INDEX.prevClose) / INDEX.prevClose) * 100, 2) + "%" +
      "，更新于 " + state.clock);
  }

  function init() {
    Object.keys(WATCH).forEach(function (key) {
      WATCH[key].rows.forEach(function (row, i) {
        const rnd = mulberry32(7000 + key.length * 131 + i * 37);
        const drift = (row.price - row.prev) / row.prev;
        const values = [];
        let v = 0;
        for (let k = 0; k < 20; k++) {
          v += (rnd() - 0.48) * 0.6 + drift * 8;
          values.push(v);
        }
        row.spark = values;
      });
    });

    initTicker();
    renderIndex();
    renderTiles();
    renderWatch(state.cat);
    renderTicker();
    chart = initChart();
    initTabs();
    initClock();
    initPause();
    startTimer();

    document.addEventListener("visibilitychange", function () {
      if (document.hidden) stopTimer();
      else startTimer();
    });
  }

  init();
})();
