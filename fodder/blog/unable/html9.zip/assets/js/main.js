/* ==========================================================================
   FORGE 工具台 — 交互与工具实现
   纯原生 JavaScript，零依赖，全部计算在本地完成
   ========================================================================== */
"use strict";

(function () {

  /* ==================== 0. 基础工具 ==================== */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  function flash(msg, ok) {
    let el = $("#toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "toast";
      el.className = "toast";
      el.setAttribute("role", "status");
      el.setAttribute("aria-live", "polite");
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.dataset.tone = ok === false ? "bad" : "ok";
    el.classList.add("is-on");
    clearTimeout(flash._t);
    flash._t = setTimeout(() => el.classList.remove("is-on"), 1800);
  }

  async function copyText(text) {
    if (!text) {
      flash("没有可复制的内容", false);
      return;
    }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        flash("已复制到剪贴板");
        return;
      }
    } catch (err) {
      /* 回退到 execCommand */
    }
    try {
      if (typeof document.execCommand === "function") {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.setAttribute("readonly", "");
        ta.style.position = "fixed";
        ta.style.insetBlockStart = "-1000px";
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand("copy");
        document.body.removeChild(ta);
        flash(ok ? "已复制到剪贴板" : "复制失败，请手动选择", ok);
        return;
      }
    } catch (err) {
      /* 忽略 */
    }
    flash("当前环境不支持自动复制", false);
  }

  function fmtBytes(n) {
    if (!isFinite(n)) return "—";
    if (n < 1024) return n + " B";
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + " KB";
    return (n / 1048576).toFixed(2) + " MB";
  }

  function num(v, sig) {
    const d = sig || 6;
    if (!isFinite(v)) return "—";
    if (v === 0) return "0";
    const abs = Math.abs(v);
    if (abs >= 1e-4 && abs < 1e12) {
      let s = v.toPrecision(d);
      if (s.indexOf("e") >= 0) return v.toExponential(4);
      if (s.indexOf(".") >= 0) s = s.replace(/0+$/, "").replace(/\.$/, "");
      return s;
    }
    return v.toExponential(4);
  }

  function bytesOf(str) {
    return new TextEncoder().encode(str);
  }

  function pad2(n) {
    return String(n).padStart(2, "0");
  }

  /* ==================== 1. MD5 / SHA-256（纯 JS 实现） ==================== */
  const MD5 = (function () {
    const S = [
      7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
      5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
      4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
      6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21
    ];
    const K = new Array(64);
    for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0;

    return function md5(bytes) {
      const len = bytes.length;
      const total = ((len + 8) >> 6) * 64 + 64;
      const buf = new Uint8Array(total);
      buf.set(bytes);
      buf[len] = 0x80;
      const dv = new DataView(buf.buffer);
      const bits = len * 8;
      dv.setUint32(total - 8, bits >>> 0, true);
      dv.setUint32(total - 4, Math.floor(bits / 4294967296), true);

      let a0 = 0x67452301;
      let b0 = 0xefcdab89;
      let c0 = 0x98badcfe;
      let d0 = 0x10325476;

      const M = new Array(16);
      for (let off = 0; off < total; off += 64) {
        for (let i = 0; i < 16; i++) M[i] = dv.getUint32(off + i * 4, true);
        let A = a0;
        let B = b0;
        let C = c0;
        let D = d0;
        for (let i = 0; i < 64; i++) {
          let F;
          let g;
          if (i < 16) {
            F = (B & C) | (~B & D);
            g = i;
          } else if (i < 32) {
            F = (D & B) | (~D & C);
            g = (5 * i + 1) % 16;
          } else if (i < 48) {
            F = B ^ C ^ D;
            g = (3 * i + 5) % 16;
          } else {
            F = C ^ (B | ~D);
            g = (7 * i) % 16;
          }
          const sum = (F + A + K[i] + M[g]) | 0;
          const rot = ((sum << S[i]) | (sum >>> (32 - S[i]))) | 0;
          A = D;
          D = C;
          C = B;
          B = (B + rot) | 0;
        }
        a0 = (a0 + A) | 0;
        b0 = (b0 + B) | 0;
        c0 = (c0 + C) | 0;
        d0 = (d0 + D) | 0;
      }

      const out = new Uint8Array(16);
      const ov = new DataView(out.buffer);
      ov.setUint32(0, a0 >>> 0, true);
      ov.setUint32(4, b0 >>> 0, true);
      ov.setUint32(8, c0 >>> 0, true);
      ov.setUint32(12, d0 >>> 0, true);
      return toHex(out);
    };
  })();

  const SHA256 = (function () {
    const K = [
      0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
      0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
      0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
      0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
      0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
      0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
      0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
      0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ];

    return function sha256(bytes) {
      const len = bytes.length;
      const total = ((len + 8) >> 6) * 64 + 64;
      const buf = new Uint8Array(total);
      buf.set(bytes);
      buf[len] = 0x80;
      const dv = new DataView(buf.buffer);
      const bits = len * 8;
      dv.setUint32(total - 8, Math.floor(bits / 4294967296));
      dv.setUint32(total - 4, bits >>> 0);

      let h0 = 0x6a09e667;
      let h1 = 0xbb67ae85;
      let h2 = 0x3c6ef372;
      let h3 = 0xa54ff53a;
      let h4 = 0x510e527f;
      let h5 = 0x9b05688c;
      let h6 = 0x1f83d9ab;
      let h7 = 0x5be0cd19;

      const w = new Array(64);
      for (let off = 0; off < total; off += 64) {
        for (let i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4);
        for (let i = 16; i < 64; i++) {
          const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
          const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
          w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
        }
        let a = h0;
        let b = h1;
        let c = h2;
        let d = h3;
        let e = h4;
        let f = h5;
        let g = h6;
        let h = h7;
        for (let i = 0; i < 64; i++) {
          const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
          const ch = (e & f) ^ (~e & g);
          const t1 = (h + S1 + ch + K[i] + w[i]) | 0;
          const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
          const mj = (a & b) ^ (a & c) ^ (b & c);
          const t2 = (S0 + mj) | 0;
          h = g;
          g = f;
          f = e;
          e = (d + t1) | 0;
          d = c;
          c = b;
          b = a;
          a = (t1 + t2) | 0;
        }
        h0 = (h0 + a) | 0;
        h1 = (h1 + b) | 0;
        h2 = (h2 + c) | 0;
        h3 = (h3 + d) | 0;
        h4 = (h4 + e) | 0;
        h5 = (h5 + f) | 0;
        h6 = (h6 + g) | 0;
        h7 = (h7 + h) | 0;
      }

      const out = new Uint8Array(32);
      const ov = new DataView(out.buffer);
      [h0, h1, h2, h3, h4, h5, h6, h7].forEach((v, i) => ov.setUint32(i * 4, v >>> 0));
      return toHex(out);
    };

    function rotr(x, n) {
      return (x >>> n) | (x << (32 - n));
    }
  })();

  function toHex(bytes) {
    let s = "";
    for (let i = 0; i < bytes.length; i++) s += pad2(bytes[i].toString(16));
    return s;
  }

  async function digest(kind, bytes) {
    const subtle = window.crypto && window.crypto.subtle;
    if (kind === "md5") return MD5(bytes);
    if (kind === "sha256") {
      if (subtle) {
        try {
          return toHex(new Uint8Array(await subtle.digest("SHA-256", bytes)));
        } catch (err) {
          /* 回退到纯 JS */
        }
      }
      return SHA256(bytes);
    }
    const name = { sha1: "SHA-1", sha384: "SHA-384", sha512: "SHA-512" }[kind];
    if (!subtle) throw new Error("当前环境不支持 " + name + "（需要 Web Crypto）");
    return toHex(new Uint8Array(await subtle.digest(name, bytes)));
  }

  /* ==================== 2. 工具注册表 ==================== */
  const TOOLS = [
    { id: "json", name: "JSON 格式化", desc: "美化 / 压缩 / 排序", icon: "i-brace", kw: "json 美化 格式化 压缩 排版" },
    { id: "base64", name: "Base64", desc: "编解码", icon: "i-binary", kw: "base64 编码 解码 b64" },
    { id: "url", name: "URL 与参数", desc: "编解码 / 拆参数", icon: "i-link", kw: "url 编码 解码 参数 查询 query" },
    { id: "unit", name: "单位换算", desc: "长度质量面积…", icon: "i-ruler", kw: "单位 换算 length 长度 重量 温度 数据" },
    { id: "time", name: "时间戳", desc: "Unix ↔ 日期", icon: "i-clock", kw: "时间戳 timestamp unix 日期 时间" },
    { id: "color", name: "颜色与对比度", desc: "HEX RGB HSL OKLCH", icon: "i-palette", kw: "颜色 配色 对比度 hex rgb hsl oklch 色值" },
    { id: "text", name: "文本统计", desc: "字数 / 清洗", icon: "i-text", kw: "文本 字数 统计 去重 排序 大小写" },
    { id: "regex", name: "正则测试", desc: "高亮 / 分组", icon: "i-regex", kw: "正则 regex 匹配 表达式" },
    { id: "hash", name: "哈希摘要", desc: "MD5 / SHA 系列", icon: "i-hash", kw: "哈希 hash md5 sha1 sha256 sha512 摘要" },
    { id: "password", name: "密码生成", desc: "安全随机", icon: "i-key", kw: "密码 password 随机 生成 强度" },
    { id: "uuid", name: "UUID 与随机串", desc: "批量生成", icon: "i-fingerprint", kw: "uuid guid 随机 字符串 id" },
    { id: "image", name: "图片压缩", desc: "本地缩放", icon: "i-image", kw: "图片 压缩 缩放 image webp jpeg 转换" }
  ];

  /* ==================== 3. 工具：JSON ==================== */
  function initJson() {
    const inp = $("#jsonIn");
    const out = $("#jsonOut");
    const status = $("#jsonStatus");
    const indent = $("#jsonIndent");
    if (!inp) return;

    const setStatus = (msg, tone) => {
      status.textContent = msg;
      status.className = "status" + (tone ? " " + tone : "");
    };

    const indentStr = () => (indent.value === "tab" ? "\t" : Number(indent.value));

    function sortDeep(v) {
      if (Array.isArray(v)) return v.map(sortDeep);
      if (v && typeof v === "object") {
        const keys = Object.keys(v).sort((a, b) => a.localeCompare(b, "zh-Hans-CN"));
        const o = {};
        keys.forEach((k) => {
          o[k] = sortDeep(v[k]);
        });
        return o;
      }
      return v;
    }

    function whereIs(raw, msg) {
      const m = /position (\d+)/i.exec(msg);
      if (!m) return "";
      const pos = Number(m[1]);
      const before = raw.slice(0, pos);
      const line = before.split("\n").length;
      const col = pos - before.lastIndexOf("\n");
      return "（第 " + line + " 行第 " + col + " 列）";
    }

    function run(mode) {
      const raw = inp.value.trim();
      if (!raw) {
        out.value = "";
        setStatus("等待输入");
        return;
      }
      let data;
      try {
        data = JSON.parse(raw);
      } catch (err) {
        out.value = "";
        setStatus("✕ " + String(err.message).replace(/^JSON\.parse: /, "") + whereIs(raw, String(err.message)), "status--bad");
        return;
      }
      let text;
      if (mode === "minify") text = JSON.stringify(data);
      else if (mode === "sort") text = JSON.stringify(sortDeep(data), null, indentStr());
      else text = JSON.stringify(data, null, indentStr());

      out.value = text;
      const lines = text.split("\n").length;
      setStatus("✓ 有效 JSON · " + lines + " 行 · " + fmtBytes(bytesOf(text).length), "status--ok");
    }

    $$("[data-json]", $("#tool-json")).forEach((btn) => {
      btn.addEventListener("click", () => {
        const mode = btn.dataset.json;
        if (mode === "sample") {
          inp.value = JSON.stringify(
            {
              product: "FORGE 工具台",
              version: "1.0.0",
              offline: true,
              tools: [
                { id: "json", name: "JSON 格式化", tags: ["编码", "文本"] },
                { id: "hash", name: "哈希摘要", tags: ["安全"] }
              ],
              meta: { author: "FORGE Tools", released: "2026-11-18", locale: "zh-CN" }
            },
            null,
            2
          );
          run("format");
          return;
        }
        run(mode);
      });
    });

    indent.addEventListener("change", () => run("format"));
    inp.addEventListener("input", () => {
      if (inp.value.trim()) run("format");
      else {
        out.value = "";
        setStatus("等待输入");
      }
    });
  }

  /* ==================== 4. 工具：Base64 ==================== */
  function initBase64() {
    const inp = $("#b64In");
    const out = $("#b64Out");
    const status = $("#b64Status");
    const urlSafe = $("#b64UrlSafe");
    if (!inp) return;

    const setStatus = (msg, tone) => {
      status.textContent = msg;
      status.className = "status" + (tone ? " " + tone : "");
    };

    function encode(str) {
      const bytes = bytesOf(str);
      let bin = "";
      const CH = 0x8000;
      for (let i = 0; i < bytes.length; i += CH) {
        bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
      }
      let b64 = btoa(bin);
      if (urlSafe.checked) b64 = b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
      return b64;
    }

    function decode(str) {
      let clean = str.replace(/[\r\n\t\s]/g, "").replace(/-/g, "+").replace(/_/g, "/");
      if (!clean) return "";
      const mod = clean.length % 4;
      if (mod === 1) throw new Error("长度不合法，无法解码");
      if (mod === 2) clean += "==";
      else if (mod === 3) clean += "=";
      const bin = atob(clean);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    }

    function run(mode) {
      const v = inp.value;
      if (!v) {
        out.value = "";
        setStatus("等待输入");
        return;
      }
      try {
        const res = mode === "encode" ? encode(v) : decode(v);
        out.value = res;
        setStatus(
          (mode === "encode" ? "✓ 已编码 · " : "✓ 已解码 · ") +
            res.length +
            " 字符 · " +
            fmtBytes(bytesOf(res).length),
          "status--ok"
        );
      } catch (err) {
        out.value = "";
        setStatus("✕ " + err.message, "status--bad");
      }
    }

    $$("[data-b64]", $("#tool-base64")).forEach((btn) => {
      btn.addEventListener("click", () => {
        if (btn.dataset.b64 === "swap") {
          if (out.value) {
            inp.value = out.value;
            out.value = "";
            setStatus("结果已转为输入");
          }
          return;
        }
        run(btn.dataset.b64);
      });
    });

    urlSafe.addEventListener("change", () => {
      if (inp.value) run("encode");
    });
  }

  /* ==================== 5. 工具：URL ==================== */
  function initUrl() {
    const inp = $("#urlIn");
    const out = $("#urlOut");
    const status = $("#urlStatus");
    const tbody = $("#urlParams tbody");
    if (!inp) return;

    const setStatus = (msg, tone) => {
      status.textContent = msg;
      status.className = "status" + (tone ? " " + tone : "");
    };

    function renderParams(text) {
      if (!tbody) return;
      tbody.innerHTML = "";
      let q = "";
      const idx = text.indexOf("?");
      if (idx >= 0) q = text.slice(idx + 1).split("#")[0];
      else if (/^[^=&#]+=[^&]*/.test(text) && text.indexOf("=") > 0) q = text;

      if (!q) {
        const tr = document.createElement("tr");
        const td = document.createElement("td");
        td.colSpan = 2;
        td.className = "tbl__empty";
        td.textContent = "未检测到查询参数";
        tr.appendChild(td);
        tbody.appendChild(tr);
        return;
      }

      q.split("&").forEach((pair) => {
        if (!pair) return;
        const eq = pair.indexOf("=");
        const rawK = eq < 0 ? pair : pair.slice(0, eq);
        const rawV = eq < 0 ? "" : pair.slice(eq + 1);
        const tr = document.createElement("tr");
        const k = document.createElement("td");
        const v = document.createElement("td");
        try {
          k.textContent = decodeURIComponent(rawK.replace(/\+/g, " "));
        } catch (err) {
          k.textContent = rawK;
        }
        try {
          v.textContent = decodeURIComponent(rawV.replace(/\+/g, " ")) || "（空）";
        } catch (err) {
          v.textContent = rawV;
        }
        tr.appendChild(k);
        tr.appendChild(v);
        tbody.appendChild(tr);
      });
    }

    function run(mode) {
      const v = inp.value;
      if (!v) {
        out.value = "";
        setStatus("等待输入");
        return;
      }
      try {
        out.value = mode === "encode" ? encodeURIComponent(v) : decodeURIComponent(v);
        setStatus("✓ 已" + (mode === "encode" ? "编码" : "解码"), "status--ok");
      } catch (err) {
        out.value = "";
        setStatus("✕ 解码失败：百分号转义不完整", "status--bad");
      }
      renderParams(v);
    }

    $$("[data-url]", $("#tool-url")).forEach((btn) => {
      btn.addEventListener("click", () => run(btn.dataset.url));
    });

    inp.addEventListener("input", () => renderParams(inp.value));
  }

  /* ==================== 6. 工具：哈希 ==================== */
  function initHash() {
    const inp = $("#hashIn");
    const list = $("#hashOut");
    const status = $("#hashStatus");
    if (!inp) return;

    function render(rows) {
      list.innerHTML = "";
      rows.forEach((row) => {
        const li = document.createElement("li");
        const b = document.createElement("b");
        b.textContent = row[0];
        const code = document.createElement("code");
        code.textContent = row[1];
        li.appendChild(b);
        li.appendChild(code);
        list.appendChild(li);
      });
    }

    $$("[data-hash]", $("#tool-hash")).forEach((btn) => {
      btn.addEventListener("click", async () => {
        const kind = btn.dataset.hash;
        const label = { md5: "MD5", sha1: "SHA-1", sha256: "SHA-256", sha384: "SHA-384", sha512: "SHA-512" }[kind];
        status.textContent = "计算中…";
        status.className = "status";
        try {
          const hex = await digest(kind, bytesOf(inp.value));
          render([[label, hex]]);
          status.textContent = "✓ " + label + " · " + inp.value.length + " 字符输入";
          status.className = "status status--ok";
        } catch (err) {
          status.textContent = "✕ " + err.message;
          status.className = "status status--bad";
        }
      });
    });
  }

  /* ==================== 7. 工具：单位换算 ==================== */
  const UNIT_SETS = {
    length: {
      label: "长度",
      units: [
        ["mm", "毫米", 0.001], ["cm", "厘米", 0.01], ["m", "米", 1], ["km", "千米", 1000],
        ["in", "英寸", 0.0254], ["ft", "英尺", 0.3048], ["yd", "码", 0.9144],
        ["mi", "英里", 1609.344], ["nmi", "海里", 1852], ["尺", "市尺", 1 / 3], ["里", "市里", 500]
      ]
    },
    mass: {
      label: "质量",
      units: [
        ["mg", "毫克", 1e-6], ["g", "克", 0.001], ["kg", "千克", 1], ["t", "吨", 1000],
        ["lb", "磅", 0.45359237], ["oz", "盎司", 0.028349523125], ["斤", "市斤", 0.5], ["两", "市两", 0.05]
      ]
    },
    area: {
      label: "面积",
      units: [
        ["cm²", "平方厘米", 1e-4], ["m²", "平方米", 1], ["km²", "平方千米", 1e6],
        ["ha", "公顷", 1e4], ["亩", "市亩", 666.6667], ["ft²", "平方英尺", 0.09290304], ["acre", "英亩", 4046.8564224]
      ]
    },
    volume: {
      label: "体积",
      units: [
        ["mL", "毫升", 0.001], ["L", "升", 1], ["m³", "立方米", 1000],
        ["gal", "美制加仑", 3.785411784], ["qt", "夸脱", 0.946352946], ["floz", "液盎司", 0.0295735295625]
      ]
    },
    data: {
      label: "数据",
      units: [
        ["bit", "比特", 0.125], ["B", "字节", 1], ["KB", "千字节", 1024], ["MB", "兆字节", 1048576],
        ["GB", "吉字节", 1073741824], ["TB", "太字节", 1099511627776]
      ]
    },
    speed: {
      label: "速度",
      units: [
        ["m/s", "米每秒", 1], ["km/h", "千米每小时", 0.2777778], ["mph", "英里每小时", 0.44704],
        ["kn", "节", 0.5144444], ["Mach", "马赫", 340.3]
      ]
    },
    time: {
      label: "时间",
      units: [
        ["ms", "毫秒", 0.001], ["s", "秒", 1], ["min", "分", 60], ["h", "小时", 3600],
        ["d", "天", 86400], ["wk", "周", 604800], ["yr", "年（365 天）", 31536000]
      ]
    },
    temp: {
      label: "温度",
      units: [["C", "摄氏度", 1], ["F", "华氏度", 1], ["K", "开尔文", 1]]
    }
  };

  function initUnit() {
    const cat = $("#unitCat");
    const from = $("#unitFrom");
    const to = $("#unitTo");
    const val = $("#unitValue");
    const result = $("#unitResult");
    const list = $("#unitList");
    if (!cat) return;

    function toBase(category, unit, v) {
      if (category === "temp") {
        if (unit === "C") return v;
        if (unit === "F") return ((v - 32) * 5) / 9;
        return v - 273.15;
      }
      const row = UNIT_SETS[category].units.find((u) => u[0] === unit);
      return v * (row ? row[2] : 1);
    }

    function fromBase(category, unit, v) {
      if (category === "temp") {
        if (unit === "C") return v;
        if (unit === "F") return (v * 9) / 5 + 32;
        return v + 273.15;
      }
      const row = UNIT_SETS[category].units.find((u) => u[0] === unit);
      return v / (row ? row[2] : 1);
    }

    function fillUnits() {
      const set = UNIT_SETS[cat.value];
      const build = (sel, defIdx) => {
        sel.innerHTML = "";
        set.units.forEach((u, i) => {
          const opt = document.createElement("option");
          opt.value = u[0];
          opt.textContent = u[1] + "（" + u[0] + "）";
          sel.appendChild(opt);
          if (i === defIdx) opt.selected = true;
        });
      };
      build(from, 0);
      build(to, 1);
    }

    function update() {
      const category = cat.value;
      const v = Number(val.value);
      if (!isFinite(v)) {
        result.textContent = "—";
        return;
      }
      const base = toBase(category, from.value, v);
      result.textContent = num(fromBase(category, to.value, base), 8);

      list.innerHTML = "";
      UNIT_SETS[category].units.forEach((u) => {
        if (u[0] === from.value) return;
        const li = document.createElement("li");
        const s = document.createElement("span");
        s.textContent = u[1] + "（" + u[0] + "）";
        const b = document.createElement("b");
        b.textContent = num(fromBase(category, u[0], base), 8);
        li.appendChild(s);
        li.appendChild(b);
        list.appendChild(li);
      });
    }

    cat.addEventListener("change", () => {
      fillUnits();
      update();
    });
    [from, to].forEach((el) => el.addEventListener("change", update));
    val.addEventListener("input", update);

    fillUnits();
    update();
  }

  /* ==================== 8. 工具：时间戳 ==================== */
  function initTime() {
    const nowEl = $("#nowTs");
    const nowUnit = $("#nowUnit");
    const input = $("#timeIn");
    const local = $("#timeLocal");
    const out = $("#timeOut");
    const btn = $("#timeNow");
    if (!input) return;

    function tick() {
      const ms = Date.now();
      nowEl.textContent = String(Math.floor(ms / 1000));
      nowUnit.textContent = "秒（" + ms + " 毫秒）";
    }

    function toDate(raw) {
      const t = String(raw).trim();
      if (!t) return null;
      const n = Number(t);
      if (!isFinite(n)) return null;
      // 13 位及以上按毫秒
      const ms = Math.abs(n) >= 1e12 ? n : n * 1000;
      const d = new Date(ms);
      return isNaN(d.getTime()) ? null : d;
    }

    function render() {
      out.innerHTML = "";
      const d = toDate(input.value);
      if (!d) {
        const li = document.createElement("li");
        li.className = "k";
        li.textContent = "无法解析，请输入纯数字时间戳";
        out.appendChild(li);
        return;
      }
      const ms = d.getTime();
      const sec = Math.floor(ms / 1000);
      const off = -d.getTimezoneOffset() / 60;
      const rows = [
        ["秒", String(sec)],
        ["毫秒", String(ms)],
        ["本地时间", d.toLocaleString("zh-CN", { hour12: false })],
        ["ISO 8601", d.toISOString()],
        ["UTC", d.toUTCString()],
        ["日期", d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate())],
        ["星期", "星期" + "日一二三四五六"[d.getDay()]],
        ["时区", "UTC" + (off >= 0 ? "+" : "") + off]
      ];
      rows.forEach((r) => {
        const li = document.createElement("li");
        const k = document.createElement("span");
        k.className = "k";
        k.textContent = r[0];
        const v = document.createElement("span");
        v.className = "v";
        v.textContent = r[1];
        li.appendChild(k);
        li.appendChild(v);
        out.appendChild(li);
      });

      // 同步本地输入框（避免用户输入时打断）
      if (document.activeElement !== local) {
        const pad = (n) => pad2(n);
        local.value =
          d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) +
          "T" + pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds());
      }
    }

    input.addEventListener("input", render);
    local.addEventListener("input", () => {
      if (!local.value) return;
      const d = new Date(local.value);
      if (isNaN(d.getTime())) return;
      input.value = String(Math.floor(d.getTime() / 1000));
      render();
    });
    btn.addEventListener("click", () => {
      input.value = String(Math.floor(Date.now() / 1000));
      render();
    });

    tick();
    render();
    setInterval(tick, 1000);
  }

  /* ==================== 9. 工具：颜色 ==================== */
  function initColor() {
    const pick = $("#colorPick");
    const text = $("#colorIn");
    const swatch = $("#colorSwatch");
    const out = $("#colorOut");
    const contrast = $("#colorContrast");
    const palette = $("#colorPalette");
    if (!pick) return;

    function clamp01(v) {
      return Math.min(255, Math.max(0, Math.round(v)));
    }

    function parse(value) {
      const s = String(value).trim().toLowerCase();
      let m = /^#?([0-9a-f]{3})$/.exec(s);
      if (m) {
        const h = m[1];
        return { r: parseInt(h[0] + h[0], 16), g: parseInt(h[1] + h[1], 16), b: parseInt(h[2] + h[2], 16) };
      }
      m = /^#?([0-9a-f]{6})$/.exec(s);
      if (m) {
        const h = m[1];
        return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16) };
      }
      m = /^rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/.exec(s);
      if (m) return { r: +m[1], g: +m[2], b: +m[3] };
      m = /^hsla?\(\s*([\d.]+)[\s,]+([\d.]+)%[\s,]+([\d.]+)%/.exec(s);
      if (m) return hslToRgb(+m[1], +m[2] / 100, +m[3] / 100);
      const named = {
        black: "#000000", white: "#ffffff", red: "#ff0000", green: "#008000", blue: "#0000ff",
        gray: "#808080", grey: "#808080", orange: "#ffa500", purple: "#800080", teal: "#008080"
      };
      if (named[s]) return parse(named[s]);
      return null;
    }

    function rgbToHsl(r, g, b) {
      r /= 255; g /= 255; b /= 255;
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const l = (max + min) / 2;
      let h = 0;
      let s = 0;
      if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
        else if (max === g) h = ((b - r) / d + 2) / 6;
        else h = ((r - g) / d + 4) / 6;
      }
      return { h: h * 360, s: s * 100, l: l * 100 };
    }

    function hslToRgb(h, s, l) {
      h = ((h % 360) + 360) % 360 / 360;
      const f = (p, q, t) => {
        let tt = t;
        if (tt < 0) tt += 1;
        if (tt > 1) tt -= 1;
        if (tt < 1 / 6) return p + (q - p) * 6 * tt;
        if (tt < 1 / 2) return q;
        if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
        return p;
      };
      let r;
      let g;
      let b;
      if (s === 0) {
        r = g = b = l;
      } else {
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r = f(p, q, h + 1 / 3);
        g = f(p, q, h);
        b = f(p, q, h - 1 / 3);
      }
      return { r: clamp01(r * 255), g: clamp01(g * 255), b: clamp01(b * 255) };
    }

    function toOklch(c) {
      const lin = (v) => {
        const x = v / 255;
        return x <= 0.04045 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
      };
      const r = lin(c.r);
      const g = lin(c.g);
      const b = lin(c.b);
      const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
      const m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
      const s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
      const L = 0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s;
      const A = 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s;
      const B = 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s;
      const C = Math.sqrt(A * A + B * B);
      let H = (Math.atan2(B, A) * 180) / Math.PI;
      if (H < 0) H += 360;
      return (
        "oklch(" + L.toFixed(3) + " " + C.toFixed(3) + " " + (C < 0.001 ? 0 : H).toFixed(1) + ")"
      );
    }

    function luminance(c) {
      const lin = (v) => {
        const x = v / 255;
        return x <= 0.04045 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
      };
      return 0.2126 * lin(c.r) + 0.7152 * lin(c.g) + 0.0722 * lin(c.b);
    }

    function ratio(a, b) {
      const l1 = luminance(a);
      const l2 = luminance(b);
      const hi = Math.max(l1, l2);
      const lo = Math.min(l1, l2);
      return (hi + 0.05) / (lo + 0.05);
    }

    function hex(c) {
      return "#" + [c.r, c.g, c.b].map((v) => pad2(clamp01(v).toString(16))).join("");
    }

    function mix(a, b, t) {
      return {
        r: Math.round(a.r + (b.r - a.r) * t),
        g: Math.round(a.g + (b.g - a.g) * t),
        b: Math.round(a.b + (b.b - a.b) * t)
      };
    }

    function render(input) {
      const c = parse(input);
      if (!c) {
        out.innerHTML = "";
        contrast.innerHTML = "";
        const li = document.createElement("li");
        li.className = "k";
        li.textContent = "无法识别该颜色值，试试 #4f46e5、rgb(79,70,229) 或 hsl(243,75%,59%)";
        out.appendChild(li);
        return;
      }
      const h6 = hex(c);
      const hsl = rgbToHsl(c.r, c.g, c.b);
      swatch.style.background = h6;
      if (document.activeElement !== text) text.value = h6;
      pick.value = h6;

      const rows = [
        ["HEX", h6],
        ["RGB", "rgb(" + c.r + ", " + c.g + ", " + c.b + ")"],
        ["HSL", "hsl(" + Math.round(hsl.h) + ", " + Math.round(hsl.s) + "%, " + Math.round(hsl.l) + "%)"],
        ["OKLCH", toOklch(c)]
      ];
      out.innerHTML = "";
      rows.forEach((r) => {
        const li = document.createElement("li");
        const k = document.createElement("span");
        k.className = "k";
        k.textContent = r[0];
        const v = document.createElement("span");
        v.className = "v";
        v.textContent = r[1];
        li.appendChild(k);
        li.appendChild(v);
        out.appendChild(li);
      });

      const white = { r: 255, g: 255, b: 255 };
      const black = { r: 0, g: 0, b: 0 };
      const pairs = [
        ["白底上的文字", c, white, white],
        ["黑底上的文字", c, black, black]
      ];
      contrast.innerHTML = "";
      pairs.forEach((p) => {
        const cr = ratio(p[1], p[2]);
        const li = document.createElement("li");
        const chip = document.createElement("span");
        chip.className = "contrast__chip";
        chip.style.background = hex(p[2]);
        chip.style.color = h6;
        chip.textContent = "Aa";
        const mid = document.createElement("span");
        mid.textContent = p[0] + " ";
        const badgeAA = document.createElement("span");
        badgeAA.className = "badge " + (cr >= 4.5 ? "badge--pass" : "badge--fail");
        badgeAA.textContent = "AA";
        const badgeAAA = document.createElement("span");
        badgeAAA.className = "badge " + (cr >= 7 ? "badge--pass" : "badge--fail");
        badgeAAA.textContent = "AAA";
        mid.appendChild(badgeAA);
        mid.appendChild(document.createTextNode(" "));
        mid.appendChild(badgeAAA);
        const rt = document.createElement("span");
        rt.className = "contrast__ratio";
        rt.textContent = cr.toFixed(2) + ":1";
        li.appendChild(chip);
        li.appendChild(mid);
        li.appendChild(rt);
        contrast.appendChild(li);
      });

      palette.innerHTML = "";
      const steps = [];
      for (let i = 4; i >= 1; i--) steps.push(mix(c, white, i / 5));
      steps.push(c);
      for (let i = 1; i <= 4; i++) steps.push(mix(c, black, i / 5));
      steps.forEach((s) => {
        const li = document.createElement("li");
        const chip = document.createElement("span");
        chip.className = "palette__chip";
        chip.style.background = hex(s);
        const label = document.createElement("span");
        label.textContent = hex(s).slice(1);
        li.appendChild(chip);
        li.appendChild(label);
        palette.appendChild(li);
      });
    }

    text.addEventListener("input", () => render(text.value));
    pick.addEventListener("input", () => {
      text.value = pick.value;
      render(pick.value);
    });

    render(text.value);
  }

  /* ==================== 10. 工具：文本 ==================== */
  function initText() {
    const area = $("#textArea");
    const st = {
      chars: $("#stChars"),
      noSpace: $("#stNoSpace"),
      cjk: $("#stCjk"),
      words: $("#stWords"),
      lines: $("#stLines"),
      bytes: $("#stBytes")
    };
    const status = $("#textStatus");
    if (!area) return;

    function update() {
      const v = area.value;
      st.chars.textContent = String(v.length);
      st.noSpace.textContent = String(v.replace(/\s/g, "").length);
      const cjk = v.match(/[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/g);
      st.cjk.textContent = String(cjk ? cjk.length : 0);
      const latin = v.match(/[A-Za-zÀ-ÿ0-9]+(?:[''-][A-Za-z0-9]+)*/g);
      st.words.textContent = String((latin ? latin.length : 0) + (cjk ? cjk.length : 0));
      st.lines.textContent = String(v ? v.split(/\r\n|\r|\n/).length : 0);
      st.bytes.textContent = String(bytesOf(v).length);
    }

    function apply(kind) {
      const v = area.value;
      switch (kind) {
        case "upper":
          area.value = v.toUpperCase();
          break;
        case "lower":
          area.value = v.toLowerCase();
          break;
        case "title":
          area.value = v.replace(/(^|\s)([a-z])/g, (m, p1, p2) => p1 + p2.toUpperCase());
          break;
        case "dedupe": {
          const seen = new Set();
          area.value = v
            .split("\n")
            .filter((line) => {
              const key = line.trim();
              if (!key) return true;
              if (seen.has(key)) return false;
              seen.add(key);
              return true;
            })
            .join("\n");
          break;
        }
        case "sort":
          area.value = v.split("\n").sort((a, b) => a.localeCompare(b, "zh-Hans-CN")).join("\n");
          break;
        case "trim":
          area.value = v
            .split("\n")
            .map((l) => l.trim())
            .filter((l) => l.length > 0)
            .join("\n");
          break;
        case "reverse":
          area.value = v.split("\n").reverse().join("\n");
          break;
        case "clear":
          area.value = "";
          break;
        default:
          break;
      }
      update();
      status.textContent = kind === "clear" ? "已清空" : "✓ 已应用处理";
      status.className = "status status--ok";
    }

    $$("[data-text]", $("#tool-text")).forEach((btn) => {
      btn.addEventListener("click", () => apply(btn.dataset.text));
    });
    area.addEventListener("input", update);
    update();
  }

  /* ==================== 11. 工具：正则 ==================== */
  function initRegex() {
    const pat = $("#rePattern");
    const flagsIn = $("#reFlags");
    const text = $("#reText");
    const preview = $("#rePreview");
    const status = $("#reStatus");
    const tbody = $("#reMatches tbody");
    if (!pat) return;

    const boxes = $$("[data-flag]", $("#tool-regex"));

    function flagsFromBoxes() {
      return boxes.filter((b) => b.checked).map((b) => b.dataset.flag).join("");
    }

    function syncBoxesFromInput() {
      const f = flagsIn.value;
      boxes.forEach((b) => {
        b.checked = f.indexOf(b.dataset.flag) >= 0;
      });
    }

    function run() {
      preview.innerHTML = "";
      tbody.innerHTML = "";
      const source = pat.value;
      const flags = flagsIn.value;

      if (!source) {
        preview.textContent = "输入表达式开始匹配";
        preview.className = "re__preview re__none";
        status.textContent = "输入表达式开始匹配";
        status.className = "status";
        return;
      }

      let re;
      try {
        re = new RegExp(source, flags.indexOf("g") >= 0 ? flags : flags + "g");
      } catch (err) {
        preview.textContent = "表达式不合法：" + err.message;
        preview.className = "re__preview re__none";
        status.textContent = "✕ " + err.message;
        status.className = "status status--bad";
        return;
      }

      preview.className = "re__preview";
      const subject = text.value;
      const marks = [];
      let m;
      let guard = 0;
      const global = flags.indexOf("g") >= 0;

      while ((m = re.exec(subject)) !== null) {
        marks.push({ start: m.index, end: m.index + m[0].length, text: m[0], groups: m.slice(1) });
        if (!global) break;
        if (m[0].length === 0) re.lastIndex++;
        if (++guard > 5000) break;
      }

      if (!marks.length) {
        preview.textContent = subject || "（测试文本为空）";
        status.textContent = "没有匹配";
        status.className = "status";
        return;
      }

      let cursor = 0;
      marks.forEach((mk) => {
        if (mk.start > cursor) preview.appendChild(document.createTextNode(subject.slice(cursor, mk.start)));
        const mark = document.createElement("mark");
        mark.textContent = subject.slice(mk.start, mk.end) || "​";
        preview.appendChild(mark);
        cursor = Math.max(cursor, mk.end);
      });
      if (cursor < subject.length) preview.appendChild(document.createTextNode(subject.slice(cursor)));

      marks.forEach((mk, i) => {
        const tr = document.createElement("tr");
        const c1 = document.createElement("td");
        c1.textContent = String(i + 1);
        const c2 = document.createElement("td");
        c2.textContent = String(mk.start);
        const c3 = document.createElement("td");
        c3.textContent = mk.text;
        const c4 = document.createElement("td");
        c4.textContent = mk.groups.length
          ? mk.groups.map((g, gi) => "$" + (gi + 1) + "=" + (g === undefined ? "—" : g)).join("  ")
          : "—";
        tr.appendChild(c1);
        tr.appendChild(c2);
        tr.appendChild(c3);
        tr.appendChild(c4);
        tbody.appendChild(tr);
      });

      status.textContent = "✓ 匹配 " + marks.length + " 处";
      status.className = "status status--ok";
    }

    pat.addEventListener("input", run);
    text.addEventListener("input", run);
    flagsIn.addEventListener("input", () => {
      syncBoxesFromInput();
      run();
    });
    boxes.forEach((b) => {
      b.addEventListener("change", () => {
        flagsIn.value = flagsFromBoxes();
        run();
      });
    });

    run();
  }

  /* ==================== 12. 工具：密码 ==================== */
  function initPassword() {
    const lenEl = $("#pwLen");
    const lenVal = $("#pwLenVal");
    const countEl = $("#pwCount");
    const boxes = {
      upper: $("#pwUpper"),
      lower: $("#pwLower"),
      digit: $("#pwDigit"),
      symbol: $("#pwSymbol"),
      noAmb: $("#pwNoAmb")
    };
    const list = $("#pwList");
    const out = $("#pwOut");
    const status = $("#pwStatus");
    const btn = $("#pwGen");
    if (!lenEl) return;

    const SETS = {
      upper: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
      lower: "abcdefghijklmnopqrstuvwxyz",
      digit: "0123456789",
      symbol: "!@#$%^&*()-_=+[]{};:,.?/",
      amb: "0O1lI|`'\""
    };

    function pool() {
      let s = "";
      ["upper", "lower", "digit", "symbol"].forEach((k) => {
        if (boxes[k] && boxes[k].checked) s += SETS[k];
      });
      if (boxes.noAmb && boxes.noAmb.checked) {
        s = s.split("").filter((ch) => SETS.amb.indexOf(ch) < 0).join("");
      }
      return s;
    }

    function randomIdx(max) {
      const arr = new Uint32Array(1);
      const limit = Math.floor(0x100000000 / max) * max;
      let v;
      do {
        window.crypto.getRandomValues(arr);
        v = arr[0];
      } while (v >= limit);
      return v % max;
    }

    function generate() {
      const chars = pool();
      if (!chars) {
        list.innerHTML = "";
        const li = document.createElement("li");
        li.className = "pwlist__empty";
        li.textContent = "至少选择一种字符类型";
        list.appendChild(li);
        status.textContent = "✕ 没有可用字符集";
        status.className = "status status--bad";
        return;
      }
      const n = Number(lenEl.value);
      const count = Number(countEl.value);
      const results = [];
      for (let k = 0; k < count; k++) {
        let s = "";
        for (let i = 0; i < n; i++) s += chars[randomIdx(chars.length)];
        results.push(s);
      }
      const bits = Math.round(n * Math.log2(chars.length));
      list.innerHTML = "";
      results.forEach((pw) => {
        const li = document.createElement("li");
        const code = document.createElement("code");
        code.textContent = pw;
        const copyBtn = document.createElement("button");
        copyBtn.type = "button";
        copyBtn.className = "icon-btn";
        copyBtn.setAttribute("aria-label", "复制这条密码");
        copyBtn.innerHTML = '<svg class="ico" aria-hidden="true"><use href="#i-copy"/></svg>';
        copyBtn.addEventListener("click", () => copyText(pw));
        li.appendChild(code);
        li.appendChild(copyBtn);
        list.appendChild(li);
      });
      out.value = results.join("\n");
      status.textContent = "✓ 已生成 " + count + " 条 · 字符池 " + chars.length + " · 熵约 " + bits + " bit" + (bits >= 100 ? "（很强）" : bits >= 70 ? "（强）" : "（一般）");
      status.className = "status status--ok";
    }

    lenEl.addEventListener("input", () => {
      lenVal.textContent = lenEl.value;
    });
    btn.addEventListener("click", generate);
    generate();
  }

  /* ==================== 13. 工具：UUID ==================== */
  function initUuid() {
    const countEl = $("#uuidCount");
    const fmtEl = $("#uuidFormat");
    const out = $("#uuidOut");
    const status = $("#uuidStatus");
    const btn = $("#uuidGen");
    if (!btn) return;

    function v4() {
      if (window.crypto && typeof window.crypto.randomUUID === "function") {
        try {
          return window.crypto.randomUUID();
        } catch (err) {
          /* 回退 */
        }
      }
      const b = new Uint8Array(16);
      window.crypto.getRandomValues(b);
      b[6] = (b[6] & 0x0f) | 0x40;
      b[8] = (b[8] & 0x3f) | 0x80;
      const h = Array.from(b, (x) => pad2(x.toString(16))).join("");
      return h.slice(0, 8) + "-" + h.slice(8, 12) + "-" + h.slice(12, 16) + "-" + h.slice(16, 20) + "-" + h.slice(20);
    }

    function generate() {
      const n = Number(countEl.value);
      const fmt = fmtEl.value;
      const list = [];
      for (let i = 0; i < n; i++) {
        let id = v4();
        if (fmt === "upper") id = id.toUpperCase();
        else if (fmt === "plain") id = id.replace(/-/g, "");
        else if (fmt === "brace") id = "{" + id + "}";
        list.push(id);
      }
      out.value = list.join("\n");
      status.textContent = "✓ 已生成 " + n + " 个 UUID v4";
      status.className = "status status--ok";
    }

    btn.addEventListener("click", generate);
    fmtEl.addEventListener("change", generate);
    countEl.addEventListener("change", generate);
    generate();
  }

  /* ==================== 14. 工具：图片压缩 ==================== */
  function initImage() {
    const drop = $("#drop");
    const file = $("#imgFile");
    const runBtn = $("#imgRun");
    const dl = $("#imgDownload");
    const previewWrap = $("#imgPreviewWrap");
    let preview = $("#imgPreview");
    const meta = $("#imgMeta");
    const status = $("#imgStatus");
    const widthSel = $("#imgWidth");
    const quality = $("#imgQuality");
    const qualityVal = $("#imgQualityVal");
    const formatSel = $("#imgFormat");
    if (!drop) return;

    let current = null;
    let objectUrl = null;

    function statusMsg(msg, tone) {
      status.textContent = msg;
      status.className = "status" + (tone ? " " + tone : "");
    }

    function loadImage(fileObj) {
      return new Promise((resolve, reject) => {
        if (typeof createImageBitmap === "function") {
          createImageBitmap(fileObj).then(resolve, () => {
            fallback();
          });
        } else {
          fallback();
        }
        function fallback() {
          const url = URL.createObjectURL(fileObj);
          const img = new Image();
          img.onload = () => resolve(img);
          img.onerror = () => reject(new Error("无法读取该图片"));
          img.src = url;
        }
      });
    }

    function accept(fileObj) {
      if (!fileObj) return;
      if (!/^image\//.test(fileObj.type)) {
        statusMsg("✕ 请选择图片文件", "status--bad");
        return;
      }
      current = fileObj;
      runBtn.disabled = false;
      dl.hidden = true;
      statusMsg("已选择 " + fileObj.name + " · " + fmtBytes(fileObj.size) + "，点击「压缩」");
    }

    async function compress() {
      if (!current) return;
      statusMsg("处理中…");
      try {
        const img = await loadImage(current);
        const srcW = img.width || img.naturalWidth;
        const srcH = img.height || img.naturalHeight;
        const maxW = Number(widthSel.value);
        const scale = maxW > 0 && srcW > maxW ? maxW / srcW : 1;
        const w = Math.max(1, Math.round(srcW * scale));
        const h = Math.max(1, Math.round(srcH * scale));

        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) throw new Error("当前浏览器不支持 Canvas 2D");
        ctx.imageSmoothingQuality = "high";
        ctx.drawImage(img, 0, 0, w, h);

        const type = formatSel.value;
        const q = Number(quality.value);
        const blob = await new Promise((resolve) => canvas.toBlob(resolve, type, q));
        if (!blob) throw new Error("编码失败，请换一种格式");

        if (objectUrl) URL.revokeObjectURL(objectUrl);
        objectUrl = URL.createObjectURL(blob);
        // 首次压缩时才创建 <img>，避免页面上出现无源图片
        if (!preview) {
          preview = document.createElement("img");
          preview.id = "imgPreview";
          preview.alt = "压缩后的图片预览";
          preview.decoding = "async";
          previewWrap.insertBefore(preview, meta);
        }
        preview.src = objectUrl;
        preview.width = w;
        preview.height = h;
        previewWrap.hidden = false;

        const saved = current.size > 0 ? Math.round((1 - blob.size / current.size) * 100) : 0;
        meta.textContent =
          w + " × " + h + " px · " + fmtBytes(current.size) + " → " + fmtBytes(blob.size) +
          (current.size > blob.size ? "（减少 " + saved + "%）" : "（反而变大，建议换 WebP 或降低质量）");

        dl.hidden = false;
        dl.dataset.filename = "compressed-" + w + "x" + h + (type === "image/webp" ? ".webp" : ".jpg");
        statusMsg("✓ 压缩完成 · " + fmtBytes(blob.size), "status--ok");
      } catch (err) {
        statusMsg("✕ " + err.message, "status--bad");
      }
    }

    file.addEventListener("change", () => accept(file.files && file.files[0]));
    runBtn.addEventListener("click", compress);

    dl.addEventListener("click", () => {
      if (!objectUrl) return;
      const a = document.createElement("a");
      a.href = objectUrl;
      a.download = dl.dataset.filename || "compressed.webp";
      document.body.appendChild(a);
      a.click();
      a.remove();
      flash("已开始下载");
    });
    quality.addEventListener("input", () => {
      qualityVal.textContent = Number(quality.value).toFixed(2);
    });

    ["dragenter", "dragover"].forEach((ev) => {
      drop.addEventListener(ev, (e) => {
        e.preventDefault();
        drop.classList.add("is-over");
      });
    });
    ["dragleave", "drop"].forEach((ev) => {
      drop.addEventListener(ev, (e) => {
        e.preventDefault();
        drop.classList.remove("is-over");
      });
    });
    drop.addEventListener("drop", (e) => {
      const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      accept(f);
    });
  }

  /* ==================== 15. 工作台切换 ==================== */
  let activeTool = "json";

  function openTool(id, scroll) {
    if (!TOOLS.some((t) => t.id === id)) return;
    activeTool = id;
    $$(".rail__btn").forEach((b) => {
      const on = b.dataset.tool === id;
      b.classList.toggle("is-active", on);
      b.setAttribute("aria-current", on ? "true" : "false");
      b.tabIndex = on ? 0 : -1;
    });
    $$(".panel").forEach((p) => {
      p.hidden = p.dataset.panel !== id;
    });
    const t = TOOLS.find((x) => x.id === id);
    const intro = $("#benchIntro");
    if (intro && t) intro.textContent = "当前：" + t.name + " · " + t.desc;
    if (scroll) {
      const bench = $("#workbench");
      if (bench) bench.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  function initBench() {
    const railBtns = $$(".rail__btn");
    railBtns.forEach((btn) => {
      btn.addEventListener("click", () => openTool(btn.dataset.tool));
    });

    // 方向键在侧栏内移动
    const rail = $(".rail");
    if (rail) {
      rail.addEventListener("keydown", (e) => {
        const keys = ["ArrowDown", "ArrowUp", "ArrowRight", "ArrowLeft", "Home", "End"];
        if (keys.indexOf(e.key) < 0) return;
        const idx = railBtns.indexOf(document.activeElement);
        if (idx < 0) return;
        e.preventDefault();
        let next = idx;
        if (e.key === "ArrowDown" || e.key === "ArrowRight") next = (idx + 1) % railBtns.length;
        else if (e.key === "ArrowUp" || e.key === "ArrowLeft") next = (idx - 1 + railBtns.length) % railBtns.length;
        else if (e.key === "Home") next = 0;
        else next = railBtns.length - 1;
        railBtns[next].focus();
        openTool(railBtns[next].dataset.tool);
      });
    }

    $$("[data-open]").forEach((card) => {
      card.addEventListener("click", () => openTool(card.dataset.open, true));
    });

    const rand = $("#heroRandom");
    if (rand) {
      rand.addEventListener("click", () => {
        const pick = TOOLS[Math.floor(Math.random() * TOOLS.length)];
        openTool(pick.id, true);
        flash("已打开：" + pick.name);
      });
    }

    // 初始：侧栏按钮只有当前项可 Tab 到
    openTool("json");
  }

  /* ==================== 16. 命令面板 ==================== */
  function initPalette() {
    const dlg = $("#palette");
    const input = $("#paletteInput");
    const listEl = $("#paletteList");
    const openBtn = $("#paletteBtn");
    const closeBtn = $("#paletteClose");
    if (!dlg || !input) return;

    let items = [];
    let sel = 0;

    function build(query) {
      const q = query.trim().toLowerCase();
      const hits = TOOLS.filter((t) => {
        if (!q) return true;
        return (t.name + " " + t.desc + " " + t.kw + " " + t.id).toLowerCase().indexOf(q) >= 0;
      });
      items = hits;
      sel = 0;
      listEl.innerHTML = "";
      if (!hits.length) {
        const p = document.createElement("li");
        p.className = "palette__empty";
        p.textContent = "没有匹配的工具";
        listEl.appendChild(p);
        return;
      }
      hits.forEach((t, i) => {
        const li = document.createElement("li");
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "palette__item";
        btn.setAttribute("aria-selected", i === 0 ? "true" : "false");
        btn.innerHTML = '<svg aria-hidden="true"><use href="#' + t.icon + '"/></svg>';
        btn.appendChild(document.createTextNode(t.name));
        const sp = document.createElement("span");
        sp.textContent = t.desc;
        btn.appendChild(sp);
        btn.addEventListener("click", () => {
          choose(t.id);
        });
        li.appendChild(btn);
        listEl.appendChild(li);
      });
    }

    function highlight() {
      const btns = $$(".palette__item", listEl);
      btns.forEach((b, i) => b.setAttribute("aria-selected", i === sel ? "true" : "false"));
      const cur = btns[sel];
      if (cur && cur.scrollIntoView) cur.scrollIntoView({ block: "nearest" });
    }

    function choose(id) {
      close();
      openTool(id, true);
      const t = TOOLS.find((x) => x.id === id);
      if (t) flash("已打开：" + t.name);
    }

    function open() {
      build("");
      input.value = "";
      if (typeof dlg.showModal === "function") dlg.showModal();
      else dlg.setAttribute("open", "");
      setTimeout(() => input.focus(), 20);
    }

    function close() {
      if (typeof dlg.close === "function" && dlg.open) dlg.close();
      else dlg.removeAttribute("open");
    }

    openBtn.addEventListener("click", open);
    if (closeBtn) closeBtn.addEventListener("click", close);
    input.addEventListener("input", () => build(input.value));
    dlg.addEventListener("click", (e) => {
      if (e.target === dlg) close();
    });
    dlg.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        sel = Math.min(items.length - 1, sel + 1);
        highlight();
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        sel = Math.max(0, sel - 1);
        highlight();
      } else if (e.key === "Enter") {
        e.preventDefault();
        if (items[sel]) choose(items[sel].id);
      } else if (e.key === "Escape") {
        close();
      }
    });

    document.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "K")) {
        e.preventDefault();
        open();
      }
    });
  }

  /* ==================== 17. 主题 ==================== */
  function initTheme() {
    const btn = $("#themeBtn");
    const root = document.documentElement;
    if (!btn) return;

    const stored = (function () {
      try {
        return localStorage.getItem("forge-theme");
      } catch (err) {
        return null;
      }
    })();

    if (stored === "dark" || stored === "light") root.dataset.theme = stored;
    else if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) root.dataset.theme = "dark";

    const sync = () => {
      const isDark = root.dataset.theme === "dark";
      btn.setAttribute("aria-pressed", isDark ? "true" : "false");
      btn.setAttribute("aria-label", isDark ? "切换到浅色模式" : "切换到深色模式");
      const meta = document.querySelector('meta[name="theme-color"]');
      if (meta) meta.setAttribute("content", isDark ? "#171a21" : "#4f46e5");
    };

    btn.addEventListener("click", () => {
      root.dataset.theme = root.dataset.theme === "dark" ? "light" : "dark";
      sync();
      try {
        localStorage.setItem("forge-theme", root.dataset.theme);
      } catch (err) {
        /* 隐私模式下忽略 */
      }
    });

    sync();
  }

  /* ==================== 18. 复制按钮 & 入场动画 ==================== */
  function initCopyButtons() {
    $$("[data-copy]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const target = document.getElementById(btn.dataset.copy);
        if (!target) return;
        const text = "value" in target ? target.value : target.textContent;
        copyText(text);
      });
    });
  }

  function initReveal() {
    const els = $$(".cards li, .privacy__list li");
    if (!els.length) return;
    els.forEach((el) => el.classList.add("fade-up"));
    const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || !("IntersectionObserver" in window)) {
      els.forEach((el) => el.classList.add("is-in"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            en.target.classList.add("is-in");
            io.unobserve(en.target);
          }
        });
      },
      { rootMargin: "0px 0px -6% 0px", threshold: 0.08 }
    );
    els.forEach((el, i) => {
      el.style.transitionDelay = Math.min(i * 28, 260) + "ms";
      io.observe(el);
    });
  }

  /* ==================== 19. 启动 ==================== */
  function init() {
    initTheme();
    initBench();
    initPalette();
    initCopyButtons();
    initJson();
    initBase64();
    initUrl();
    initHash();
    initUnit();
    initTime();
    initColor();
    initText();
    initRegex();
    initPassword();
    initUuid();
    initImage();
    initReveal();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
