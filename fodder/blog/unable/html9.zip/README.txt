FORGE 工具台 · 纯静态工具站
================================

一、文件说明
------------
index.html              页面结构（顶栏 / 工具目录 / 12 个工具面板 / 命令面板 / 页脚）
assets/css/style.css    全部样式（@layer 分层：reset/tokens/base/layout/components/utilities）
assets/js/main.js       全部工具实现（原生 JavaScript，无框架、无第三方库）
favicon.svg             站点图标

本站不加载任何外部资源：没有 CDN、没有网络字体、没有统计脚本。
字体使用系统字体栈（system-ui / 苹方 / 微软雅黑），图标为内联 SVG 精灵。

二、包含的 12 个工具（全部在浏览器本地运行）
--------------------------------------------
1  JSON 格式化      美化 / 压缩 / 递归排序键名 / 语法错误定位（行、列）
2  Base64           编解码，按 UTF-8 处理，支持 URL-safe 变体
3  URL 与参数       percent-encoding 编解码，查询参数拆解成表格
4  单位换算         长度 / 质量 / 面积 / 体积 / 数据 / 速度 / 时间 / 温度
5  时间戳           Unix 秒与毫秒自动识别，本地 / ISO / UTC / 星期 / 时区
6  颜色与对比度     HEX / RGB / HSL / OKLCH 互转，WCAG AA·AAA 判定，配色阶梯
7  文本统计         字符 / 不含空格 / 中文字 / 词 / 行 / UTF-8 字节 + 8 种清洗操作
8  正则测试         实时高亮匹配、捕获分组明细
9  哈希摘要         MD5 与 SHA-256 为纯 JS 实现；SHA-1/384/512 走 Web Crypto
10 密码生成         crypto.getRandomValues 无偏采样，显示字符池规模与信息熵
11 UUID / 随机串    批量 v4 UUID，四种输出格式
12 图片压缩         Canvas 本地缩放与重编码，显示压缩前后体积，可下载

三、nginx 部署
--------------
1. 解压到 /var/www/tools/（保证 /var/www/tools/index.html 存在）
2. 站点配置：

  server {
      listen 80;
      server_name tools.example.com;
      root /var/www/tools;
      index index.html;

      charset utf-8;
      charset_types text/css application/javascript application/json image/svg+xml;

      location / {
          try_files $uri $uri/ /index.html;
      }

      location ~* \.(?:css|js|svg|png|jpg|jpeg|webp|ico)$ {
          expires 30d;
          add_header Cache-Control "public, max-age=2592000, immutable";
          access_log off;
      }

      add_header X-Content-Type-Options "nosniff" always;
      add_header Referrer-Policy "strict-origin-when-cross-origin" always;
      add_header X-Frame-Options "SAMEORIGIN" always;

      gzip on;
      gzip_types text/css application/javascript image/svg+xml;
      gzip_min_length 1024;
  }

如需作为子目录部署，放到 /var/www/html/tools/ 后访问 http://your-host/tools/ 即可，
页面内所有资源均为相对路径，不需要额外配置。

四、浏览器支持
--------------
Chrome / Edge 120+、Firefox 121+、Safari 17.4+
使用 @layer、oklch()、color-mix()、:has()、dvh、dialog 等现代特性。
剪贴板写入失败时会自动回退到 execCommand，file:// 下也能复制。

五、说明
--------
- 所有计算在本地完成，输入的文本、图片不会上传到任何服务器。
- 图片压缩在 file:// 下同样可用（Canvas 与 Blob URL 均为本地对象）。
- 密码与 UUID 使用 crypto.getRandomValues 生成，仅在当前页面内存中，不会保存。
- 本站不接入任何后端接口，示例数据仅用于演示。
