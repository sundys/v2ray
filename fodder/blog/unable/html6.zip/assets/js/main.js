/* ==========================================================================
   THE LEDGER · 时纪日报 — 交互脚本
   纯静态演示：数据全部内置，无任何网络请求
   ========================================================================== */
"use strict";

(function () {
  /* ==================== 1. 工具与常量 ==================== */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
  const hasIO = "IntersectionObserver" in window;
  const STORE_TEXT = "ledger.textsize";
  const STORE_VOTE = "ledger.poll";

  /* 本地存储：隐私模式下会抛错，统一忽略 */
  function readStore(key) {
    try { return window.localStorage.getItem(key); } catch (err) { return null; }
  }
  function writeStore(key, value) {
    try { window.localStorage.setItem(key, value); } catch (err) { /* 忽略 */ }
  }

  /* ==================== 2. 正文字号 ==================== */
  function initTextSize() {
    const root = document.documentElement;
    const buttons = $$("button[data-textsize]");
    if (!buttons.length) return;

    const apply = (size) => {
      root.dataset.textsize = size;
      buttons.forEach((btn) => {
        btn.setAttribute("aria-pressed", String(btn.dataset.textsize === size));
      });
    };

    const saved = readStore(STORE_TEXT);
    apply(["s", "m", "l"].includes(saved) ? saved : "m");

    buttons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const size = btn.dataset.textsize;
        if (!size || size === root.dataset.textsize) return;
        apply(size);
        writeStore(STORE_TEXT, size);
      });
    });
  }

  /* ==================== 3. 快讯滚动暂停 ==================== */
  function initTicker() {
    const ticker = $("#ticker");
    const button = $("#tickerBtn");
    const track = $("#tickerTrack");
    if (!ticker || !button || !track) return;

    const setPaused = (paused) => {
      ticker.dataset.paused = String(paused);
      button.setAttribute("aria-pressed", String(paused));
      button.setAttribute("aria-label", paused ? "继续滚动快讯" : "暂停滚动快讯");
      button.querySelector("use")?.setAttribute("href", paused ? "#i-play" : "#i-pause");
    };

    setPaused(false);
    button.addEventListener("click", () => setPaused(ticker.dataset.paused !== "true"));

    /* 系统偏好切换时同步按钮语义（CSS 已停止动画） */
    const syncMotion = () => {
      if (motionQuery.matches) setPaused(true);
    };
    motionQuery.addEventListener("change", syncMotion);
    syncMotion();
  }

  /* ==================== 4. 版面锚点高亮 ==================== */
  function initSectionNav() {
    const links = $$(".cats__list a");
    const current = $("#catsNow");
    if (!links.length) return;

    const sections = links
      .map((link) => ({ link, el: document.getElementById(link.hash.slice(1)) }))
      .filter((item) => item.el);

    if (!sections.length) return;

    const setActive = (link) => {
      links.forEach((item) => {
        item.setAttribute("aria-current", String(item === link));
      });
      if (current) current.textContent = link.textContent.trim();
    };

    setActive(links[0]);

    if (!hasIO) return;

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const hit = sections.find((item) => item.el === entry.target);
          if (hit) setActive(hit.link);
        });
      },
      { rootMargin: "-18% 0px -62% 0px", threshold: 0 }
    );

    sections.forEach((item) => io.observe(item.el));
  }

  /* ==================== 5. 观点投票 ==================== */
  const POLL_BASE = { time: 612, fare: 318, access: 241, rent: 113 };
  const POLL_LABEL = {
    time: "通勤时间",
    fare: "票价与优惠",
    access: "站点接驳",
    rent: "沿线房租"
  };

  function initPoll() {
    const form = $("#poll");
    if (!form) return;

    const options = $$(".poll__opt", form);
    const totalEl = $("#pollTotal");
    const note = $("#pollNote");
    const stored = readStore(STORE_VOTE);
    let mine = options.some((btn) => btn.dataset.poll === stored) ? stored : null;

    const render = (announce) => {
      const counts = Object.assign({}, POLL_BASE);
      if (mine && typeof counts[mine] === "number") counts[mine] += 1;
      const total = Object.keys(counts).reduce((sum, key) => sum + counts[key], 0);

      options.forEach((btn) => {
        const key = btn.dataset.poll;
        const pct = total ? (counts[key] / total) * 100 : 0;
        const value = pct.toFixed(1);
        const pctEl = btn.querySelector(".poll__pct");
        if (pctEl) pctEl.textContent = value + "%";
        btn.style.setProperty("--v", value + "%");
        btn.setAttribute("aria-pressed", String(mine === key));
        btn.setAttribute("aria-label",
          POLL_LABEL[key] + "，当前 " + value + "%" + (mine === key ? "，已选" : ""));
      });

      if (totalEl) totalEl.textContent = total.toLocaleString("zh-CN");

      if (announce && mine) {
        const share = ((counts[mine] / total) * 100).toFixed(1);
        note.textContent = "已记录：你选择「" + POLL_LABEL[mine] + "」，当前占比 " +
          share + "%，共 " + total.toLocaleString("zh-CN") + " 人参与。";
      }
    };

    options.forEach((btn) => {
      btn.addEventListener("click", () => {
        mine = btn.dataset.poll;
        writeStore(STORE_VOTE, mine);
        render(true);
      });
    });

    render(false);
    if (mine && note) {
      note.textContent = "你已投给「" + POLL_LABEL[mine] + "」，点击其他选项可改投。";
    }
  }

  /* ==================== 6. 长文折叠 ==================== */
  function initLongform() {
    $$("details.fold").forEach((fold) => {
      const text = fold.querySelector(".fold__text");
      const hint = fold.querySelector(".fold__hint");
      const paragraphs = $$(".fold__body p", fold);
      const chars = paragraphs.reduce((sum, p) => sum + p.textContent.trim().length, 0);

      const sync = () => {
        if (text) text.textContent = fold.open ? "收起全文" : "继续阅读全文";
        if (hint) {
          hint.textContent = fold.open
            ? "已展开 " + paragraphs.length + " 段"
            : "余 " + paragraphs.length + " 段 · 约 " + chars.toLocaleString("zh-CN") + " 字";
        }
        fold.dataset.open = String(fold.open);
      };

      fold.addEventListener("toggle", sync);
      sync();
    });
  }

  /* ==================== 7. 站内检索 ==================== */
  const SEARCH_INDEX = [
    { kicker: "要闻", title: "环线成环：41.6 万人次的第一天", text: "全长 78.4 公里的环城铁路今日 05:42 发出首班车，23 座车站串起四座新城。" },
    { kicker: "要闻", title: "提前下达 2027 年新增专项债额度 1.9 万亿元", text: "重点投向城市更新、轨道交通与保障性住房。" },
    { kicker: "要闻", title: "10 月社零同比增长 4.8%", text: "餐饮收入增速回升至 6.1%，以旧换新带动家电类增长 12.3%。" },
    { kicker: "要闻", title: "京张高速部分路段因降雪限速 60 公里", text: "养护部门出动 46 台除雪车，山区段禁止危化品运输车辆通行。" },
    { kicker: "要闻", title: "民国报纸数字化二期上线 12.4 万版", text: "国家图书馆开放 1912 至 1949 年间 318 种报纸的全文检索。" },
    { kicker: "短讯", title: "10 月出口同比增长 6.4%，机电产品占比 61.2%", text: "对东盟出口增长 11.8%，连续 7 个月高于整体增速。" },
    { kicker: "短讯", title: "28 纳米车规级 MCU 在合肥下线", text: "一期月产能 2,500 片晶圆，已通过 AEC-Q100 二级认证。" },
    { kicker: "短讯", title: "城六区新增 42 处错时共享停车位", text: "共 3,180 个车位，夜间月租 280 元。" },
    { kicker: "短讯", title: "城市马拉松 11 月 22 日开跑", text: "环线 3 座车站临时封闭，12 条公交线路绕行。" },
    { kicker: "深度", title: "一条环线，如何重画 800 万人的通勤半径", text: "45 分钟以内可达就业岗位的人口占比预计由 54% 升至 63%。" },
    { kicker: "深度", title: "隧道里的 26 台盾构", text: "32 米埋深下的 1,140 天，最慢一段每天只推进 4.2 米。" },
    { kicker: "深度", title: "夜班公交的最后一公里", text: "环线末班车 23:18，之后仍有 6 条夜班线路在等。" },
    { kicker: "观点", title: "把“站城一体化”的账算清楚", text: "612 亿元投资，票价无法覆盖，缺口需由土地增值与财政补贴承担。" },
    { kicker: "观点", title: "站厅要快，城市要慢", text: "环线 23 座车站中有 11 座出入口直接对着城市支路。" },
    { kicker: "图集", title: "今日影像：首班车与晚高峰", text: "4 张现场照片，记录 05:48 至 18:40 的环线首日。" },
    { kicker: "数字", title: "环线首末班车时刻（部分车站）", text: "望江路 05:42 首班、23:18 末班；外环首班顺延 8 分钟。" }
  ];

  function initSearch() {
    const dialog = $("#searchDialog");
    const openBtn = $("#searchBtn");
    const closeBtn = $("#searchClose");
    const input = $("#searchInput");
    const list = $("#searchList");
    const meta = $("#searchMeta");
    if (!dialog || !openBtn || !input || !list) return;

    const render = (keyword) => {
      const query = keyword.trim();
      const hits = query
        ? SEARCH_INDEX.filter((item) => (item.title + item.text + item.kicker).includes(query))
        : SEARCH_INDEX.slice(0, 5);

      list.replaceChildren();
      hits.forEach((item) => {
        const li = document.createElement("li");
        li.className = "search__item";

        const kicker = document.createElement("span");
        kicker.className = "search__kicker";
        kicker.textContent = item.kicker;

        const title = document.createElement("p");
        title.className = "search__hit";
        title.textContent = item.title;

        const text = document.createElement("p");
        text.className = "search__text";
        text.textContent = item.text;

        li.append(kicker, title, text);
        list.appendChild(li);
      });

      if (meta) {
        meta.textContent = query
          ? "“" + query + "” 命中 " + hits.length + " 条"
          : "演示索引共 " + SEARCH_INDEX.length + " 条，输入关键词即时筛选";
      }
    };

    openBtn.addEventListener("click", () => {
      render("");
      if (typeof dialog.showModal === "function") dialog.showModal();
      else dialog.setAttribute("open", "");
      input.value = "";
      input.focus();
    });

    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        if (typeof dialog.close === "function") dialog.close();
        else dialog.removeAttribute("open");
      });
    }

    input.addEventListener("input", () => render(input.value));

    dialog.addEventListener("click", (event) => {
      if (event.target !== dialog || typeof dialog.close !== "function") return;
      const rect = dialog.getBoundingClientRect();
      const outside = event.clientX < rect.left || event.clientX > rect.right ||
        event.clientY < rect.top || event.clientY > rect.bottom;
      if (outside) dialog.close();
    });
  }

  /* ==================== 8. 入场渐显 ==================== */
  function initReveal() {
    const items = $$("[data-reveal]");
    if (!items.length) return;

    if (motionQuery.matches || !hasIO) {
      items.forEach((el) => el.classList.add("is-in"));
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add("is-in");
          io.unobserve(entry.target);
        });
      },
      { rootMargin: "0px 0px -6% 0px", threshold: 0.08 }
    );

    items.forEach((el) => io.observe(el));
  }

  /* ==================== 9. 启动 ==================== */
  function init() {
    initTextSize();
    initTicker();
    initSectionNav();
    initPoll();
    initLongform();
    initSearch();
    initReveal();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
