THE LEDGER · 时纪日报 —— 纯静态新闻资讯主页
============================================================

一、站点说明
------------------------------------------------------------
· 主题：THE LEDGER，纸媒质感的新闻资讯头版（米白纸张 + 墨黑细线 + 朱红点缀）。
· 全部内容为虚构演示：新闻事件、机构、人名、引语、数字均非真实信息，
  仅用于版式与技术演示，页脚已注明。
· 零外部依赖：不使用 CDN、网络字体、第三方库、接口请求。
  图标为内联 SVG，字体只用系统字体栈，图片全部为本地 WebP。
· 直接双击 index.html（file://）或用任意静态服务器访问，表现一致。
· 交互（全部由 assets/js/main.js 绑定，无内联事件属性）：
  1. 顶部快讯无缝滚动（CSS 动画 + 内容复制一份），悬停暂停，
     右侧按钮可手动暂停/继续；prefers-reduced-motion 下停止动画并允许横向滚动。
  2. 版面锚点栏吸顶，滚动时用 IntersectionObserver 高亮当前版面并同步“当前”提示。
  3. 观点投票条：点击即计入并显示百分比与票数，结果写入 localStorage（try/catch）。
  4. 深度长文 <details> 折叠，摘要文案按实际段落数与字数自动生成。
  5. 报头字号切换 A− / A / A+，写入 localStorage。
  6. 报头检索按钮打开原生 <dialog>，对内置索引做即时筛选。
  7. 各版块入场渐显（IntersectionObserver，减少动态偏好下直接显示）。

二、文件清单
------------------------------------------------------------
06-news/
├── index.html                 单页结构（报头、快讯、版面锚点、要闻、深度、观点、
│                              图集、数字与时刻、编读、页脚、检索弹窗）
├── favicon.svg                站点图标（内联绘制，无外部引用）
├── README.txt                 本说明
└── assets/
    ├── css/style.css          单文件样式表，@layer 分层：
    │                          reset → tokens → base → layout → components → utilities
    ├── js/main.js             单文件经典脚本（defer），"use strict" + init* 函数
    └── img/
        ├── lead-story.webp    头版主图（首屏，fetchpriority=high，未懒加载）
        ├── city-transit.webp  图集：首班车驶离站台
        ├── photo-02.webp      深度报道配图
        ├── photo-03.webp      图集：换乘通道
        ├── photo-04.webp      图集：调度指挥中心
        └── photo-05.webp      图集：晚高峰接驳

三、本地预览
------------------------------------------------------------
方式 1：双击 index.html（file:// 直接打开）。
方式 2：任意静态服务器，例如在 06-news 目录下执行
        python -m http.server 8080
        然后访问 http://127.0.0.1:8080/

四、nginx 部署
------------------------------------------------------------
1）把 06-news 整个目录上传到服务器，例如 /var/www/06-news：

   sudo mkdir -p /var/www/06-news
   sudo cp -r 06-news/* /var/www/06-news/
   sudo chown -R www-data:www-data /var/www/06-news

2）站点配置 /etc/nginx/conf.d/06-news.conf：

   server {
       listen       80;
       server_name  news.example.com;
       root         /var/www/06-news;
       index        index.html;

       charset utf-8;

       # 单页站点：找不到文件时回退到首页
       location / {
           try_files $uri $uri/ /index.html;
       }

       # 静态资源长缓存（文件名不含指纹，故用 7 天）
       location ~* \.(?:css|js|webp|svg)$ {
           expires 7d;
           add_header Cache-Control "public, max-age=604800";
           access_log off;
       }

       # HTML 不缓存，便于更新
       location = /index.html {
           add_header Cache-Control "no-cache, must-revalidate";
       }

       # 站点无外部依赖，可收紧安全头
       add_header X-Content-Type-Options "nosniff" always;
       add_header Referrer-Policy "strict-origin-when-cross-origin" always;

       gzip on;
       gzip_types text/css application/javascript image/svg+xml;
       gzip_min_length 1024;
   }

3）校验并重载：

   sudo nginx -t
   sudo systemctl reload nginx

4）访问 http://news.example.com/ 即可。若部署在子路径（如 /news/），
   请把配置中的 location / 改为 location /news/，并确保 root 指向父目录。

五、兼容性与自检
------------------------------------------------------------
· 目标浏览器：Chrome/Edge 120+、Safari 17.4+、Firefox 121+。
· 使用了 @layer、oklch()、color-mix()、:has()、容器查询、dvh、text-wrap 等现代特性；
  prefers-reduced-motion 与 prefers-contrast 均有降级或增强处理。
· 自检命令（在仓库根目录执行）：
      node tools/check.mjs 06-news
  预期输出 PASS。
