/* ==========================================================================
   PIXEL RUN 像素游戏厅 — 交互与 Canvas 游戏引擎
   纯静态：所有数据内置，最高分保存在本机，无任何网络请求
   ========================================================================== */
"use strict";

(function () {

  /* ==================== 1. 静态配置（虚构数据） ==================== */
  const GAMES = {
    snake: {
      name: "贪吃蛇",
      en: "SNAKE",
      type: "街机 · 反应",
      level: "中等",
      metaLabel: "长度",
      readyKicker: "READY",
      readyTitle: "贪吃蛇 · 准备开始",
      readyText: "方向键或 WASD 控制方向，吃到黄色方块身体加长、速度加快；撞墙或咬到自己即结束。",
      hint: "方向键 / WASD 移动 · 空格暂停 · R 重开",
      canvasLabel: "贪吃蛇游戏画面：24 乘 15 的方格场地，使用方向键或 WASD 控制蛇的移动。",
      bestKey: "pixelrun:best:snake"
    },
    brick: {
      name: "打砖块",
      en: "BRICK",
      type: "街机 · 物理",
      level: "偏高",
      metaLabel: "生命",
      readyKicker: "READY",
      readyTitle: "打砖块 · 准备发球",
      readyText: "左右方向键或 A / D 移动挡板，空格发球。清空全部砖块进入下一关，三条命用完结束。",
      hint: "← → / A D 移动 · 空格发球 · P 暂停 · R 重开",
      canvasLabel: "打砖块游戏画面：使用左右方向键移动挡板，击碎上方五排砖块。",
      bestKey: "pixelrun:best:brick"
    },
    memory: {
      name: "记忆翻牌",
      en: "MEMORY",
      type: "益智 · 记忆",
      level: "轻松",
      metaLabel: "步数",
      readyKicker: "READY",
      readyTitle: "记忆翻牌 · 准备开始",
      readyText: "点按卡牌，或用方向键移动光标、空格翻牌，找出 8 对相同图案。用时越短，结算奖励越高。",
      hint: "方向键移动 · 空格翻牌 · P 暂停 · R 重开",
      canvasLabel: "记忆翻牌游戏画面：4 乘 4 共 16 张卡牌，使用方向键移动光标并按空格翻开卡牌。",
      bestKey: "pixelrun:best:memory"
    }
  };

  const ACHIEVEMENTS = [
    { id: "first-run", test: (s) => s.played.snake || s.played.brick || s.played.memory },
    { id: "snake-50", test: (s) => s.best.snake >= 50 },
    { id: "brick-100", test: (s) => s.best.brick >= 100 },
    { id: "memory-120", test: (s) => s.best.memory >= 120 },
    { id: "high-200", test: (s) => Math.max(s.best.snake, s.best.brick, s.best.memory) >= 200 },
    { id: "all-three", test: (s) => s.played.snake && s.played.brick && s.played.memory }
  ];

  const COLORS = {
    paper: "#fdfaf0",
    cream: "#f7f1e1",
    ink: "#1e1e24",
    red: "#e8452f",
    blue: "#2fafd6",
    yellow: "#f5c518"
  };

  /* 打砖块的虚拟坐标系：宽 100，高 62.5（与 16:10 画布一致） */
  const VIEW = { w: 100, h: 62.5 };
  const STEP = 1 / 60;

  /* ==================== 2. 工具 ==================== */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const clamp = (v, min, max) => Math.min(max, Math.max(min, v));

  /* localStorage 在 file:// 下可能直接抛错，全部包 try/catch */
  const Store = {
    get(key, fallback) {
      try {
        const raw = window.localStorage.getItem(key);
        if (raw === null) return fallback;
        const num = Number(raw);
        return Number.isFinite(num) ? num : fallback;
      } catch (err) {
        return fallback;
      }
    },
    set(key, value) {
      try {
        window.localStorage.setItem(key, String(value));
        return true;
      } catch (err) {
        return false;
      }
    }
  };

  /* ==================== 3. 运行时状态 ==================== */
  const stats = { best: { snake: 0, brick: 0, memory: 0 }, played: { snake: false, brick: false, memory: false } };
  let mode = "snake";
  let phase = "idle"; /* idle | playing | paused | over */
  let state = null;

  let canvas = null;
  let ctx = null;
  let W = 0;
  let H = 0;
  let dpr = 1;
  let raf = 0;
  let last = 0;
  let acc = 0;
  const keys = { left: false, right: false, up: false, down: false };

  const el = {
    stage: $("#stage"),
    overlay: $("#gameOverlay"),
    overlayKicker: $("#overlayKicker"),
    overlayTitle: $("#overlayTitle"),
    overlayText: $("#overlayText"),
    overlayBtn: $("#overlayBtn"),
    stageName: $("#stageName"),
    stageEn: $("#stageEn"),
    stageType: $("#stageType"),
    stageLevel: $("#stageLevel"),
    score: $("#scoreVal"),
    best: $("#bestVal"),
    metaLabel: $("#metaLabel"),
    meta: $("#metaVal"),
    status: $("#gameStatus"),
    startBtn: $("#startBtn"),
    startText: $("#startBtnText"),
    restartBtn: $("#restartBtn"),
    help: $("#stageHelp"),
    achCount: $("#achCount"),
    achProgress: $("#achProgress")
  };

  /* ==================== 4. 三个游戏的初始状态 ==================== */
  function makeSnake() {
    const s = {
      cols: 24,
      rows: 15,
      body: [{ x: 9, y: 7 }, { x: 8, y: 7 }, { x: 7, y: 7 }],
      dir: { x: 1, y: 0 },
      pending: [],
      food: { x: 15, y: 7 },
      step: 0.17,
      acc: 0,
      score: 0
    };
    placeFood(s);
    return s;
  }

  function placeFood(s) {
    const free = [];
    for (let y = 0; y < s.rows; y++) {
      for (let x = 0; x < s.cols; x++) {
        if (!s.body.some((p) => p.x === x && p.y === y)) free.push({ x, y });
      }
    }
    s.food = free.length ? free[Math.floor(Math.random() * free.length)] : { x: 0, y: 0 };
  }

  function makeBrick() {
    const bricks = [];
    for (let r = 0; r < 5; r++) {
      for (let c = 0; c < 10; c++) bricks.push({ r, c, alive: true });
    }
    return {
      bricks,
      left: bricks.length,
      paddle: { x: VIEW.w / 2, w: 17, h: 2.6, y: VIEW.h - 4.2 },
      ball: { x: VIEW.w / 2, y: VIEW.h - 7, vx: 0, vy: 0, r: 1.5, stuck: true },
      speed: 46,
      lives: 3,
      level: 1,
      score: 0,
      flash: 0
    };
  }

  const BRICK_PAD = 4;
  const BRICK_GAP = 1.1;
  const BRICK_W = (VIEW.w - BRICK_PAD * 2 - BRICK_GAP * 9) / 10;
  const BRICK_H = 3.1;
  const BRICK_COLORS = [COLORS.red, COLORS.red, COLORS.blue, COLORS.blue, COLORS.yellow];

  function brickRect(b) {
    return {
      x: BRICK_PAD + b.c * (BRICK_W + BRICK_GAP),
      y: 7 + b.r * (BRICK_H + BRICK_GAP),
      w: BRICK_W,
      h: BRICK_H
    };
  }

  function makeMemory() {
    const syms = [0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7];
    for (let i = syms.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const tmp = syms[i];
      syms[i] = syms[j];
      syms[j] = tmp;
    }
    return {
      cards: syms.map((sym) => ({ sym, matched: false, flip: 0, target: 0 })),
      first: -1,
      second: -1,
      lock: 0,
      cursor: 0,
      moves: 0,
      matches: 0,
      score: 0,
      elapsed: 0,
      done: false
    };
  }

  function makeState(id) {
    if (id === "brick") return makeBrick();
    if (id === "memory") return makeMemory();
    return makeSnake();
  }

  /* ==================== 5. 主循环（固定时间步长） ==================== */
  function loop(now) {
    raf = 0;
    if (phase !== "playing") return;
    if (!last) last = now;
    let delta = (now - last) / 1000;
    last = now;
    if (delta > 0.25) delta = 0.25;
    acc += delta;

    let guard = 0;
    while (acc >= STEP && guard < 6) {
      update(STEP);
      acc -= STEP;
      guard++;
      if (phase !== "playing") break;
    }

    render();
    paintHud();
    if (phase === "playing") raf = window.requestAnimationFrame(loop);
  }

  function startLoop() {
    if (raf) window.cancelAnimationFrame(raf);
    raf = 0;
    last = 0;
    acc = 0;
    raf = window.requestAnimationFrame(loop);
  }

  function stopLoop() {
    if (raf) window.cancelAnimationFrame(raf);
    raf = 0;
    last = 0;
    acc = 0;
  }

  function update(dt) {
    if (mode === "snake") updateSnake(dt);
    else if (mode === "brick") updateBrick(dt);
    else updateMemory(dt);
  }

  /* ==================== 6. 贪吃蛇 ==================== */
  function snakeTurn(dir) {
    const s = state;
    const map = { up: { x: 0, y: -1 }, down: { x: 0, y: 1 }, left: { x: -1, y: 0 }, right: { x: 1, y: 0 } };
    const d = map[dir];
    if (!d) return;
    const base = s.pending.length ? s.pending[s.pending.length - 1] : s.dir;
    if (base.x === -d.x && base.y === -d.y) return;
    if (base.x === d.x && base.y === d.y) return;
    if (s.pending.length < 2) s.pending.push(d);
  }

  function updateSnake(dt) {
    const s = state;
    s.acc += dt;
    let guard = 0;
    while (s.acc >= s.step && phase === "playing" && guard < 4) {
      s.acc -= s.step;
      stepSnake();
      guard++;
    }
  }

  function stepSnake() {
    const s = state;
    if (s.pending.length) s.dir = s.pending.shift();

    const head = s.body[0];
    const nx = head.x + s.dir.x;
    const ny = head.y + s.dir.y;

    if (nx < 0 || ny < 0 || nx >= s.cols || ny >= s.rows) {
      endGame("撞到边界");
      return;
    }

    const eating = nx === s.food.x && ny === s.food.y;
    const limit = eating ? s.body.length : s.body.length - 1;
    for (let i = 0; i < limit; i++) {
      if (s.body[i].x === nx && s.body[i].y === ny) {
        endGame("咬到自己");
        return;
      }
    }

    s.body.unshift({ x: nx, y: ny });
    if (eating) {
      s.score += 10;
      s.step = Math.max(0.075, s.step - 0.004);
      placeFood(s);
    } else {
      s.body.pop();
    }
  }

  /* ==================== 7. 打砖块 ==================== */
  function updateBrick(dt) {
    const s = state;
    const p = s.paddle;
    const move = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
    if (move) p.x = clamp(p.x + move * 62 * dt, p.w / 2, VIEW.w - p.w / 2);

    const b = s.ball;
    if (s.flash > 0) s.flash = Math.max(0, s.flash - dt * 4);

    if (b.stuck) {
      b.x = p.x;
      b.y = p.y - p.h / 2 - b.r - 0.4;
      return;
    }

    const prevX = b.x;
    const prevY = b.y;
    b.x += b.vx * dt;
    b.y += b.vy * dt;

    if (b.x - b.r < 0) { b.x = b.r; b.vx = Math.abs(b.vx); }
    if (b.x + b.r > VIEW.w) { b.x = VIEW.w - b.r; b.vx = -Math.abs(b.vx); }
    if (b.y - b.r < 0) { b.y = b.r; b.vy = Math.abs(b.vy); }

    const top = p.y - p.h / 2;
    if (b.vy > 0 && b.y + b.r >= top && b.y - b.r <= top + p.h &&
        b.x >= p.x - p.w / 2 - b.r && b.x <= p.x + p.w / 2 + b.r) {
      b.y = top - b.r;
      const offset = clamp((b.x - p.x) / (p.w / 2), -1, 1);
      const speed = Math.hypot(b.vx, b.vy) || s.speed;
      b.vx = offset * speed * 0.78;
      b.vy = -Math.sqrt(Math.max(0.12 * speed * speed, speed * speed - b.vx * b.vx));
      s.flash = 1;
    }

    for (let i = 0; i < s.bricks.length; i++) {
      const brick = s.bricks[i];
      if (!brick.alive) continue;
      const r = brickRect(brick);
      const cx = clamp(b.x, r.x, r.x + r.w);
      const cy = clamp(b.y, r.y, r.y + r.h);
      const dx = b.x - cx;
      const dy = b.y - cy;
      if (dx * dx + dy * dy > b.r * b.r) continue;

      brick.alive = false;
      s.left--;
      s.score += 5;

      if (prevY + b.r <= r.y) b.vy = -Math.abs(b.vy);
      else if (prevY - b.r >= r.y + r.h) b.vy = Math.abs(b.vy);
      else if (prevX + b.r <= r.x) b.vx = -Math.abs(b.vx);
      else if (prevX - b.r >= r.x + r.w) b.vx = Math.abs(b.vx);
      else b.vy = -b.vy;

      const speed = Math.hypot(b.vx, b.vy) || s.speed;
      const target = Math.min(78, speed * 1.012);
      b.vx *= target / speed;
      b.vy *= target / speed;
      s.flash = 1;
      break;
    }

    if (s.left === 0) {
      nextBrickLevel();
      return;
    }

    if (b.y - b.r > VIEW.h) loseBrickLife();
  }

  function nextBrickLevel() {
    const s = state;
    s.level++;
    s.speed = Math.min(78, s.speed * 1.08);
    s.bricks = s.bricks.map((b) => ({ r: b.r, c: b.c, alive: true }));
    s.left = s.bricks.length;
    s.score += 50;
    s.ball.stuck = true;
    s.ball.vx = 0;
    s.ball.vy = 0;
    setStatus("第 " + s.level + " 关开始 · 清空奖励 +50 分");
  }

  function loseBrickLife() {
    const s = state;
    s.lives--;
    if (s.lives <= 0) {
      endGame("三条命用完");
      return;
    }
    s.ball.stuck = true;
    s.ball.vx = 0;
    s.ball.vy = 0;
    setStatus("掉球了 · 还剩 " + s.lives + " 条命");
  }

  function launchBall() {
    if (mode !== "brick" || phase !== "playing") return;
    const s = state;
    const b = s.ball;
    if (!b.stuck) return;
    b.stuck = false;
    b.vx = (Math.random() < 0.5 ? -1 : 1) * s.speed * 0.42;
    b.vy = -Math.sqrt(s.speed * s.speed - b.vx * b.vx);
  }

  /* ==================== 8. 记忆翻牌 ==================== */
  function updateMemory(dt) {
    const s = state;
    if (!s.done) s.elapsed += dt;

    for (let i = 0; i < s.cards.length; i++) {
      const card = s.cards[i];
      const diff = card.target - card.flip;
      if (diff !== 0) {
        const stepLen = dt * 6;
        card.flip = Math.abs(diff) <= stepLen ? card.target : card.flip + Math.sign(diff) * stepLen;
      }
    }

    if (s.lock > 0) {
      s.lock -= dt;
      if (s.lock <= 0) resolveMemory();
    }
  }

  function moveCursor(dir) {
    const s = state;
    let col = s.cursor % 4;
    let row = Math.floor(s.cursor / 4);
    if (dir === "left") col = (col + 3) % 4;
    if (dir === "right") col = (col + 1) % 4;
    if (dir === "up") row = (row + 3) % 4;
    if (dir === "down") row = (row + 1) % 4;
    s.cursor = row * 4 + col;
  }

  function flipCard(index) {
    const s = state;
    if (phase !== "playing" || !s || !s.cards) return;
    const card = s.cards[index];
    if (!card || card.matched || card.target === 1 || s.lock > 0) return;

    card.target = 1;
    if (s.first < 0) {
      s.first = index;
      return;
    }
    if (s.second < 0) {
      s.second = index;
      s.moves++;
      s.lock = 0.8;
    }
  }

  function resolveMemory() {
    const s = state;
    const a = s.first >= 0 ? s.cards[s.first] : null;
    const b = s.second >= 0 ? s.cards[s.second] : null;

    if (a && b) {
      if (a.sym === b.sym) {
        a.matched = true;
        b.matched = true;
        s.matches++;
        s.score += 20;
        if (s.matches === 8) {
          finishMemory();
          return;
        }
        setStatus("配对成功 · 已找到 " + s.matches + " / 8 对");
      } else {
        s.score = Math.max(0, s.score - 5);
        a.target = 0;
        b.target = 0;
        setStatus("图案不同 · 分数 −5");
      }
    }

    s.first = -1;
    s.second = -1;
  }

  function finishMemory() {
    const s = state;
    const bonus = Math.max(0, 40 - Math.floor(s.elapsed / 2));
    s.score += bonus;
    s.done = true;
    endGame("用时 " + s.elapsed.toFixed(1) + " 秒，奖励 +" + bonus + " 分");
  }

  /* ==================== 9. 绘制 ==================== */
  function roundRect(x, y, w, h, r) {
    const rr = Math.max(0, Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2));
    ctx.beginPath();
    if (typeof ctx.roundRect === "function") ctx.roundRect(x, y, w, h, rr);
    else ctx.rect(x, y, w, h);
  }

  function clearScreen() {
    ctx.fillStyle = COLORS.paper;
    ctx.fillRect(0, 0, W, H);
  }

  function render() {
    if (!ctx || !state) return;
    if (mode === "snake") renderSnake();
    else if (mode === "brick") renderBrick();
    else renderMemory();
  }

  function renderSnake() {
    const s = state;
    clearScreen();
    const cell = Math.min(W / s.cols, H / s.rows);
    const ox = (W - cell * s.cols) / 2;
    const oy = (H - cell * s.rows) / 2;

    ctx.strokeStyle = "rgba(30,30,36,0.09)";
    ctx.lineWidth = 1;
    for (let x = 0; x <= s.cols; x++) {
      const px = Math.round(ox + x * cell) + 0.5;
      ctx.beginPath();
      ctx.moveTo(px, oy);
      ctx.lineTo(px, oy + cell * s.rows);
      ctx.stroke();
    }
    for (let y = 0; y <= s.rows; y++) {
      const py = Math.round(oy + y * cell) + 0.5;
      ctx.beginPath();
      ctx.moveTo(ox, py);
      ctx.lineTo(ox + cell * s.cols, py);
      ctx.stroke();
    }

    const fx = ox + s.food.x * cell;
    const fy = oy + s.food.y * cell;
    ctx.fillStyle = COLORS.yellow;
    ctx.strokeStyle = COLORS.ink;
    ctx.lineWidth = Math.max(2, cell * 0.1);
    roundRect(fx + cell * 0.18, fy + cell * 0.18, cell * 0.64, cell * 0.64, cell * 0.16);
    ctx.fill();
    ctx.stroke();

    for (let i = s.body.length - 1; i >= 0; i--) {
      const seg = s.body[i];
      const x = ox + seg.x * cell;
      const y = oy + seg.y * cell;
      const inset = cell * 0.07;
      ctx.fillStyle = i === 0 ? COLORS.ink : COLORS.red;
      ctx.strokeStyle = COLORS.ink;
      ctx.lineWidth = Math.max(1.5, cell * 0.08);
      roundRect(x + inset, y + inset, cell - inset * 2, cell - inset * 2, cell * 0.24);
      ctx.fill();
      ctx.stroke();
    }

    const head = s.body[0];
    const hx = ox + head.x * cell + cell / 2;
    const hy = oy + head.y * cell + cell / 2;
    const px = -s.dir.y;
    const py = s.dir.x;
    const eye = Math.max(1.2, cell * 0.075);
    ctx.fillStyle = COLORS.paper;
    ctx.beginPath();
    ctx.arc(hx + s.dir.x * cell * 0.16 + px * cell * 0.17, hy + s.dir.y * cell * 0.16 + py * cell * 0.17, eye, 0, Math.PI * 2);
    ctx.arc(hx + s.dir.x * cell * 0.16 - px * cell * 0.17, hy + s.dir.y * cell * 0.16 - py * cell * 0.17, eye, 0, Math.PI * 2);
    ctx.fill();
  }

  function renderBrick() {
    const s = state;
    clearScreen();
    const k = Math.min(W / VIEW.w, H / VIEW.h);
    const ox = (W - VIEW.w * k) / 2;
    const oy = (H - VIEW.h * k) / 2;

    for (let i = 0; i < s.bricks.length; i++) {
      const brick = s.bricks[i];
      if (!brick.alive) continue;
      const r = brickRect(brick);
      ctx.fillStyle = BRICK_COLORS[brick.r];
      ctx.strokeStyle = COLORS.ink;
      ctx.lineWidth = Math.max(1.5, 1.8 * k);
      roundRect(ox + r.x * k, oy + r.y * k, r.w * k, r.h * k, 3 * k);
      ctx.fill();
      ctx.stroke();
    }

    const p = s.paddle;
    const px = ox + (p.x - p.w / 2) * k;
    const py = oy + (p.y - p.h / 2) * k;
    ctx.fillStyle = COLORS.ink;
    roundRect(px, py, p.w * k, p.h * k, (p.h * k) / 2);
    ctx.fill();
    ctx.fillStyle = COLORS.yellow;
    roundRect(px + 2 * k, py + 2 * k, p.w * k - 4 * k, p.h * k * 0.34, (p.h * k) / 4);
    ctx.fill();

    const b = s.ball;
    ctx.fillStyle = COLORS.ink;
    ctx.beginPath();
    ctx.arc(ox + b.x * k, oy + b.y * k, Math.max(3, b.r * k), 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = COLORS.paper;
    ctx.beginPath();
    ctx.arc(ox + b.x * k - b.r * k * 0.28, oy + b.y * k - b.r * k * 0.28, Math.max(1, b.r * k * 0.3), 0, Math.PI * 2);
    ctx.fill();

    if (s.flash > 0) {
      ctx.strokeStyle = "rgba(30,30,36," + (s.flash * 0.25).toFixed(3) + ")";
      ctx.lineWidth = 6;
      ctx.strokeRect(ox + 3, oy + 3, VIEW.w * k - 6, VIEW.h * k - 6);
    }
  }

  function memoryMetrics() {
    const gap = Math.max(4, Math.min(W, H) * 0.018);
    const pad = Math.max(6, Math.min(W, H) * 0.035);
    const size = Math.min((W - pad * 2 - gap * 3) / 4, (H - pad * 2 - gap * 3) / 4);
    const total = size * 4 + gap * 3;
    return { gap, size, ox: (W - total) / 2, oy: (H - total) / 2 };
  }

  function renderMemory() {
    const s = state;
    clearScreen();
    const m = memoryMetrics();

    for (let i = 0; i < s.cards.length; i++) {
      const card = s.cards[i];
      const col = i % 4;
      const row = Math.floor(i / 4);
      const x = m.ox + col * (m.size + m.gap);
      const y = m.oy + row * (m.size + m.gap);
      const squash = Math.max(0.08, Math.abs(Math.cos(Math.PI * card.flip)));
      const w = m.size * squash;
      const cx = x + m.size / 2;
      drawCard(cx - w / 2, y, w, m.size, card, i === s.cursor);
    }
  }

  function drawCard(x, y, w, h, card, focused) {
    const front = card.flip > 0.5;
    ctx.save();

    ctx.fillStyle = "rgba(30,30,36,0.9)";
    roundRect(x + 3, y + 4, w, h, 8);
    ctx.fill();

    ctx.fillStyle = front ? COLORS.paper : COLORS.blue;
    ctx.strokeStyle = COLORS.ink;
    ctx.lineWidth = 3;
    roundRect(x, y, w, h, 8);
    ctx.fill();
    ctx.stroke();

    if (front) {
      drawSymbol(card.sym, x + w / 2, y + h / 2, Math.min(w, h) * 0.52);
    } else {
      const dot = Math.max(2.5, w * 0.055);
      const gap = dot * 2.1;
      ctx.fillStyle = "rgba(30,30,36,0.42)";
      for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 3; c++) {
          ctx.fillRect(x + w / 2 + (c - 1) * gap - dot / 2, y + h / 2 + (r - 1) * gap - dot / 2, dot, dot);
        }
      }
    }

    if (card.matched) {
      ctx.fillStyle = "rgba(245,197,24,0.55)";
      roundRect(x, y, w, h, 8);
      ctx.fill();
      ctx.strokeStyle = COLORS.ink;
      ctx.lineWidth = 3;
      roundRect(x, y, w, h, 8);
      ctx.stroke();
      ctx.strokeStyle = COLORS.ink;
      ctx.lineWidth = Math.max(3, w * 0.06);
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.beginPath();
      ctx.moveTo(x + w * 0.28, y + h * 0.52);
      ctx.lineTo(x + w * 0.45, y + h * 0.68);
      ctx.lineTo(x + w * 0.74, y + h * 0.32);
      ctx.stroke();
    }

    if (focused) {
      ctx.setLineDash([6, 5]);
      ctx.strokeStyle = COLORS.ink;
      ctx.lineWidth = 2;
      roundRect(x - 5, y - 5, w + 10, h + 10, 10);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    ctx.restore();
  }

  function drawSymbol(sym, cx, cy, size) {
    const fills = [COLORS.red, COLORS.blue, COLORS.yellow, COLORS.red, COLORS.blue, COLORS.yellow, COLORS.red, COLORS.blue];
    ctx.save();
    ctx.fillStyle = fills[sym] || COLORS.yellow;
    ctx.beginPath();
    ctx.arc(cx, cy, size * 0.8, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = COLORS.ink;
    ctx.fillStyle = COLORS.ink;
    ctx.lineWidth = Math.max(2.5, size * 0.12);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    const r = size * 0.52;

    ctx.beginPath();
    if (sym === 0) {
      ctx.arc(cx, cy, r * 0.82, 0, Math.PI * 2);
      ctx.stroke();
    } else if (sym === 1) {
      ctx.rect(cx - r * 0.8, cy - r * 0.8, r * 1.6, r * 1.6);
      ctx.stroke();
    } else if (sym === 2) {
      ctx.moveTo(cx, cy - r);
      ctx.lineTo(cx + r * 0.95, cy + r * 0.75);
      ctx.lineTo(cx - r * 0.95, cy + r * 0.75);
      ctx.closePath();
      ctx.stroke();
    } else if (sym === 3) {
      ctx.moveTo(cx, cy - r);
      ctx.lineTo(cx + r * 0.9, cy);
      ctx.lineTo(cx, cy + r);
      ctx.lineTo(cx - r * 0.9, cy);
      ctx.closePath();
      ctx.stroke();
    } else if (sym === 4) {
      for (let i = 0; i < 10; i++) {
        const rad = i % 2 === 0 ? r : r * 0.46;
        const ang = -Math.PI / 2 + (i * Math.PI) / 5;
        const px = cx + Math.cos(ang) * rad;
        const py = cy + Math.sin(ang) * rad;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
    } else if (sym === 5) {
      ctx.moveTo(cx - r * 0.85, cy);
      ctx.lineTo(cx + r * 0.85, cy);
      ctx.moveTo(cx, cy - r * 0.85);
      ctx.lineTo(cx, cy + r * 0.85);
      ctx.stroke();
    } else if (sym === 6) {
      ctx.moveTo(cx - r, cy + r * 0.55);
      ctx.lineTo(cx - r * 0.3, cy - r * 0.55);
      ctx.lineTo(cx + r * 0.3, cy + r * 0.55);
      ctx.lineTo(cx + r, cy - r * 0.55);
      ctx.stroke();
    } else {
      ctx.moveTo(cx - r * 0.85, cy - r * 0.35);
      ctx.lineTo(cx + r * 0.85, cy - r * 0.35);
      ctx.moveTo(cx - r * 0.85, cy + r * 0.35);
      ctx.lineTo(cx + r * 0.85, cy + r * 0.35);
      ctx.stroke();
    }

    ctx.restore();
  }

  /* ==================== 10. 流程控制 ==================== */
  function setStatus(text) {
    el.status.textContent = text;
  }

  function metaValue() {
    if (!state) return "—";
    if (mode === "snake") return String(state.body.length);
    if (mode === "brick") return String(state.lives);
    return String(state.moves);
  }

  function paintHud() {
    if (!state) return;
    const score = String(state.score);
    const best = String(stats.best[mode]);
    const meta = metaValue();
    if (el.score.textContent !== score) el.score.textContent = score;
    if (el.best.textContent !== best) el.best.textContent = best;
    if (el.meta.textContent !== meta) el.meta.textContent = meta;
  }

  function updateStartBtn() {
    let text = "开始";
    let icon = "#i-play";
    if (phase === "playing") {
      text = "暂停";
      icon = "#i-pause";
    } else if (phase === "paused") {
      text = "继续";
      icon = "#i-play";
    } else if (phase === "over") {
      text = "再来一局";
      icon = "#i-restart";
    }
    el.startText.textContent = text;
    const use = el.startBtn.querySelector("use");
    if (use) use.setAttribute("href", icon);
  }

  function showOverlay(kind) {
    const g = GAMES[mode];
    let kicker = g.readyKicker;
    let title = g.readyTitle;
    let text = g.readyText;
    let label = "开始游戏";

    if (kind === "paused") {
      kicker = "PAUSED";
      title = "已暂停";
      text = "按「继续」或空格键回到游戏，本局进度会保留。";
      label = "继续";
    } else if (kind === "over") {
      kicker = "GAME OVER";
      title = "本局结束";
      text = "本局 " + state.score + " 分，最高分 " + stats.best[mode] + " 分。换个思路再来一局。";
      label = "再来一局";
    }

    el.overlayKicker.textContent = kicker;
    el.overlayTitle.textContent = title;
    el.overlayText.textContent = text;
    el.overlayBtn.textContent = label;
    el.overlay.hidden = false;
  }

  function hideOverlay() {
    const active = document.activeElement;
    el.overlay.hidden = true;
    if (active && el.overlay.contains(active) && canvas) {
      try {
        canvas.focus({ preventScroll: true });
      } catch (err) {
        canvas.focus();
      }
    }
  }

  function begin() {
    stopLoop();
    state = makeState(mode);
    phase = "playing";
    hideOverlay();
    updateStartBtn();
    paintHud();
    setStatus("游戏进行中 · " + GAMES[mode].hint);
    startLoop();
  }

  function pause() {
    if (phase !== "playing") return;
    phase = "paused";
    stopLoop();
    render();
    paintHud();
    showOverlay("paused");
    updateStartBtn();
    setStatus("已暂停 · 按空格或 P 继续");
  }

  function resume() {
    if (phase !== "paused") return;
    phase = "playing";
    hideOverlay();
    updateStartBtn();
    setStatus("游戏进行中 · " + GAMES[mode].hint);
    startLoop();
  }

  function togglePause() {
    if (phase === "playing") pause();
    else if (phase === "paused") resume();
    else begin();
  }

  function endGame(reason) {
    phase = "over";
    stopLoop();

    const score = state && typeof state.score === "number" ? state.score : 0;
    stats.played[mode] = true;
    Store.set("pixelrun:played:" + mode, 1);

    let record = false;
    if (score > stats.best[mode]) {
      stats.best[mode] = score;
      Store.set(GAMES[mode].bestKey, score);
      record = true;
    }

    render();
    paintHud();
    refreshBestLabels();
    refreshAchievements();
    updateStartBtn();
    showOverlay("over");
    setStatus((record ? "新纪录！" : "本局结束。") + "得分 " + score + " 分，最高分 " + stats.best[mode] + " 分" +
      (reason ? "（" + reason + "）" : ""));
  }

  function primaryAction() {
    if (phase === "playing") pause();
    else if (phase === "paused") resume();
    else begin();
  }

  function setGame(id) {
    if (!GAMES[id] || id === mode) return;
    stopLoop();
    mode = id;
    state = makeState(mode);
    phase = "idle";

    const g = GAMES[id];
    el.stageName.textContent = g.name;
    el.stageEn.textContent = g.en;
    el.stageType.textContent = g.type;
    el.stageLevel.textContent = g.level;
    el.metaLabel.textContent = g.metaLabel;
    el.help.textContent = g.hint;
    canvas.setAttribute("aria-label", g.canvasLabel);

    updateStartBtn();
    paintHud();
    showOverlay("idle");
    render();
    refreshCards();
    setStatus("已加载「" + g.name + "」 · 按开始或空格开局");
  }

  /* ==================== 11. 卡片 / 成就 / 最高分 ==================== */
  function refreshCards() {
    $$("[data-game]").forEach((card) => {
      const on = card.dataset.game === mode;
      card.classList.toggle("is-active", on);
      const badge = card.querySelector("[data-badge]");
      if (badge) badge.textContent = on ? "正在游玩" : "可挑战";
      if (on) card.setAttribute("aria-current", "true");
      else card.removeAttribute("aria-current");
    });
  }

  function refreshBestLabels() {
    $$("[data-best-for]").forEach((node) => {
      const key = node.dataset.bestFor;
      if (key && Object.prototype.hasOwnProperty.call(stats.best, key)) {
        node.textContent = String(stats.best[key]);
      }
    });
  }

  function refreshAchievements() {
    let unlocked = 0;
    for (let i = 0; i < ACHIEVEMENTS.length; i++) {
      const a = ACHIEVEMENTS[i];
      const on = Boolean(a.test(stats));
      if (on) unlocked++;
      const item = document.querySelector('[data-ach="' + a.id + '"]');
      if (!item) continue;
      item.classList.toggle("is-unlocked", on);
      const label = item.querySelector(".badge__state");
      if (label) label.textContent = on ? "已解锁" : "未解锁";
    }
    el.achCount.textContent = String(unlocked);
    el.achProgress.value = unlocked;
    el.achProgress.textContent = unlocked + " / " + ACHIEVEMENTS.length;
  }

  /* ==================== 12. 输入 ==================== */
  function press(dir) {
    if (dir === "act") {
      if (mode === "memory" && phase === "playing") flipCard(state.cursor);
      else togglePause();
      return;
    }

    if (phase === "idle" || phase === "over") begin();
    else if (phase === "paused") resume();

    if (mode === "snake") {
      snakeTurn(dir);
    } else if (mode === "brick") {
      if (dir === "left") keys.left = true;
      if (dir === "right") keys.right = true;
      if (dir === "up") launchBall();
    } else if (mode === "memory") {
      moveCursor(dir);
    }
  }

  function release(dir) {
    if (dir === "left") keys.left = false;
    if (dir === "right") keys.right = false;
    if (dir === "up") keys.up = false;
    if (dir === "down") keys.down = false;
  }

  function handleKey(e) {
    const key = e.key;
    const lower = key.length === 1 ? key.toLowerCase() : key;
    const isDir = key === "ArrowUp" || key === "ArrowDown" || key === "ArrowLeft" || key === "ArrowRight";
    const isSpace = key === " " || key === "Spacebar";

    /* 焦点在游戏台内时，方向键与空格不再滚动页面 */
    if (isDir || isSpace) e.preventDefault();

    if (key === "ArrowUp" || lower === "w") { press("up"); return; }
    if (key === "ArrowDown" || lower === "s") { press("down"); return; }
    if (key === "ArrowLeft" || lower === "a") { press("left"); return; }
    if (key === "ArrowRight" || lower === "d") { press("right"); return; }

    if (isSpace) {
      if (mode === "memory" && phase === "playing") {
        flipCard(state.cursor);
        return;
      }
      if (mode === "brick" && phase === "playing" && state.ball.stuck) {
        launchBall();
        return;
      }
      togglePause();
      return;
    }

    if (key === "Enter") { primaryAction(); return; }
    if (lower === "p") { togglePause(); return; }
    if (lower === "r") { begin(); return; }
  }

  /* ==================== 13. 初始化 ==================== */
  function initStorage() {
    Object.keys(GAMES).forEach((id) => {
      stats.best[id] = Store.get(GAMES[id].bestKey, 0);
      stats.played[id] = Store.get("pixelrun:played:" + id, 0) === 1;
    });
  }

  function initCanvas() {
    canvas = $("#gameCanvas");
    if (!canvas) return false;
    ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return false;

    state = makeState(mode);

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      dpr = clamp(window.devicePixelRatio || 1, 1, 2);
      W = Math.max(1, Math.round(rect.width));
      H = Math.max(1, Math.round(rect.height));
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      render();
      paintHud();
    };

    resize();
    if (typeof window.ResizeObserver === "function") {
      const ro = new ResizeObserver(resize);
      ro.observe(canvas);
    } else {
      window.addEventListener("resize", resize);
    }
    return true;
  }

  function initControls() {
    el.startBtn.addEventListener("click", primaryAction);
    el.restartBtn.addEventListener("click", begin);
    el.overlayBtn.addEventListener("click", primaryAction);

    el.stage.addEventListener("keydown", handleKey);

    $$(".dpad__btn").forEach((btn) => {
      const dir = btn.dataset.dir;
      btn.addEventListener("pointerdown", (e) => {
        e.preventDefault();
        btn.classList.add("is-down");
        press(dir);
      });
      const up = () => {
        btn.classList.remove("is-down");
        release(dir);
      };
      btn.addEventListener("pointerup", up);
      btn.addEventListener("pointercancel", up);
      btn.addEventListener("pointerleave", up);
      btn.addEventListener("contextmenu", (e) => e.preventDefault());
    });

    canvas.addEventListener("pointerdown", () => {
      try {
        canvas.focus({ preventScroll: true });
      } catch (err) {
        canvas.focus();
      }
    });

    canvas.addEventListener("pointerdown", (e) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      if (mode === "memory") {
        if (phase === "idle" || phase === "over") begin();
        const m = memoryMetrics();
        const col = Math.floor((x - m.ox) / (m.size + m.gap));
        const row = Math.floor((y - m.oy) / (m.size + m.gap));
        if (col < 0 || col > 3 || row < 0 || row > 3) return;
        const index = row * 4 + col;
        state.cursor = index;
        flipCard(index);
      } else if (mode === "brick") {
        if (phase === "idle" || phase === "over") begin();
        launchBall();
      }
    });

    canvas.addEventListener("pointermove", (e) => {
      if (mode !== "brick" || phase !== "playing") return;
      const rect = canvas.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * VIEW.w;
      state.paddle.x = clamp(x, state.paddle.w / 2, VIEW.w - state.paddle.w / 2);
    });
  }

  function initCards() {
    $$("[data-game]").forEach((card) => {
      card.addEventListener("click", () => setGame(card.dataset.game));
    });
  }

  function initVisibility() {
    document.addEventListener("visibilitychange", () => {
      if (document.hidden && phase === "playing") pause();
    });
  }

  function initReveal() {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const items = $$(".sec-head, .cards__item, .badge, .log__item, .journal__fig, .ranks, .ach__panel");
    if (reduce || !("IntersectionObserver" in window)) {
      items.forEach((item) => item.classList.add("reveal", "is-in"));
      return;
    }
    items.forEach((item) => item.classList.add("reveal"));
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-in");
        io.unobserve(entry.target);
      });
    }, { rootMargin: "0px 0px -6% 0px", threshold: 0.1 });
    items.forEach((item) => io.observe(item));
  }

  function init() {
    initStorage();
    if (!initCanvas()) return;

    initControls();
    initCards();
    initVisibility();
    initReveal();

    refreshCards();
    refreshBestLabels();
    refreshAchievements();
    updateStartBtn();
    showOverlay("idle");
    paintHud();
    render();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
