PIXEL RUN 像素游戏厅 · 静态站点说明
================================================

一、这是什么
------------------------------------------------
一个纯静态、零外部依赖的单页游戏站主页。三款小游戏（贪吃蛇、打砖块、记忆翻牌）
全部由 Canvas 逐帧绘制，游戏本体不依赖任何图片素材；页面图片只用于游戏库封面与
更新日志配图。最高分与成就在浏览器本地计算，不上传任何数据。

二、文件清单
------------------------------------------------
index.html                 单页结构（顶栏、游戏台、本周排行、游戏库、成就、更新日志、页脚）
favicon.svg                站点图标（内联图形，无外部字体）
README.txt                 本说明
assets/css/style.css       单文件样式表，@layer 分层：reset / tokens / base / layout / components / utilities
assets/js/main.js          单文件经典脚本（defer 加载，无 import/export）
assets/img/arcade-cabinet.webp    游戏库封面：贪吃蛇
assets/img/controller-hands.webp  游戏库封面：打砖块
assets/img/esports-stage.webp     游戏库封面：记忆翻牌
assets/img/arcade-row.webp        更新日志配图：线下试玩区

三、操作方式
------------------------------------------------
贪吃蛇：方向键 / WASD 转向，空格暂停，R 重开。吃到黄色方块 +10 分并加速。
打砖块：← → 或 A / D 移动挡板，空格发球，P 暂停，R 重开。每块砖 +5 分，
        清空一层 +50 分并进入下一关，三条命用完结束。
记忆翻牌：点按卡牌，或用方向键移动光标、空格翻牌。每对 +20 分，错配 −5 分，
        8 对全部配对后按用时结算奖励（最多 +40 分）。
通用：窄屏或触屏设备会显示虚拟方向键，中央「A」键为动作键（翻牌 / 暂停）。
      焦点在游戏台内时，方向键与空格不会滚动页面；切换标签页会自动暂停。

四、部署方式（nginx）
------------------------------------------------
1) 把整个 05-game 目录上传到服务器，例如 /var/www/pixel-run；
2) 在 nginx 配置中加入：

   server {
       listen 80;
       server_name game.example.com;

       root /var/www/pixel-run;
       index index.html;

       charset utf-8;

       location / {
           try_files $uri $uri/ /index.html;
       }

       location ~* \.(css|js|svg|webp)$ {
           expires 30d;
           add_header Cache-Control "public, max-age=2592000, immutable";
       }

       location = /index.html {
           add_header Cache-Control "no-cache";
       }

       gzip on;
       gzip_types text/css application/javascript image/svg+xml;
   }

3) 重载配置：nginx -t && nginx -s reload
4) 浏览器访问 http://game.example.com/ 即可。

提示：本站没有构建步骤，也可以直接双击 index.html 用 file:// 打开。部分浏览器在
file:// 下会禁用 localStorage，此时最高分无法保存，但游戏本身仍可正常游玩。

五、技术要点
------------------------------------------------
- 零外部请求：无 CDN、无网络字体、无第三方库，图标全部为内联 SVG。
- Canvas 按 devicePixelRatio 缩放，并用 ResizeObserver 跟随容器尺寸重绘。
- 主循环 requestAnimationFrame + 固定时间步长（1/60 秒），页面隐藏时暂停。
- 视觉：奶油底 oklch(0.96 0.02 95)、墨黑 oklch(0.2 0.01 280)，红 / 蓝 / 黄撞色，
  2–3px 描边配无模糊的偏移硬阴影，动效仅使用 transform 与 opacity。
- 响应式断点 640 / 900 / 1200，320px 宽不产生横向滚动。
- 已适配 prefers-reduced-motion：装饰动效降级，游戏本身保留。
- 所有数据为内置虚构样本，仅供演示。

六、许可
------------------------------------------------
页面代码与虚构文案可自由取用；图片素材来自公共图库，仅作演示用途。
