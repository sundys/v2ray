NOCTURNE 夜曲 · 深夜黑金音乐电台 — 静态站点说明
====================================================

一、这是什么
----------------------------------------------------
一个纯静态的单页音乐站点主页，主题为「深夜黑金 + 波形可视化」。
所有曲目、榜单、艺人、播放量均为内置的虚构样本，用于展示版式与交互；
页面不加载任何音频文件，也不发起任何网络请求，播放条与波形都是可视化模拟。

二、文件清单
----------------------------------------------------
index.html                    单页结构：顶栏 / 主视觉（正在播放 + 本周热榜）/
                              新专辑 / 深夜电台与歌单 / 驻站艺人 / 页脚 + 底部播放条
favicon.svg                   站点图标（近黑底 + 香槟金波形）
README.txt                    本说明文件
assets/css/style.css          单文件样式表，@layer 分层：
                              reset → tokens → base → layout → components → utilities
assets/js/main.js             单文件经典脚本（defer 加载，无 import/export）：
                              榜单渲染、播放模拟、Canvas 波形、滚动与入场动画
assets/img/album-nocturne.webp    正在播放专辑《午夜调频》封面
assets/img/album-neon-rain.webp   新专辑《霓虹雨》封面
assets/img/album-deep-blue.webp   新专辑《深蓝频率》封面
assets/img/album-live-hall.webp   新专辑《城市现场 · 上海站》封面
assets/img/radio-studio.webp      深夜电台直播间 / 电台合辑封面

三、技术要点
----------------------------------------------------
1. 零外部依赖：没有 CDN、网络字体、第三方库；图标全部为 HTML 内联 SVG 精灵。
   字体只使用系统字体栈（无衬线正文 + 宋体标题 + 等宽数字标签）。
2. 无构建步骤：双击 index.html 以 file:// 打开，与在 nginx 下访问表现一致。
3. 现代 CSS：@layer、自定义属性、clamp()、oklch()、color-mix()、:has()、
   容器查询（@container）、aspect-ratio、逻辑属性、dvh。
4. 交互全部由 addEventListener 绑定，HTML 中没有内联事件属性。
5. Canvas 波形按 devicePixelRatio 缩放，ResizeObserver 自适应，
   页面隐藏时暂停，prefers-reduced-motion 下改为静态绘制。
6. 无障碍：skip-link、单一 h1、tablist 方向键切换、range 控件原生键盘支持、
   aria-live 播报曲目与循环模式变化、:focus-visible 焦点环、图片均有 alt。

四、本地预览
----------------------------------------------------
方式一（推荐，最接近线上）：直接双击 index.html，用现代浏览器打开。
方式二（如需 http 环境）：在站点目录启动任意静态服务器，例如
    python -m http.server 8080
然后访问 http://127.0.0.1:8080/

五、nginx 部署
----------------------------------------------------
把 02-music 整个目录上传到服务器，例如 /var/www/nocturne，然后：

    server {
        listen 80;
        server_name nocturne.example.com;

        root /var/www/nocturne;
        index index.html;

        charset utf-8;

        location / {
            try_files $uri $uri/ /index.html;
        }

        # 静态资源长缓存，HTML 不缓存，方便更新
        location ~* \.(?:css|js|webp|svg|woff2?)$ {
            expires 30d;
            add_header Cache-Control "public, max-age=2592000, immutable";
        }

        location = /index.html {
            add_header Cache-Control "no-cache";
        }

        # 站点不需要任何外部请求，可顺手加上安全响应头
        add_header X-Content-Type-Options "nosniff";
        add_header Referrer-Policy "strict-origin-when-cross-origin";
        add_header X-Frame-Options "SAMEORIGIN";

        gzip on;
        gzip_types text/css application/javascript image/svg+xml;

        error_page 404 /index.html;
    }

启用配置：

    sudo ln -s /etc/nginx/sites-available/nocturne /etc/nginx/sites-enabled/
    sudo nginx -t
    sudo systemctl reload nginx

若使用 HTTPS，用 certbot 申请证书后由它自动补全 443 server 块即可，
站点本身不依赖任何外部域名，无需额外 CSP 白名单。

六、内容声明
----------------------------------------------------
站内的专辑名、艺人名、曲目、播放量、榜单名次、备案号与联系方式均为虚构，
仅用于静态页面演示；如有雷同纯属巧合。页面不提供真实音频播放与下载。
