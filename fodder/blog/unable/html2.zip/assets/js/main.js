/* ==========================================================================
   NOCTURNE 夜曲 — 交互脚本
   纯静态演示：所有曲目、榜单与播放数据均为内置虚构样本，不加载音频、不发起请求
   ========================================================================== */
"use strict";

(function () {
  document.documentElement.classList.add("js");

  /* ==================== 1. 数据（虚构样本） ==================== */
  const ALBUMS = {
    nocturne: { title: "午夜调频", cover: "assets/img/album-nocturne.webp", date: "2026-10-23", alt: "黑胶唱机与暖色灯光" },
    neon: { title: "霓虹雨", cover: "assets/img/album-neon-rain.webp", date: "2026-11-06", alt: "夜色中的舞台灯光与设备" },
    deepblue: { title: "深蓝频率", cover: "assets/img/album-deep-blue.webp", date: "2026-11-11", alt: "深蓝灯光下的耳机与录音设备" },
    live: { title: "城市现场 · 上海站", cover: "assets/img/album-live-hall.webp", date: "2026-10-31", alt: "演出现场的灯光与人潮" },
    insomnia: { title: "失眠者俱乐部", cover: "assets/img/radio-studio.webp", date: "2026-11-02", alt: "深夜录音室的耳机与调音设备" }
  };

  const TRACKS = [
    {
      id: "t1", title: "夜航西飞", artist: "林知夏", album: "nocturne",
      genre: "暗潮流行", bpm: 82, key: "A 小调", dur: 252, plays: "128.4 万",
      note: "整张专辑都在凌晨一点到四点之间录制：磁带底噪、走廊回声、楼下便利店的门铃声全部保留。第二段副歌之后突然抽掉鼓组，只留一台走音的 Rhodes 电钢，是今年最克制的编曲处理。"
    },
    {
      id: "t2", title: "霓虹雨", artist: "陈默", album: "neon",
      genre: "合成器流行", bpm: 104, key: "F♯ 小调", dur: 228, plays: "96.7 万",
      note: "合成器的节奏采样自雨刷器，副歌叠了七层人声；混音师把 4 kHz 以上削掉 3 dB，听起来像隔着车窗看整条街的灯。"
    },
    {
      id: "t3", title: "凌晨四点的便利店", artist: "苏野", album: "live",
      genre: "独立摇滚", bpm: 128, key: "D 大调", dur: 276, plays: "88.2 万",
      note: "录于武汉街道口一家 24 小时便利店，收银机的提示音成了间奏；主唱刻意保留了换气声，鼓组只用了三支麦克风。"
    },
    {
      id: "t4", title: "玻璃海", artist: "何岸", album: "deepblue",
      genre: "氛围后摇", bpm: 68, key: "C 小调", dur: 362, plays: "54.9 万",
      note: "九分钟的器乐，前四分钟只有海浪与一台 Fender Rhodes，第五分钟鼓组才进来，像潮水慢慢漫过脚踝又退回去。"
    },
    {
      id: "t5", title: "回声里的你", artist: "林知夏", album: "nocturne",
      genre: "暗潮流行", bpm: 76, key: "E 小调", dur: 245, plays: "112.3 万",
      note: "人声在楼梯间录了三遍，最后选的是混响最长的那一条；尾奏那声呼吸没有剪掉，制作人说那是整首歌最贵的部分。"
    },
    {
      id: "t6", title: "慢速电梯", artist: "陈默", album: "neon",
      genre: "城市电子", bpm: 118, key: "G 小调", dur: 214, plays: "73.5 万",
      note: "118 BPM 的慢速车库，低音线采样自老式电梯的钢缆摩擦声，中段那段失真的电话拨号音来自他父亲 1998 年的录音笔。"
    },
    {
      id: "t7", title: "空调外机的雨", artist: "苏野", album: "live",
      genre: "噪音摇滚", bpm: 142, key: "A 大调", dur: 198, plays: "41.6 万",
      note: "吉他用一整块反馈撑满副歌，鼓手临时换成了电子鼓；录音时邻居敲了三次墙，最后那三下被留在了第二段主歌里。"
    },
    {
      id: "t8", title: "无人的地铁站", artist: "何岸", album: "deepblue",
      genre: "氛围", bpm: 62, key: "D 小调", dur: 401, plays: "36.8 万",
      note: "在末班车之后的站台录了两小时环境音：广播、穿堂风、远处刹车声都在里面，人声只出现了一次，是一句听不清的“借过”。"
    },
    {
      id: "t9", title: "磁带 B 面", artist: "白露", album: "insomnia",
      genre: "复古流行", bpm: 96, key: "B 小调", dur: 233, plays: "67.4 万",
      note: "整首歌先录进一盘 1994 年的空白磁带，再转回数字；高频那点毛边是故意留下的，像旧耳机里一直存在的那层雾。"
    },
    {
      id: "t10", title: "便利店关东煮", artist: "白露", album: "insomnia",
      genre: "卧室流行", bpm: 88, key: "C 大调", dur: 187, plays: "58.1 万",
      note: "卧室流行，只有一把尼龙弦吉他和一台鼓机；歌词写的是凌晨两点在便利店加热柜前犹豫的四分钟，副歌只有一个字。"
    },
    {
      id: "t11", title: "午夜调频", artist: "林知夏", album: "nocturne",
      genre: "暗潮流行", bpm: 84, key: "A 小调", dur: 268, plays: "104.6 万",
      note: "同名曲，把收音机的调频噪音做成了和声铺底；间奏里那段模糊的报时声，来自主播阿岚 2024 年的一期节目。"
    },
    {
      id: "t12", title: "雨刷器", artist: "陈默", album: "neon",
      genre: "合成器流行", bpm: 112, key: "F 大调", dur: 206, plays: "49.3 万",
      note: "112 BPM，节奏完全由雨刷器的摆动决定；副歌的琶音用一台坏了一半的 Juno-106 弹的，坏掉的那半个键盘才是重点。"
    },
    {
      id: "t13", title: "楼下的猫", artist: "苏野", album: "live",
      genre: "民谣摇滚", bpm: 92, key: "G 大调", dur: 241, plays: "44.7 万",
      note: "返场曲目，副歌的合唱来自录音棚楼下的三位邻居；唱到第三遍时台下有人跟着哼，那个声音被保留在左声道。"
    },
    {
      id: "t14", title: "低频城市", artist: "何岸", album: "deepblue",
      genre: "电子氛围", bpm: 74, key: "E 小调", dur: 318, plays: "32.5 万",
      note: "74 BPM 的电子氛围，低频像远处驶过的地铁；母带刻意压到 −14 LUFS，就是为了让人愿意把音量再拧大一点。"
    }
  ];

  const CHARTS = {
    mandarin: [
      { t: "t1", trend: 3 }, { t: "t5", trend: 0 }, { t: "t3", trend: 1 }, { t: "t9", trend: "new" },
      { t: "t11", trend: -2 }, { t: "t10", trend: 4 }, { t: "t13", trend: 0 }, { t: "t2", trend: -1 }
    ],
    electronic: [
      { t: "t6", trend: 2 }, { t: "t2", trend: 1 }, { t: "t12", trend: "new" }, { t: "t14", trend: 3 },
      { t: "t1", trend: 0 }, { t: "t10", trend: -1 }, { t: "t8", trend: 2 }, { t: "t11", trend: -3 }
    ],
    indie: [
      { t: "t3", trend: 1 }, { t: "t7", trend: "new" }, { t: "t13", trend: 2 }, { t: "t5", trend: 0 },
      { t: "t4", trend: 1 }, { t: "t9", trend: -2 }, { t: "t14", trend: 0 }, { t: "t1", trend: -1 }
    ]
  };

  const PLAYLISTS = [
    { name: "城市夜行", desc: "合成器与地铁风声", count: 32, plays: "268.4 万", icon: "i-moon", hue: 300, track: "t6" },
    { name: "关灯之后", desc: "钢琴与房间里的回声", count: 24, plays: "92.7 万", icon: "i-disc", hue: 85, track: "t4" },
    { name: "磁带年代", desc: "父辈的卡带与失真吉他", count: 41, plays: "156.2 万", icon: "i-tape", hue: 45, track: "t9" },
    { name: "雨天低气压", desc: "后摇与慢核的潮湿", count: 28, plays: "61.3 万", icon: "i-rain", hue: 245, track: "t8" },
    { name: "凌晨四点", desc: "民谣、烟味与便利店灯", count: 19, plays: "47.8 万", icon: "i-clock", hue: 25, track: "t13" },
    { name: "信号漂移", desc: "实验电子与磁带噪点", count: 36, plays: "38.6 万", icon: "i-radio", hue: 190, track: "t14" }
  ];

  const ARTISTS = [
    { name: "林知夏", role: "暗潮流行 · 上海", listeners: "82.6 万", hue: 85 },
    { name: "陈默", role: "合成器 / 制作人 · 成都", listeners: "64.1 万", hue: 300 },
    { name: "苏野", role: "独立摇滚 · 武汉", listeners: "47.3 万", hue: 35 },
    { name: "何岸", role: "氛围 / 后摇 · 大理", listeners: "39.8 万", hue: 235 },
    { name: "白露", role: "卧室流行 · 台北", listeners: "71.5 万", hue: 330 },
    { name: "声音档案室", role: "厂牌 / 合集 · 北京", listeners: "28.4 万", hue: 120 }
  ];

  const REPEAT_MODES = [
    { mode: "list", label: "列表循环" },
    { mode: "one", label: "单曲循环" },
    { mode: "shuffle", label: "随机播放" }
  ];

  /* ==================== 2. 状态与工具 ==================== */
  const state = {
    index: 0,
    playing: false,
    time: 0,
    volume: 0.72,
    muted: false,
    repeat: "list",
    chart: "mandarin",
    reduceMotion: window.matchMedia("(prefers-reduced-motion: reduce)").matches
  };

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const el = {};

  const byId = (id) => TRACKS.find((t) => t.id === id) || TRACKS[0];
  const indexOfTrack = (id) => TRACKS.findIndex((t) => t.id === id);
  const currentTrack = () => TRACKS[state.index];

  function pad2(n) {
    return String(n).padStart(2, "0");
  }

  function fmtTime(sec) {
    const s = Math.max(0, Math.floor(sec));
    return Math.floor(s / 60) + ":" + pad2(s % 60);
  }

  function setFill(input, ratio) {
    input.style.setProperty("--fill", (Math.min(1, Math.max(0, ratio)) * 100).toFixed(2) + "%");
  }

  /* ==================== 3. Canvas 波形 ==================== */
  const Wave = (function () {
    const GOLD = "rgba(226, 194, 126, 0.92)";
    const VIOLET = "rgba(172, 118, 238, 0.88)";
    const BARS = 72;
    let canvas = null;
    let ctx = null;
    let w = 0;
    let h = 0;
    let raf = 0;
    let running = false;

    const rand = (i) => {
      const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
      return x - Math.floor(x);
    };

    function resize() {
      if (!canvas || !ctx) return;
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(2, Math.max(1, window.devicePixelRatio || 1));
      w = Math.max(1, Math.round(rect.width));
      h = Math.max(1, Math.round(rect.height));
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      paint(0);
    }

    function paint(now) {
      if (!ctx) return;
      const mid = h / 2;
      const t = now * 0.001;
      const active = state.playing && !state.reduceMotion;

      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = "rgba(226, 194, 126, 0.16)";
      ctx.fillRect(0, mid - 0.5, w, 1);

      const gap = Math.max(2, w / 240);
      const bw = Math.max(1.5, (w - gap * (BARS - 1)) / BARS);

      for (let i = 0; i < BARS; i++) {
        const seed = rand(i + 1);
        const base = 0.16 + seed * 0.4;
        let amp = base * 0.34;
        if (active) {
          amp = base * (0.5 + 0.5 * Math.abs(Math.sin(t * (1.2 + seed * 1.9) + i * 0.44)));
          amp *= 0.68 + 0.32 * Math.sin(t * 0.85 + i * 0.14);
        }
        amp = Math.min(1, Math.max(0.05, amp));
        const barH = Math.max(2, amp * h * 0.92);
        const x = i * (bw + gap);
        const r = Math.min(bw / 2, 2.2);

        ctx.globalAlpha = 0.5 + amp * 0.5;
        ctx.fillStyle = amp > 0.66 ? VIOLET : GOLD;
        ctx.beginPath();
        ctx.roundRect(x, mid - barH / 2, bw, barH, r);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    function frame(now) {
      if (!running) return;
      paint(now);
      raf = requestAnimationFrame(frame);
    }

    function start() {
      if (running || !ctx) return;
      running = true;
      raf = requestAnimationFrame(frame);
    }

    function stop() {
      running = false;
      if (raf) cancelAnimationFrame(raf);
      raf = 0;
    }

    return {
      init(target) {
        canvas = target;
        if (!canvas) return;
        ctx = canvas.getContext("2d");
        if (!ctx) return;
        resize();
        new ResizeObserver(resize).observe(canvas);
        document.addEventListener("visibilitychange", () => {
          if (document.hidden) stop();
          else Wave.sync();
        });
        Wave.sync();
      },
      sync() {
        if (!ctx) return;
        if (state.playing && !state.reduceMotion) start();
        else {
          stop();
          paint(0);
        }
      }
    };
  })();

  /* ==================== 4. 渲染 ==================== */
  function renderChart(key) {
    const rows = CHARTS[key] || CHARTS.mandarin;
    el.chartList.innerHTML = rows.map((row, i) => {
      const track = byId(row.t);
      let trendClass = "chart-row__trend";
      let trendText = "—";
      if (row.trend === "new") {
        trendClass += " chart-row__trend--new";
        trendText = "NEW";
      } else if (row.trend > 0) {
        trendClass += " chart-row__trend--up";
        trendText = "▲ " + row.trend;
      } else if (row.trend < 0) {
        trendClass += " chart-row__trend--down";
        trendText = "▼ " + Math.abs(row.trend);
      }
      return '<li class="chart-row" data-track="' + track.id + '">' +
        '<button class="chart-row__btn" type="button" aria-label="播放 ' + track.title + '，' + track.artist + '">' +
        '<span class="chart-row__rank">' + pad2(i + 1) + "</span>" +
        '<span class="chart-row__main">' +
        '<span class="chart-row__title">' + track.title + "</span>" +
        '<span class="chart-row__sub">' + track.artist + " · " + track.plays + "次播放</span>" +
        "</span>" +
        '<span class="' + trendClass + '">' + trendText + "</span>" +
        '<span class="chart-row__dur">' + fmtTime(track.dur) + "</span>" +
        "</button></li>";
    }).join("");
    markCurrent();
  }

  function markCurrent() {
    const id = currentTrack().id;
    $$(".chart-row").forEach((row) => {
      row.classList.toggle("is-current", row.dataset.track === id);
    });
  }

  function renderPlaylists() {
    el.playlistGrid.innerHTML = PLAYLISTS.map((p) =>
      '<li><button class="playlist-card" type="button" data-track="' + p.track +
      '" aria-label="播放歌单 ' + p.name + '">' +
      '<span class="playlist-card__art" style="--h:' + p.hue + '">' +
      '<svg class="ico" aria-hidden="true"><use href="#' + p.icon + '"/></svg>' +
      '<span class="playlist-card__count">' + p.count + " 首</span>" +
      "</span>" +
      '<span class="playlist-card__name">' + p.name + "</span>" +
      '<span class="playlist-card__desc">' + p.desc + "</span>" +
      '<span class="playlist-card__plays">播放 ' + p.plays + "</span>" +
      "</button></li>"
    ).join("");
  }

  function renderArtists() {
    el.artistWall.innerHTML = ARTISTS.map((a) =>
      '<li class="artist">' +
      '<span class="artist__avatar" style="--h:' + a.hue + '" aria-hidden="true">' + a.name.charAt(0) + "</span>" +
      '<span class="artist__name">' + a.name + "</span>" +
      '<span class="artist__role">' + a.role + "</span>" +
      '<span class="artist__listeners">月听众 ' + a.listeners + "</span>" +
      "</li>"
    ).join("");
  }

  function renderTrack() {
    const t = currentTrack();
    const album = ALBUMS[t.album];

    el.coverImg.src = album.cover;
    el.coverImg.alt = "专辑《" + album.title + "》封面，" + album.alt;
    el.coverCap.textContent = "《" + album.title + "》· " + album.date + " 发行";
    el.trackGenre.textContent = t.genre;
    el.specDurInline.textContent = fmtTime(t.dur);
    el.trackTitle.textContent = t.title;
    el.trackArtist.textContent = t.artist;
    el.trackAlbum.textContent = "《" + album.title + "》";
    el.specGenre.textContent = t.genre;
    el.specBpm.textContent = t.bpm + " BPM";
    el.specKey.textContent = t.key;
    el.specDur.textContent = fmtTime(t.dur);
    el.trackNote.textContent = t.note;
    el.statPlays.textContent = t.plays;
    el.statLikes.textContent = (parseFloat(t.plays) * 0.029).toFixed(1) + " 万";

    el.barCover.src = album.cover;
    el.barTitle.textContent = t.title;
    el.barArtist.textContent = t.artist + " · 《" + album.title + "》";

    el.seek.max = String(t.dur);
    el.durTime.textContent = fmtTime(t.dur);
    markCurrent();
  }

  /* ==================== 5. 播放模拟 ==================== */
  let rafId = 0;
  let lastTs = 0;

  function updateProgress() {
    const t = currentTrack();
    const ratio = t.dur ? state.time / t.dur : 0;
    el.seek.value = String(Math.floor(state.time));
    setFill(el.seek, ratio);
    el.curTime.textContent = fmtTime(state.time);
    el.seek.setAttribute("aria-valuetext", fmtTime(state.time) + " / " + fmtTime(t.dur));
  }

  function startTicker() {
    if (rafId) return;
    lastTs = performance.now();
    rafId = requestAnimationFrame(tick);
  }

  function stopTicker() {
    if (rafId) cancelAnimationFrame(rafId);
    rafId = 0;
  }

  function tick(now) {
    rafId = 0;
    if (!state.playing) return;
    const dt = Math.min(0.25, (now - lastTs) / 1000);
    lastTs = now;
    state.time += dt;
    if (state.time >= currentTrack().dur) {
      handleTrackEnd();
      return;
    }
    updateProgress();
    rafId = requestAnimationFrame(tick);
  }

  function handleTrackEnd() {
    if (state.repeat === "one") {
      state.time = 0;
      updateProgress();
      startTicker();
      return;
    }
    let next = state.index + 1;
    if (state.repeat === "shuffle") {
      next = Math.floor(Math.random() * TRACKS.length);
      if (next === state.index) next = (next + 1) % TRACKS.length;
    }
    setTrack(next, true);
  }

  function setPlaying(on) {
    if (on && state.time >= currentTrack().dur) state.time = 0;
    state.playing = Boolean(on);
    document.body.dataset.playing = String(state.playing);
    el.playBtn.setAttribute("aria-label", state.playing ? "暂停" : "播放");
    el.heroPlay.setAttribute("aria-pressed", String(state.playing));
    el.heroPlayLabel.textContent = state.playing ? "暂停" : "播放";
    el.heroPlayIcon.setAttribute("href", state.playing ? "#i-pause" : "#i-play");
    el.waveState.textContent = state.playing ? "播放中 · 波形实时渲染" : "已暂停 · 点击播放";
    if (state.playing) startTicker();
    else stopTicker();
    Wave.sync();
  }

  function setTrack(index, autoplay) {
    state.index = ((index % TRACKS.length) + TRACKS.length) % TRACKS.length;
    state.time = 0;
    renderTrack();
    updateProgress();
    el.playerLive.textContent = "正在播放 " + currentTrack().title + "，" + currentTrack().artist;
    if (autoplay) setPlaying(true);
  }

  function applyVolume() {
    const v = state.muted ? 0 : state.volume;
    el.volRange.value = String(Math.round(v * 100));
    setFill(el.volRange, v);
    el.muteBtn.setAttribute("aria-pressed", String(state.muted));
    el.muteBtn.setAttribute("aria-label", state.muted ? "取消静音" : "静音");
    el.muteBtn.querySelector(".ico--vol").style.display = state.muted ? "none" : "block";
    el.muteBtn.querySelector(".ico--mute").style.display = state.muted ? "block" : "none";
  }

  function setLiked(liked) {
    el.likeBtn.setAttribute("aria-pressed", String(liked));
    el.barLike.setAttribute("aria-pressed", String(liked));
    el.likeLabel.textContent = liked ? "已收藏" : "收藏";
    el.likeIcon.setAttribute("href", liked ? "#i-heart-fill" : "#i-heart");
    el.barLikeIcon.setAttribute("href", liked ? "#i-heart-fill" : "#i-heart");
  }

  function cycleRepeat() {
    const current = REPEAT_MODES.findIndex((m) => m.mode === state.repeat);
    const next = REPEAT_MODES[(current + 1) % REPEAT_MODES.length];
    state.repeat = next.mode;
    el.repeatBtn.dataset.mode = next.mode;
    el.repeatBtn.setAttribute("aria-label", "循环模式：" + next.label);
    el.playerLive.textContent = "循环模式已切换为" + next.label;
  }

  /* ==================== 6. 交互绑定 ==================== */
  function initPlayer() {
    el.playBtn.addEventListener("click", () => setPlaying(!state.playing));
    el.heroPlay.addEventListener("click", () => setPlaying(!state.playing));

    el.prevBtn.addEventListener("click", () => setTrack(state.index - 1, state.playing));
    el.nextBtn.addEventListener("click", () => setTrack(state.index + 1, state.playing));

    el.seek.addEventListener("input", () => {
      state.time = Number(el.seek.value);
      updateProgress();
    });

    el.volRange.addEventListener("input", () => {
      state.volume = Number(el.volRange.value) / 100;
      state.muted = state.volume === 0;
      applyVolume();
    });

    el.muteBtn.addEventListener("click", () => {
      state.muted = !state.muted;
      applyVolume();
    });

    el.repeatBtn.addEventListener("click", cycleRepeat);

    el.likeBtn.addEventListener("click", () => setLiked(el.likeBtn.getAttribute("aria-pressed") !== "true"));
    el.barLike.addEventListener("click", () => setLiked(el.barLike.getAttribute("aria-pressed") !== "true"));

    el.chartList.addEventListener("click", (e) => {
      const row = e.target.closest("[data-track]");
      if (row) setTrack(indexOfTrack(row.dataset.track), true);
    });

    el.albumTrack.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-track]");
      if (btn) setTrack(indexOfTrack(btn.dataset.track), true);
    });

    el.playlistGrid.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-track]");
      if (btn) setTrack(indexOfTrack(btn.dataset.track), true);
    });

    el.radioPlay.addEventListener("click", () => setTrack(indexOfTrack("t8"), true));
  }

  function initTabs() {
    const tabs = $$(".tabs__btn");
    const activate = (tab) => {
      state.chart = tab.dataset.chart;
      tabs.forEach((t) => {
        const on = t === tab;
        t.classList.toggle("is-active", on);
        t.setAttribute("aria-selected", String(on));
        t.tabIndex = on ? 0 : -1;
      });
      el.chartPanel.setAttribute("aria-labelledby", tab.id);
      renderChart(state.chart);
    };

    tabs.forEach((tab) => {
      tab.addEventListener("click", () => activate(tab));
      tab.addEventListener("keydown", (e) => {
        const i = tabs.indexOf(tab);
        let next = null;
        if (e.key === "ArrowRight") next = tabs[(i + 1) % tabs.length];
        else if (e.key === "ArrowLeft") next = tabs[(i - 1 + tabs.length) % tabs.length];
        else if (e.key === "Home") next = tabs[0];
        else if (e.key === "End") next = tabs[tabs.length - 1];
        if (!next) return;
        e.preventDefault();
        activate(next);
        next.focus();
      });
    });
  }

  function initScroller() {
    const track = el.albumTrack;
    const step = () => Math.max(200, Math.round(track.clientWidth * 0.82));

    const update = () => {
      el.albumPrev.disabled = track.scrollLeft <= 4;
      el.albumNext.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 4;
    };

    el.albumPrev.addEventListener("click", () => {
      track.scrollBy({ left: -step(), behavior: state.reduceMotion ? "auto" : "smooth" });
    });
    el.albumNext.addEventListener("click", () => {
      track.scrollBy({ left: step(), behavior: state.reduceMotion ? "auto" : "smooth" });
    });

    let queued = false;
    track.addEventListener("scroll", () => {
      if (queued) return;
      queued = true;
      requestAnimationFrame(() => {
        queued = false;
        update();
      });
    }, { passive: true });

    new ResizeObserver(update).observe(track);
    update();
  }

  function initClock() {
    const render = () => {
      const d = new Date();
      const hh = pad2(d.getHours());
      const mm = pad2(d.getMinutes());
      el.clockTime.textContent = hh + ":" + mm;
      el.clockTime.setAttribute("datetime", hh + ":" + mm);
      const h = d.getHours();
      const phase = h < 5 ? "深夜" : h < 9 ? "清晨" : h < 12 ? "上午" : h < 18 ? "午后" : h < 22 ? "夜晚" : "深夜";
      el.clockPhase.textContent = phase + " · 上海";
    };
    render();
    setInterval(render, 30000);
  }

  function initReveal() {
    const items = $$(".fade-up");
    if (state.reduceMotion || !("IntersectionObserver" in window)) {
      items.forEach((item) => item.classList.add("is-in"));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-in");
          io.unobserve(entry.target);
        }
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    items.forEach((item) => io.observe(item));
  }

  function initMotionPreference() {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    mq.addEventListener("change", (e) => {
      state.reduceMotion = e.matches;
      Wave.sync();
    });
  }

  /* ==================== 7. 启动 ==================== */
  function cacheDom() {
    el.clockTime = $("#clockTime");
    el.clockPhase = $("#clockPhase");
    el.coverImg = $("#coverImg");
    el.coverCap = $("#coverCap");
    el.trackGenre = $("#trackGenre");
    el.trackTitle = $("#trackTitle");
    el.trackArtist = $("#trackArtist");
    el.trackAlbum = $("#trackAlbum");
    el.specGenre = $("#specGenre");
    el.specBpm = $("#specBpm");
    el.specKey = $("#specKey");
    el.specDur = $("#specDur");
    el.specDurInline = $("#specDurInline");
    el.trackNote = $("#trackNote");
    el.statPlays = $("#statPlays");
    el.statLikes = $("#statLikes");
    el.heroPlay = $("#heroPlay");
    el.heroPlayIcon = $("#heroPlayIcon");
    el.heroPlayLabel = $("#heroPlayLabel");
    el.likeBtn = $("#likeBtn");
    el.likeLabel = $("#likeLabel");
    el.likeIcon = $("#likeIcon");
    el.waveCanvas = $("#waveCanvas");
    el.waveState = $("#waveState");
    el.chartList = $("#chartList");
    el.chartPanel = $("#chartPanel");
    el.albumTrack = $("#albumTrack");
    el.albumPrev = $("#albumPrev");
    el.albumNext = $("#albumNext");
    el.playlistGrid = $("#playlistGrid");
    el.radioPlay = $("#radioPlay");
    el.artistWall = $("#artistWall");
    el.barCover = $("#barCover");
    el.barTitle = $("#barTitle");
    el.barArtist = $("#barArtist");
    el.barLike = $("#barLike");
    el.barLikeIcon = $("#barLikeIcon");
    el.prevBtn = $("#prevBtn");
    el.playBtn = $("#playBtn");
    el.nextBtn = $("#nextBtn");
    el.seek = $("#seekRange");
    el.curTime = $("#curTime");
    el.durTime = $("#durTime");
    el.repeatBtn = $("#repeatBtn");
    el.muteBtn = $("#muteBtn");
    el.volRange = $("#volRange");
    el.playerLive = $("#playerLive");
  }

  function init() {
    cacheDom();
    renderChart(state.chart);
    renderPlaylists();
    renderArtists();
    setTrack(0, false);
    initTabs();
    initPlayer();
    initScroller();
    initClock();
    initReveal();
    initMotionPreference();
    applyVolume();
    Wave.init(el.waveCanvas);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
