/* ==========================================================================
   Skyward 天气观测台 — 交互脚本
   纯静态演示：数据内置，无任何网络请求
   ========================================================================== */
"use strict";

(function () {
  /* ==================== 1. 数据（虚构样本） ==================== */
  const CITIES = [
    {
      id: "beijing",
      name: "北京",
      district: "朝阳区",
      station: "54511 · 城区自动站",
      cond: "partly",
      label: "多云转晴",
      temp: 18, feels: 17, hi: 22, lo: 11, pop: 10,
      humidity: 46, wind: 3.2, windDir: "西北风", pressure: 1016,
      uv: 5, uvLabel: "中等", vis: 18, dew: 6,
      sunrise: "06:42", sunset: "17:28",
      summary: "高空槽东移，午后云量逐渐减少，能见度转好；昼夜温差达 11℃，早晚出行注意加件外套。",
      dayCond: "partly", nightCond: "clear",
      aqi: {
        v: 62, lv: "良",
        tip: "空气质量可接受，极少数异常敏感人群应减少户外活动。",
        items: [["PM2.5", "35"], ["PM10", "58"], ["O₃", "96"], ["NO₂", "28"], ["SO₂", "6"], ["CO", "0.7"]]
      },
      hourlyTemp: [18, 17, 16, 15, 13, 12, 11, 11, 10, 10, 11, 13, 15, 17, 19, 21, 22, 22, 21, 19, 17, 16, 15, 14],
      hourlyPop: [10, 8, 6, 5, 5, 4, 4, 3, 3, 3, 4, 6, 8, 10, 12, 14, 16, 14, 10, 8, 6, 6, 5, 5],
      daily: [
        ["今天", "11/14", "partly", 22, 11, 10],
        ["周日", "11/15", "clear", 24, 12, 0],
        ["周一", "11/16", "partly", 21, 10, 10],
        ["周二", "11/17", "cloud", 18, 9, 30],
        ["周三", "11/18", "rain", 15, 8, 70],
        ["周四", "11/19", "cloud", 16, 7, 20],
        ["周五", "11/20", "clear", 19, 8, 0]
      ],
      life: [
        ["紫外线", "中等", "正午时段建议涂抹 SPF30 防晒霜。", 3],
        ["穿衣", "较凉", "建议穿薄外套或针织衫，早晚加衣。", 2],
        ["洗车", "适宜", "未来 24 小时无降水，风力较小。", 4],
        ["运动", "适宜", "体感舒适，适合慢跑与骑行。", 4],
        ["感冒", "易发", "昼夜温差大，注意及时增减衣物。", 2],
        ["钓鱼", "较适宜", "气压稳定，午后鱼儿活跃度提升。", 3]
      ]
    },
    {
      id: "shanghai",
      name: "上海",
      district: "浦东新区",
      station: "58362 · 洋山观测点",
      cond: "cloud",
      label: "阴到多云",
      temp: 21, feels: 22, hi: 25, lo: 16, pop: 30,
      humidity: 72, wind: 4.6, windDir: "东南风", pressure: 1011,
      uv: 3, uvLabel: "较弱", vis: 12, dew: 15,
      sunrise: "06:22", sunset: "16:58",
      summary: "副高边缘水汽输送增强，云系较多，局地有短时小雨；沿江沿海风力较大，注意防风。",
      dayCond: "cloud", nightCond: "cloud",
      aqi: {
        v: 48, lv: "优",
        tip: "空气质量令人满意，基本无空气污染，各类人群可正常活动。",
        items: [["PM2.5", "22"], ["PM10", "41"], ["O₃", "78"], ["NO₂", "31"], ["SO₂", "5"], ["CO", "0.5"]]
      },
      hourlyTemp: [21, 20, 19, 18, 17, 17, 16, 16, 16, 17, 19, 21, 23, 24, 25, 25, 24, 23, 22, 21, 20, 20, 19, 19],
      hourlyPop: [30, 35, 40, 45, 40, 35, 30, 25, 25, 20, 20, 25, 30, 35, 40, 40, 35, 30, 25, 25, 20, 20, 25, 30],
      daily: [
        ["今天", "11/14", "cloud", 25, 16, 30],
        ["周日", "11/15", "rain", 23, 17, 80],
        ["周一", "11/16", "rain", 22, 17, 75],
        ["周二", "11/17", "cloud", 24, 18, 25],
        ["周三", "11/18", "partly", 26, 18, 10],
        ["周四", "11/19", "clear", 27, 19, 0],
        ["周五", "11/20", "partly", 25, 18, 10]
      ],
      life: [
        ["紫外线", "较弱", "云层较厚，短时外出无需特别防护。", 2],
        ["穿衣", "舒适", "长袖衬衫加薄外套即可，注意防风。", 4],
        ["洗车", "不宜", "未来 24 小时有降水，建议推迟洗车。", 1],
        ["运动", "较适宜", "湿度偏高，建议选择室内或清晨运动。", 3],
        ["感冒", "少发", "气温平稳，感冒风险较低。", 4],
        ["钓鱼", "适宜", "阴天光线柔和，鱼类觅食活跃。", 4]
      ]
    },
    {
      id: "guangzhou",
      name: "广州",
      district: "天河区",
      station: "59287 · 五山观测站",
      cond: "thunder",
      label: "雷阵雨",
      temp: 27, feels: 31, hi: 30, lo: 23, pop: 85,
      humidity: 88, wind: 5.4, windDir: "西南风", pressure: 1004,
      uv: 2, uvLabel: "弱", vis: 6, dew: 24,
      sunrise: "06:38", sunset: "17:44",
      summary: "季风槽影响，午后到夜间有雷阵雨，局地伴有短时强降水与 7 级阵风，请注意防范。",
      dayCond: "thunder", nightCond: "rain",
      aqi: {
        v: 38, lv: "优",
        tip: "降水冲刷作用明显，污染物浓度低，空气清新。",
        items: [["PM2.5", "16"], ["PM10", "32"], ["O₃", "62"], ["NO₂", "24"], ["SO₂", "4"], ["CO", "0.4"]]
      },
      hourlyTemp: [27, 26, 25, 25, 24, 24, 23, 23, 23, 24, 25, 27, 29, 30, 30, 29, 28, 27, 26, 26, 25, 25, 25, 26],
      hourlyPop: [85, 90, 85, 75, 65, 55, 50, 45, 50, 60, 70, 75, 80, 85, 90, 85, 75, 65, 60, 55, 50, 45, 50, 60],
      daily: [
        ["今天", "11/14", "thunder", 30, 23, 85],
        ["周日", "11/15", "thunder", 29, 23, 90],
        ["周一", "11/16", "rain", 28, 22, 70],
        ["周二", "11/17", "cloud", 29, 22, 40],
        ["周三", "11/18", "partly", 31, 23, 20],
        ["周四", "11/19", "clear", 32, 24, 10],
        ["周五", "11/20", "partly", 31, 24, 20]
      ],
      life: [
        ["紫外线", "弱", "雷雨云遮蔽强，紫外线强度低。", 1],
        ["穿衣", "闷热", "短袖透气衣物为主，注意补换衣物。", 4],
        ["洗车", "不宜", "强降水频繁，洗车意义不大。", 1],
        ["运动", "不宜", "雷雨时段请勿进行户外运动。", 1],
        ["感冒", "少发", "气温高湿度大，注意空调温差。", 4],
        ["钓鱼", "不宜", "雷电天气禁止在开阔水域垂钓。", 1]
      ]
    },
    {
      id: "chengdu",
      name: "成都",
      district: "高新区",
      station: "56294 · 温江观测站",
      cond: "fog",
      label: "轻雾转阴",
      temp: 16, feels: 15, hi: 16, lo: 12, pop: 20,
      humidity: 82, wind: 1.4, windDir: "静风", pressure: 1008,
      uv: 2, uvLabel: "弱", vis: 3.5, dew: 13,
      sunrise: "07:22", sunset: "18:04",
      summary: "静稳天气维持，近地层湿度大，早晨有轻雾，能见度 3–5 公里，高速行车请减速。",
      dayCond: "fog", nightCond: "cloud",
      aqi: {
        v: 96, lv: "良",
        tip: "静稳条件下扩散一般，敏感人群减少长时间户外活动。",
        items: [["PM2.5", "68"], ["PM10", "92"], ["O₃", "54"], ["NO₂", "42"], ["SO₂", "9"], ["CO", "0.9"]]
      },
      hourlyTemp: [16, 15, 15, 14, 14, 13, 13, 12, 12, 12, 13, 14, 15, 16, 16, 16, 15, 15, 14, 14, 13, 13, 13, 14],
      hourlyPop: [20, 20, 15, 15, 20, 25, 30, 30, 25, 20, 20, 15, 15, 15, 20, 25, 30, 30, 25, 20, 20, 20, 20, 20],
      daily: [
        ["今天", "11/14", "fog", 16, 12, 20],
        ["周日", "11/15", "cloud", 17, 12, 30],
        ["周一", "11/16", "rain", 15, 11, 65],
        ["周二", "11/17", "rain", 14, 10, 70],
        ["周三", "11/18", "cloud", 16, 11, 30],
        ["周四", "11/19", "partly", 18, 11, 15],
        ["周五", "11/20", "partly", 19, 12, 10]
      ],
      life: [
        ["紫外线", "弱", "雾霾散射，紫外线很弱。", 1],
        ["穿衣", "较凉", "建议毛衣加外套，注意保暖。", 2],
        ["洗车", "较不宜", "雾气重，车身易附着水汽与浮尘。", 2],
        ["运动", "较不宜", "能见度低且扩散条件差，建议室内。", 2],
        ["感冒", "易发", "湿冷环境易引发呼吸道不适。", 2],
        ["钓鱼", "适宜", "静风稳水，适合近岸垂钓。", 3]
      ]
    },
    {
      id: "hangzhou",
      name: "杭州",
      district: "西湖区",
      station: "58457 · 杭州观测站",
      cond: "partly",
      label: "晴间多云",
      temp: 20, feels: 20, hi: 24, lo: 15, pop: 15,
      humidity: 64, wind: 2.8, windDir: "东北风", pressure: 1013,
      uv: 4, uvLabel: "中等", vis: 15, dew: 13,
      sunrise: "06:28", sunset: "17:12",
      summary: "高压底部控制，天气转好，白天阳光充足；夜间辐射降温明显，湖区晨间有薄雾。",
      dayCond: "partly", nightCond: "clear",
      aqi: {
        v: 55, lv: "良",
        tip: "空气质量可接受，适合大多数户外活动。",
        items: [["PM2.5", "31"], ["PM10", "52"], ["O₃", "88"], ["NO₂", "26"], ["SO₂", "5"], ["CO", "0.6"]]
      },
      hourlyTemp: [20, 19, 18, 17, 17, 16, 16, 15, 15, 16, 18, 20, 22, 23, 24, 24, 23, 22, 21, 20, 19, 19, 18, 18],
      hourlyPop: [15, 12, 10, 8, 8, 6, 6, 5, 5, 5, 8, 10, 12, 15, 18, 18, 15, 12, 10, 8, 8, 8, 10, 12],
      daily: [
        ["今天", "11/14", "partly", 24, 15, 15],
        ["周日", "11/15", "clear", 25, 15, 5],
        ["周一", "11/16", "partly", 23, 14, 15],
        ["周二", "11/17", "cloud", 21, 14, 35],
        ["周三", "11/18", "rain", 19, 13, 65],
        ["周四", "11/19", "cloud", 20, 12, 25],
        ["周五", "11/20", "clear", 22, 13, 5]
      ],
      life: [
        ["紫外线", "中等", "午后紫外线较强，注意遮阳。", 3],
        ["穿衣", "舒适", "薄外套加长袖，体感舒适。", 4],
        ["洗车", "适宜", "未来 24 小时降水概率低。", 4],
        ["运动", "适宜", "空气清新，适合环湖慢跑。", 5],
        ["感冒", "少发", "天气稳定，注意夜间降温。", 4],
        ["钓鱼", "适宜", "气压回升，鱼口转好。", 4]
      ]
    },
    {
      id: "urumqi",
      name: "乌鲁木齐",
      district: "天山区",
      station: "51463 · 南山观测点",
      cond: "snow",
      label: "小雪",
      temp: 6, feels: 1, hi: 8, lo: -2, pop: 75,
      humidity: 78, wind: 6.2, windDir: "西北风", pressure: 1024,
      uv: 2, uvLabel: "弱", vis: 4, dew: 3,
      sunrise: "08:14", sunset: "18:36",
      summary: "冷空气东灌，城区有小雪，山区中雪；风口风力 6–7 级，道路湿滑结冰，注意交通安全。",
      dayCond: "snow", nightCond: "snow",
      aqi: {
        v: 34, lv: "优",
        tip: "冷空气清除作用强，空气质量优良。",
        items: [["PM2.5", "14"], ["PM10", "38"], ["O₃", "44"], ["NO₂", "19"], ["SO₂", "7"], ["CO", "0.6"]]
      },
      hourlyTemp: [6, 5, 4, 2, 1, 0, -1, -2, -2, -1, 1, 4, 7, 9, 11, 12, 11, 9, 7, 5, 3, 2, 1, 0],
      hourlyPop: [75, 80, 85, 80, 70, 60, 50, 45, 40, 45, 55, 60, 65, 70, 75, 70, 65, 60, 55, 50, 45, 45, 50, 55],
      daily: [
        ["今天", "11/14", "snow", 8, -2, 75],
        ["周日", "11/15", "snow", 5, -5, 80],
        ["周一", "11/16", "cloud", 3, -7, 30],
        ["周二", "11/17", "clear", 1, -9, 5],
        ["周三", "11/18", "clear", 0, -10, 0],
        ["周四", "11/19", "partly", 2, -8, 10],
        ["周五", "11/20", "cloud", 4, -6, 25]
      ],
      life: [
        ["紫外线", "弱", "雪天云层厚，紫外线弱。", 1],
        ["穿衣", "寒冷", "羽绒服加保暖内衣，注意防风。", 1],
        ["洗车", "不宜", "降雪持续，洗车无意义。", 1],
        ["运动", "不宜", "路面湿滑，建议室内活动。", 1],
        ["感冒", "极易发", "气温骤降，注意防寒保暖。", 1],
        ["钓鱼", "不宜", "冰面尚未冻结实，禁止涉水。", 1]
      ]
    }
  ];

  const COND_META = {
    clear: { icon: "i-sun", night: "i-moon", text: "晴" },
    partly: { icon: "i-partly", night: "i-partly", text: "多云" },
    cloud: { icon: "i-cloud", night: "i-cloud", text: "阴" },
    rain: { icon: "i-rain", night: "i-rain", text: "小雨" },
    thunder: { icon: "i-thunder", night: "i-thunder", text: "雷阵雨" },
    snow: { icon: "i-snow", night: "i-snow", text: "小雪" },
    fog: { icon: "i-fog", night: "i-fog", text: "雾" }
  };

  /* ==================== 2. 状态与工具 ==================== */
  const state = {
    city: CITIES[0],
    unit: "c",
    offset: 0,
    hourIndex: 0,
    reduceMotion: window.matchMedia("(prefers-reduced-motion: reduce)").matches
  };

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const clamp = (v, min, max) => Math.min(max, Math.max(min, v));

  function toUnit(c) {
    return state.unit === "f" ? (c * 9) / 5 + 32 : c;
  }
  function fmtT(c, withDeg) {
    const v = Math.round(toUnit(c));
    return withDeg === false ? String(v) : v + "°";
  }
  function pad(n) {
    return String(n).padStart(2, "0");
  }
  function nowHour() {
    return new Date().getHours();
  }

  /* ==================== 3. Canvas 天空引擎 ==================== */
  const Sky = (function () {
    let canvas = null;
    let ctx = null;
    let w = 0;
    let h = 0;
    let dpr = 1;
    let raf = 0;
    let running = false;
    let clouds = [];
    let rain = [];
    let snow = [];
    let stars = [];
    let fog = [];
    let flash = 0;
    let nextFlash = 3000;
    let t0 = 0;
    let cond = "partly";
    let isNight = false;

    function resize() {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      dpr = clamp(window.devicePixelRatio || 1, 1, 2);
      w = Math.max(1, Math.round(rect.width));
      h = Math.max(1, Math.round(rect.height));
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      build();
    }

    function rand(a, b) {
      return a + Math.random() * (b - a);
    }

    function build() {
      const area = (w * h) / 1000000;
      const density = clamp(area, 0.4, 1.6);
      const heavy = cond === "rain" || cond === "thunder" || cond === "cloud" || cond === "snow";
      const cloudCount = Math.round((heavy ? 9 : 4) * density);
      clouds = [];
      for (let i = 0; i < cloudCount; i++) {
        clouds.push({
          x: rand(-0.15, 1.15) * w,
          y: rand(0.02, heavy ? 0.55 : 0.34) * h,
          r: rand(0.12, 0.3) * Math.min(w, h * 1.6) * (heavy ? 1.25 : 1),
          speed: rand(0.06, 0.2) * (heavy ? 1.5 : 1),
          alpha: rand(0.18, 0.42) * (heavy ? 1.35 : 1),
          tone: isNight ? 0.55 : 1
        });
      }
      rain = [];
      if (cond === "rain" || cond === "thunder") {
        const n = Math.round(120 * density);
        for (let i = 0; i < n; i++) {
          rain.push({
            x: Math.random() * w,
            y: Math.random() * h,
            len: rand(10, 26),
            v: rand(9, 17),
            a: rand(0.12, 0.4)
          });
        }
      }
      snow = [];
      if (cond === "snow") {
        const n = Math.round(90 * density);
        for (let i = 0; i < n; i++) {
          snow.push({
            x: Math.random() * w,
            y: Math.random() * h,
            r: rand(1.1, 3.4),
            v: rand(0.5, 1.5),
            d: rand(-0.4, 0.4),
            a: rand(0.35, 0.9),
            p: Math.random() * Math.PI * 2
          });
        }
      }
      stars = [];
      if (isNight) {
        const n = Math.round(90 * density);
        for (let i = 0; i < n; i++) {
          stars.push({
            x: Math.random() * w,
            y: Math.random() * h * 0.72,
            r: rand(0.5, 1.6),
            a: rand(0.25, 0.9),
            p: Math.random() * Math.PI * 2
          });
        }
      }
      fog = [];
      if (cond === "fog") {
        for (let i = 0; i < 5; i++) {
          fog.push({ y: rand(0.3, 0.95) * h, hh: rand(18, 46), a: rand(0.06, 0.16), sp: rand(0.08, 0.24), x: rand(-0.3, 0.8) * w });
        }
      }
    }

    function drawGlow() {
      const cx = w * 0.82;
      const cy = h * 0.16;
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(w, h) * 0.55);
      if (isNight) {
        g.addColorStop(0, "rgba(220,232,255,0.35)");
        g.addColorStop(0.25, "rgba(170,190,240,0.14)");
        g.addColorStop(1, "rgba(120,140,200,0)");
      } else if (cond === "rain" || cond === "thunder" || cond === "cloud" || cond === "fog") {
        g.addColorStop(0, "rgba(255,255,255,0.28)");
        g.addColorStop(1, "rgba(255,255,255,0)");
      } else {
        g.addColorStop(0, "rgba(255,246,214,0.85)");
        g.addColorStop(0.18, "rgba(255,238,196,0.35)");
        g.addColorStop(1, "rgba(255,235,190,0)");
      }
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
    }

    function drawClouds(dt) {
      for (const c of clouds) {
        c.x += c.speed * dt * 12;
        if (c.x - c.r > w + 40) c.x = -c.r - 40;
        const g = ctx.createRadialGradient(c.x, c.y, c.r * 0.15, c.x, c.y, c.r);
        const base = isNight ? "40,52,86" : "255,255,255";
        const base2 = isNight ? "30,40,72" : "226,236,248";
        g.addColorStop(0, "rgba(" + base + "," + c.alpha * c.tone + ")");
        g.addColorStop(0.55, "rgba(" + base2 + "," + c.alpha * 0.55 * c.tone + ")");
        g.addColorStop(1, "rgba(" + base2 + ",0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.ellipse(c.x, c.y, c.r, c.r * 0.55, 0, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    function drawRain(dt) {
      ctx.strokeStyle = "rgba(220,235,255,0.55)";
      ctx.lineWidth = 1.2;
      ctx.lineCap = "round";
      for (const d of rain) {
        d.y += d.v * dt * 60;
        d.x -= d.v * dt * 12;
        if (d.y > h + 30) {
          d.y = -30;
          d.x = Math.random() * w;
        }
        if (d.x < -20) d.x = w + 10;
        ctx.globalAlpha = d.a;
        ctx.beginPath();
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x - 1.6, d.y + d.len);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }

    function drawSnow(dt) {
      for (const s of snow) {
        s.p += dt * 1.6;
        s.y += s.v * dt * 40;
        s.x += Math.sin(s.p) * 0.5 + s.d * dt * 12;
        if (s.y > h + 10) {
          s.y = -10;
          s.x = Math.random() * w;
        }
        if (s.x < -10) s.x = w + 6;
        if (s.x > w + 10) s.x = -6;
        ctx.globalAlpha = s.a;
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    function drawStars(t) {
      for (const s of stars) {
        ctx.globalAlpha = s.a * (0.6 + 0.4 * Math.sin(t * 0.001 + s.p));
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    function drawFog(dt) {
      for (const f of fog) {
        f.x += f.sp * dt * 20;
        if (f.x > w) f.x = -w * 0.6;
        const g = ctx.createLinearGradient(0, f.y - f.hh, 0, f.y + f.hh);
        g.addColorStop(0, "rgba(255,255,255,0)");
        g.addColorStop(0.5, "rgba(248,251,255," + f.a + ")");
        g.addColorStop(1, "rgba(255,255,255,0)");
        ctx.fillStyle = g;
        ctx.fillRect(f.x, f.y - f.hh, w * 0.9, f.hh * 2);
      }
    }

    function frame(now) {
      if (!running) return;
      if (!t0) t0 = now;
      const dt = Math.min(0.05, (now - t0) / 1000);
      t0 = now;

      ctx.clearRect(0, 0, w, h);
      drawGlow();
      if (isNight) drawStars(now);
      drawClouds(dt);
      if (cond === "fog") drawFog(dt);
      if (cond === "rain" || cond === "thunder") drawRain(dt);
      if (cond === "snow") drawSnow(dt);

      if (cond === "thunder") {
        nextFlash -= dt * 1000;
        if (nextFlash <= 0) {
          flash = 1;
          nextFlash = 4200 + Math.random() * 5200;
        }
        if (flash > 0) {
          ctx.fillStyle = "rgba(232,240,255," + flash * 0.5 + ")";
          ctx.fillRect(0, 0, w, h);
          flash = Math.max(0, flash - dt * 3.4);
        }
      }

      raf = requestAnimationFrame(frame);
    }

    function start() {
      if (!canvas || running || state.reduceMotion) return;
      running = true;
      t0 = 0;
      raf = requestAnimationFrame(frame);
    }

    function stop() {
      running = false;
      if (raf) cancelAnimationFrame(raf);
      raf = 0;
    }

    function paintStatic() {
      if (!ctx) return;
      ctx.clearRect(0, 0, w, h);
      drawGlow();
      if (isNight) drawStars(0);
      drawClouds(0);
    }

    return {
      init(el) {
        canvas = el;
        ctx = canvas.getContext("2d", { alpha: true });
        if (!ctx) return;
        resize();
        const ro = new ResizeObserver(resize);
        ro.observe(canvas);
        document.addEventListener("visibilitychange", () => {
          if (document.hidden) stop();
          else if (!state.reduceMotion) start();
        });
      },
      set(c, night) {
        cond = c;
        isNight = night;
        if (!ctx) return;
        build();
        if (state.reduceMotion) paintStatic();
      },
      start,
      stop,
      repaint() {
        if (state.reduceMotion) paintStatic();
      }
    };
  })();

  /* ==================== 4. 渲染 ==================== */
  function isNightNow() {
    const c = state.city;
    const [rh, rm] = c.sunrise.split(":").map(Number);
    const [sh, sm] = c.sunset.split(":").map(Number);
    const mins = nowHour() * 60 + new Date().getMinutes();
    return mins < rh * 60 + rm || mins > sh * 60 + sm;
  }

  function iconFor(cond, night) {
    const meta = COND_META[cond] || COND_META.partly;
    return "#" + (night && cond === "clear" ? meta.night : meta.icon);
  }

  function renderHero() {
    const c = state.city;
    const night = isNightNow();
    document.body.dataset.cond = c.cond;
    document.body.dataset.period = night ? "night" : "day";

    $("#heroCity").textContent = c.name + " · " + c.district;
    const d = new Date();
    const week = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"][d.getDay()];
    $("#heroDate").textContent = d.getMonth() + 1 + " 月 " + d.getDate() + " 日 " + week;
    $("#heroDate").setAttribute("datetime", d.toISOString().slice(0, 10));

    const t = fmtT(c.temp, false);
    $("#heroTemp").textContent = t;
    $("#heroTempSr").textContent = "当前气温 " + t + (state.unit === "f" ? " 华氏度" : " 摄氏度");
    $("#heroFeels").textContent = fmtT(c.feels);
    $("#heroHi").textContent = fmtT(c.hi);
    $("#heroLo").textContent = fmtT(c.lo);
    $("#heroPop").textContent = c.pop + "%";
    $("#heroCond").textContent = c.label;
    $("#heroSummary").textContent = c.summary;
    $("#heroIconUse").setAttribute("href", iconFor(c.cond, night));
    $("#cityBtnLabel").textContent = c.name;

    const obs = new Date();
    $("#obsTime").textContent = pad(obs.getHours()) + ":" + pad(obs.getMinutes());
    $("#obsTime").setAttribute("datetime", obs.toISOString().slice(0, 16));

    $("#mHum").textContent = c.humidity;
    $("#mWind").textContent = c.wind.toFixed(1);
    $("#mWindDir").textContent = c.windDir;
    $("#mPres").textContent = c.pressure;
    $("#mUv").textContent = c.uv;
    $("#mUv").nextElementSibling.textContent = c.uvLabel;
    $("#mVis").textContent = c.vis;
    $("#mDew").textContent = fmtT(c.dew, false);

    $("#sunrise").textContent = c.sunrise;
    $("#sunset").textContent = c.sunset;

    // 白昼时长
    const [rh, rm] = c.sunrise.split(":").map(Number);
    const [sh, sm] = c.sunset.split(":").map(Number);
    const total = sh * 60 + sm - (rh * 60 + rm);
    $("#dayLength").textContent = Math.floor(total / 60) + " 小时 " + (total % 60) + " 分";

    // 太阳位置
    const mins = obs.getHours() * 60 + obs.getMinutes();
    const progress = clamp((mins - (rh * 60 + rm)) / total, 0, 1);
    const angle = Math.PI * (1 - progress);
    const cx = 150 + 136 * Math.cos(angle);
    const cy = 148 - 136 * Math.sin(angle);
    $("#arcSun").setAttribute("cx", cx.toFixed(1));
    $("#arcSun").setAttribute("cy", cy.toFixed(1));
    $("#arcSunGlow").setAttribute("cx", cx.toFixed(1));
    $("#arcSunGlow").setAttribute("cy", cy.toFixed(1));
    $("#arcFill").setAttribute("stroke-dasharray", (progress * 427).toFixed(1) + " 999");

    Sky.set(c.cond, night);
    Sky.start();
  }

  /* ---------- 逐时曲线 ---------- */
  const chart = { pts: [], W: 1000, H: 240, yTop: 26, yBottom: 150, barBase: 206, barMax: 58 };

  function chartMetrics() {
    const plot = $("#chartPlot");
    chart.W = Math.max(320, Math.round(plot.clientWidth || 1000));
    chart.H = Math.max(180, Math.round(plot.clientHeight || 240));
    chart.yTop = 26;
    chart.yBottom = chart.H - 96;
    chart.barBase = chart.H - 34;
    chart.barMax = 58;
    $("#hourlyChart").setAttribute("viewBox", "0 0 " + chart.W + " " + chart.H);
    const cursorLine = $("#chartCursor").querySelector("line");
    cursorLine.setAttribute("y1", "4");
    cursorLine.setAttribute("y2", String(chart.H - 26));
  }

  function buildChartPoints() {
    const c = state.city;
    const n = c.hourlyTemp.length;
    const temps = c.hourlyTemp;
    const min = Math.min.apply(null, temps) - 2;
    const max = Math.max.apply(null, temps) + 2;
    const x0 = 16;
    const x1 = chart.W - 16;
    const pts = [];
    for (let i = 0; i < n; i++) {
      const x = x0 + ((x1 - x0) * i) / (n - 1);
      const y = chart.yBottom - ((temps[i] - min) / (max - min)) * (chart.yBottom - chart.yTop);
      pts.push({ x, y, i });
    }
    chart.pts = pts;
    chart.min = min;
    chart.max = max;
  }

  function renderChart() {
    const c = state.city;
    chartMetrics();
    buildChartPoints();
    const pts = chart.pts;
    const n = pts.length;

    // 网格
    const grid = $("#chartGrid");
    grid.innerHTML = "";
    for (let g = 0; g < 4; g++) {
      const y = chart.yTop + ((chart.yBottom - chart.yTop) * g) / 3;
      const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
      line.setAttribute("x1", "16");
      line.setAttribute("x2", String(chart.W - 16));
      line.setAttribute("y1", y.toFixed(1));
      line.setAttribute("y2", y.toFixed(1));
      grid.appendChild(line);
    }

    // 降水柱
    const bars = $("#chartBars");
    bars.innerHTML = "";
    const slot = (chart.W - 32) / n;
    for (let i = 0; i < n; i++) {
      const pop = c.hourlyPop[i];
      const bh = (pop / 100) * chart.barMax;
      const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      rect.setAttribute("x", (16 + slot * i + slot * 0.22).toFixed(1));
      rect.setAttribute("y", (chart.barBase - bh).toFixed(1));
      rect.setAttribute("width", (slot * 0.56).toFixed(1));
      rect.setAttribute("height", Math.max(1.5, bh).toFixed(1));
      rect.setAttribute("rx", "3");
      rect.setAttribute("fill", "url(#gPop)");
      bars.appendChild(rect);
    }

    // 折线 + 面积
    let line = "";
    for (let i = 0; i < n; i++) line += (i ? "L" : "M") + pts[i].x.toFixed(1) + " " + pts[i].y.toFixed(1) + " ";
    $("#chartLine").setAttribute("d", line);
    $("#chartArea").setAttribute("d", line + "L" + pts[n - 1].x.toFixed(1) + " " + chart.yBottom + " L" + pts[0].x.toFixed(1) + " " + chart.yBottom + " Z");

    // 节点
    const dots = $("#chartDots");
    dots.innerHTML = "";
    for (let i = 0; i < n; i += 1) {
      const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      circle.setAttribute("cx", pts[i].x.toFixed(1));
      circle.setAttribute("cy", pts[i].y.toFixed(1));
      circle.setAttribute("r", i % 3 === 0 ? "4" : "2.2");
      circle.setAttribute("class", "chart__dot");
      dots.appendChild(circle);
    }

    // 时间标签
    const labels = $("#chartLabels");
    labels.innerHTML = "";
    const base = nowHour();
    for (let i = 0; i < n; i += 3) {
      const t = document.createElementNS("http://www.w3.org/2000/svg", "text");
      t.setAttribute("x", pts[i].x.toFixed(1));
      t.setAttribute("y", String(chart.H - 6));
      t.setAttribute("text-anchor", i === 0 ? "start" : "middle");
      t.textContent = i === 0 ? "现在" : pad((base + i) % 24) + ":00";
      labels.appendChild(t);
    }

    // 温度标注（每 6 小时）
    for (let i = 0; i < n; i += 6) {
      const t = document.createElementNS("http://www.w3.org/2000/svg", "text");
      t.setAttribute("x", pts[i].x.toFixed(1));
      t.setAttribute("y", (pts[i].y - 14).toFixed(1));
      t.setAttribute("text-anchor", "middle");
      t.setAttribute("class", "chart__tempLabel");
      t.textContent = fmtT(c.hourlyTemp[i]);
      labels.appendChild(t);
    }

    moveCursor(state.hourIndex);
  }

  function moveCursor(idx) {
    const pts = chart.pts;
    if (!pts.length) return;
    const i = clamp(idx, 0, pts.length - 1);
    state.hourIndex = i;
    const p = pts[i];
    const cursor = $("#chartCursor");
    cursor.setAttribute("opacity", "1");
    const line = cursor.querySelector("line");
    line.setAttribute("x1", p.x.toFixed(1));
    line.setAttribute("x2", p.x.toFixed(1));
    const dot = cursor.querySelector("circle");
    dot.setAttribute("cx", p.x.toFixed(1));
    dot.setAttribute("cy", p.y.toFixed(1));

    const c = state.city;
    const h = (nowHour() + i) % 24;
    $("#chartHint").textContent =
      (i === 0 ? "现在" : pad(h) + ":00") + " · " + fmtT(c.hourlyTemp[i]) + " · 降水 " + c.hourlyPop[i] + "%";

    $$(".hourstrip__item").forEach((el, k) => el.classList.toggle("is-active", k === i));
  }

  function renderHourStrip() {
    const c = state.city;
    const strip = $("#hourStrip");
    strip.innerHTML = "";
    const base = nowHour();
    const night = isNightNow();
    for (let i = 0; i < c.hourlyTemp.length; i++) {
      const li = document.createElement("li");
      li.className = "hourstrip__item";
      const h = (base + i) % 24;
      const cond = c.hourlyPop[i] > 60 && c.cond === "thunder" ? "thunder" : c.hourlyPop[i] > 55 ? (c.cond === "snow" ? "snow" : "rain") : h >= 7 && h < 18 ? c.dayCond : c.nightCond;
      li.innerHTML =
        '<span class="hourstrip__time">' + (i === 0 ? "现在" : pad(h) + ":00") + "</span>" +
        '<span class="hourstrip__icon"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="' + iconFor(cond, night && (h >= 19 || h < 6)) + '"/></svg></span>' +
        '<span class="hourstrip__temp">' + fmtT(c.hourlyTemp[i]) + "</span>" +
        '<span class="hourstrip__pop">' + (c.hourlyPop[i] >= 5 ? c.hourlyPop[i] + "%" : "—") + "</span>";
      li.addEventListener("click", () => moveCursor(i));
      strip.appendChild(li);
    }
    moveCursor(0);
  }

  function renderWeek() {
    const c = state.city;
    const list = $("#weekList");
    list.innerHTML = "";
    const all = [];
    c.daily.forEach((d) => all.push(d[3], d[4]));
    const gMin = Math.min.apply(null, all);
    const gMax = Math.max.apply(null, all);
    const span = Math.max(1, gMax - gMin);

    c.daily.forEach((d, i) => {
      const [day, date, cond, hi, lo, pop] = d;
      const li = document.createElement("li");
      li.className = "week__row fade-up";
      const left = ((lo - gMin) / span) * 100;
      const width = Math.max(6, ((hi - lo) / span) * 100);
      li.innerHTML =
        '<span class="week__day">' + day + "<small>" + date + "</small></span>" +
        '<span class="week__icon"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="' + iconFor(cond, false) + '"/></svg></span>' +
        '<span class="week__track"><span class="week__bar" style="inset-inline-start:' + left.toFixed(1) + "%;width:" + width.toFixed(1) + '%"></span></span>' +
        '<span class="week__temps"><span>' + fmtT(lo) + "</span><b>" + fmtT(hi) + '</b><em class="week__pop">' + (pop >= 5 ? pop + "%" : "") + "</em></span>";
      li.style.transitionDelay = i * 40 + "ms";
      list.appendChild(li);
    });
  }

  function renderAqi() {
    const a = state.city.aqi;
    $("#aqiVal").textContent = a.v;
    $("#aqiLv").textContent = a.lv;
    $("#aqiTip").textContent = a.tip;
    const arc = $("#aqiArc");
    const ratio = clamp(a.v / 300, 0.02, 1);
    const len = 2 * Math.PI * 58;
    arc.setAttribute("stroke-dasharray", (len * ratio).toFixed(1) + " " + len.toFixed(1));
    const color = a.v <= 50 ? "oklch(0.68 0.15 152)" : a.v <= 100 ? "oklch(0.78 0.15 88)" : a.v <= 150 ? "oklch(0.7 0.16 55)" : "oklch(0.62 0.2 25)";
    arc.setAttribute("stroke", color);

    const ul = $("#pollutants");
    ul.innerHTML = "";
    a.items.forEach((it) => {
      const li = document.createElement("li");
      li.innerHTML = it[0] + "<b>" + it[1] + "</b>";
      ul.appendChild(li);
    });
  }

  function renderLife() {
    const grid = $("#lifeGrid");
    grid.innerHTML = "";
    state.city.life.forEach((it, i) => {
      const li = document.createElement("li");
      li.className = "life__card fade-up";
      li.style.transitionDelay = i * 45 + "ms";
      let meter = "";
      for (let k = 1; k <= 5; k++) meter += '<i class="' + (k <= it[3] ? "on" : "") + '"></i>';
      li.innerHTML =
        '<div class="life__top"><span>' + pad(i + 1) + "</span><span class=\"life__lvl\">" + it[1] + "</span></div>" +
        "<h3>" + it[0] + "</h3>" +
        "<p>" + it[2] + "</p>" +
        '<div class="life__meter" role="img" aria-label="' + it[0] + " 等级 " + it[3] + " / 5\">" + meter + "</div>";
      grid.appendChild(li);
    });
  }

  function renderCityList() {
    const ul = $("#cityList");
    ul.innerHTML = "";
    CITIES.forEach((c) => {
      const li = document.createElement("li");
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "city-list__btn";
      btn.setAttribute("aria-pressed", c.id === state.city.id ? "true" : "false");
      btn.innerHTML =
        '<span class="city-list__name">' + c.name + "</span>" +
        '<span class="city-list__meta">' + COND_META[c.cond].text + " · " + c.district + "</span>" +
        '<span class="city-list__temp">' + fmtT(c.temp) + "</span>";
      btn.addEventListener("click", () => {
        state.city = c;
        state.offset = 0;
        renderAll();
        renderCityList();
        closeCityDialog();
      });
      li.appendChild(btn);
      ul.appendChild(li);
    });
  }

  function renderAll() {
    renderHero();
    renderChart();
    renderHourStrip();
    renderWeek();
    renderAqi();
    renderLife();
  }

  /* ==================== 5. 交互 ==================== */
  const dialog = $("#cityDialog");

  function openCityDialog() {
    renderCityList();
    if (typeof dialog.showModal === "function") dialog.showModal();
    else dialog.setAttribute("open", "");
    $("#cityBtn").setAttribute("aria-expanded", "true");
  }

  function closeCityDialog() {
    if (dialog.open) dialog.close();
    else dialog.removeAttribute("open");
    $("#cityBtn").setAttribute("aria-expanded", "false");
  }

  function initEvents() {
    // 移动端导航
    const nav = $("#primaryNav");
    const menuBtn = $("#menuBtn");
    const setMenu = (open) => {
      nav.classList.toggle("is-open", open);
      menuBtn.setAttribute("aria-expanded", open ? "true" : "false");
      menuBtn.setAttribute("aria-label", open ? "关闭导航菜单" : "打开导航菜单");
    };
    menuBtn.addEventListener("click", () => setMenu(!nav.classList.contains("is-open")));
    nav.addEventListener("click", (e) => {
      if (e.target.closest("a")) setMenu(false);
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && nav.classList.contains("is-open")) {
        setMenu(false);
        menuBtn.focus();
      }
    });
    window.matchMedia("(min-width: 861px)").addEventListener("change", (e) => {
      if (e.matches) setMenu(false);
    });

    $("#cityBtn").addEventListener("click", openCityDialog);
    $("#cityClose").addEventListener("click", closeCityDialog);
    dialog.addEventListener("click", (e) => {
      if (e.target === dialog) closeCityDialog();
    });
    dialog.addEventListener("close", () => $("#cityBtn").setAttribute("aria-expanded", "false"));

    $$(".unit-toggle__btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        if (btn.dataset.unit === state.unit) return;
        state.unit = btn.dataset.unit;
        $$(".unit-toggle__btn").forEach((b) => {
          const on = b === btn;
          b.classList.toggle("is-active", on);
          b.setAttribute("aria-pressed", on ? "true" : "false");
        });
        renderAll();
        renderCityList();
      });
    });

    // 刷新：模拟一次数据更新
    $("#refreshBtn").addEventListener("click", (e) => {
      const btn = e.currentTarget;
      btn.disabled = true;
      const icon = btn.querySelector("svg");
      icon.style.transition = "transform 700ms var(--ease)";
      icon.style.transform = "rotate(360deg)";

      const c = state.city;
      c.temp = clamp(c.temp + (Math.random() < 0.5 ? -1 : 1), -20, 40);
      c.humidity = clamp(c.humidity + Math.round((Math.random() - 0.5) * 6), 20, 99);
      c.wind = Math.max(0.2, +(c.wind + (Math.random() - 0.5) * 0.8).toFixed(1));
      c.aqi.v = clamp(c.aqi.v + Math.round((Math.random() - 0.5) * 8), 10, 260);
      c.aqi.lv = c.aqi.v <= 50 ? "优" : c.aqi.v <= 100 ? "良" : c.aqi.v <= 150 ? "轻度" : "中度";
      renderAll();
      renderCityList();

      setTimeout(() => {
        icon.style.transform = "";
        btn.disabled = false;
      }, 720);
    });

    // 曲线交互
    const plot = $("#chartPlot");
    const svg = $("#hourlyChart");
    svg.setAttribute("tabindex", "0");
    svg.setAttribute("role", "application");
    svg.setAttribute("aria-label", "逐时气温曲线，使用左右方向键查看各时段数值");

    plot.addEventListener("pointermove", (e) => {
      const rect = svg.getBoundingClientRect();
      const ratio = clamp((e.clientX - rect.left) / rect.width, 0, 1);
      moveCursor(Math.round(ratio * (chart.pts.length - 1)));
    });
    plot.addEventListener("pointerleave", () => moveCursor(0));
    svg.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight") {
        e.preventDefault();
        moveCursor(state.hourIndex + 1);
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        moveCursor(state.hourIndex - 1);
      } else if (e.key === "Home") {
        e.preventDefault();
        moveCursor(0);
      } else if (e.key === "End") {
        e.preventDefault();
        moveCursor(chart.pts.length - 1);
      }
    });
  }

  function initReveal() {
    const items = $$(".fade-up");
    if (state.reduceMotion || !("IntersectionObserver" in window)) {
      items.forEach((el) => el.classList.add("is-in"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            en.target.classList.add("is-in");
            io.unobserve(en.target);
          }
        });
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.12 }
    );
    items.forEach((el) => io.observe(el));
  }

  /* ==================== 6. 启动 ==================== */
  function init() {
    Sky.init($("#skyCanvas"));
    renderAll();
    renderCityList();
    initEvents();
    initReveal();

    // 曲线随容器尺寸重绘（rAF 节流）
    let resizeRaf = 0;
    const ro = new ResizeObserver(() => {
      if (resizeRaf) cancelAnimationFrame(resizeRaf);
      resizeRaf = requestAnimationFrame(() => {
        resizeRaf = 0;
        renderChart();
      });
    });
    ro.observe($("#chartPlot"));

    // 每分钟刷新一次观测时间与太阳位置
    setInterval(() => {
      const obs = new Date();
      $("#obsTime").textContent = pad(obs.getHours()) + ":" + pad(obs.getMinutes());
    }, 60000);

    window.matchMedia("(prefers-reduced-motion: reduce)").addEventListener("change", (e) => {
      state.reduceMotion = e.matches;
      if (e.matches) {
        Sky.stop();
        Sky.repaint();
      } else Sky.start();
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
