Skyward 天气观测台 · 纯静态站点
=====================================

一、文件说明
------------
index.html              页面结构（语义化 HTML5 + 内联 SVG 图标）
assets/css/style.css    全部样式（@layer 分层：reset/tokens/base/layout/components/utilities）
assets/js/main.js       全部交互（Canvas 天空动画、逐时曲线、城市切换、单位切换）
assets/img/*.webp       现场实景图片（已本地化，无外链）
favicon.svg             站点图标

本站在任何环境下都不发起外部请求：无 CDN、无网络字体、无第三方 JS。
字体使用系统字体栈（system-ui / 苹方 / 微软雅黑），离线可正常显示。

二、nginx 部署
--------------
方式 A：作为独立站点根目录
  1. 将本压缩包解压到 /var/www/weather/（保证 /var/www/weather/index.html 存在）
  2. 站点配置：

  server {
      listen 80;
      server_name weather.example.com;
      root /var/www/weather;
      index index.html;

      charset utf-8;
      charset_types text/css application/javascript application/json image/svg+xml;

      location / {
          try_files $uri $uri/ /index.html;
      }

      # 静态资源缓存
      location ~* \.(?:css|js|webp|svg|png|jpg|ico|woff2)$ {
          expires 30d;
          add_header Cache-Control "public, max-age=2592000, immutable";
          access_log off;
      }

      # 安全响应头（可按需调整）
      add_header X-Content-Type-Options "nosniff" always;
      add_header Referrer-Policy "strict-origin-when-cross-origin" always;
      add_header X-Frame-Options "SAMEORIGIN" always;

      gzip on;
      gzip_types text/css application/javascript image/svg+xml;
      gzip_min_length 1024;
  }

方式 B：作为子目录
  解压到 /var/www/html/weather/，访问 http://your-host/weather/
  若使用子目录，请确认 nginx 的 mime.types 已包含：
      image/webp  webp;
      image/svg+xml  svg;

三、本地预览
------------
直接双击 index.html 即可（file:// 协议下功能完整）。
或：python -m http.server 8080 --directory .   然后访问 http://localhost:8080/

四、浏览器支持
--------------
Chrome / Edge 120+、Firefox 121+、Safari 17.4+
使用了 @layer、oklch()、color-mix()、容器查询、dvh、:has() 等现代特性。
若需兼容更老浏览器，请自行增加回退样式（本站未包含 polyfill）。

五、说明
--------
页面内所有气象数值、预报曲线、空气质量分指数、生活指数均为虚构演示数据，
不连接任何接口，不可用于实际出行决策。

图片素材来源：Unsplash（https://unsplash.com/license，Unsplash License，可免费商用），
已下载并压缩为 WebP 存放于本地，页面不引用任何外部地址。
